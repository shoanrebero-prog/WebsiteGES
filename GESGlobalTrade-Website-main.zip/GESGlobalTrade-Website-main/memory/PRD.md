# GES Global Trade — Product Requirements (living document)

## Original problem statement
Build a premium B2B trading, global sourcing & industrial supply platform for **Global Environmental Services & Trading SPC** (brand: GES Global Trade, GESGlobalTrade.com, info@GESGlobalTrade.com, +971 52 228 2043, Oman & GCC). Public corporate website + digital enquiry/procurement platform (RFQ/BOQ/Request a Product/Business Enquiry with secure multi-file upload, unique reference numbers, enquiry status) + admin console (KPIs, enquiry management, statuses, notes, follow-ups, notifications, CRM, analytics, settings). White + corporate blue + navy theme. No fake stats, prices, certifications, suppliers. Never mention Regal Storage Systems.

## User choices (2026-06)
- Admin login: deferred ("not required now") → console open; `ADMIN_API_KEY` env gate + `X-Admin-Key` header ready.
- Email notifications: deferred → architecture isolated (logged as `[EMAIL-DISABLED]`, notification email configurable in Settings).
- Imagery: royalty-free stock photography (Unsplash) now; AI images later.
- Scope: full public site + admin dashboard.
- Logo: uploaded logo cropped into /public/logo.png, logo-header.png, logo-mark.png, favicon.png, og-image.jpg.

## Architecture
- Backend: FastAPI (`/app/backend/server.py`), Mongo (motor). Modules: `catalog_data.py` (21 categories / 187 product lines, industries, applications, search), `storage.py` (Emergent Object Storage, private files served via backend only).
- Collections: enquiries, documents, customers, notifications, audit_logs, counters (atomic reference sequence), settings.
- Reference numbers: `GES-{RFQ|PRQ|ENQ|QEQ|WHP}-{YEAR}-{0001}` via atomic counter.
- Priority scoring: project/tender/BOQ/warehouse/docs/company/date/qty → High/Medium/Normal (internal only).
- Security: file type/size validation (PDF/XLS/XLSX/DOC/DOCX/JPG/PNG, 15MB), in-memory rate limiting, honeypot, server-side validation, private storage, audit log.
- Frontend: React 19 + Tailwind + shadcn primitives, lazy-loaded pages, Plus Jakarta Sans, data-testids everywhere.

## Public pages (implemented 2026-06)
Home (16-section structure), About, Products (search/filter + no-result → Request Product), Category, Product Detail (quick enquiry modal, related, WhatsApp), Industries (+ /industries/:slug), Global Sourcing, Bulk & Project Supply, Warehouse Solutions, How We Work, Request a Product, Request a Quote/RFQ (8 request types, conditional warehouse fields, 6 doc-type uploaders), Business Enquiry, Contact, Enquiry Status (reference + email), Privacy, Terms, Thank-you (reference), 404. Header search dialog (autocomplete, recent, popular), sticky header, mobile menu + sticky CTA bar, floating WhatsApp, SEO (titles, meta, canonical, OG, Organization + Breadcrumb JSON-LD, sitemap.xml, robots.txt).

## Admin console (/admin) (implemented 2026-06)
Dashboard KPIs + recent + follow-ups; Enquiries list (search/filter/sort/paginate/CSV export); Enquiry detail (customer, requirement, warehouse, documents download, notes, status/assign/priority/follow-up, timeline); Customers CRM (auto-built, history, notes); Follow-ups (overdue/today/upcoming); Notifications (badge, mark read); Analytics (recharts, live); Settings (company info, team members, admin key, email status).

## Backlog / next
- P0: Admin authentication (JWT) + roles (Super Admin / Sales / Procurement / Viewer) — architecture ready via `require_admin`.
- P0: Email notifications (Resend) to info@ + customer confirmation.
- P1: AI-generated imagery replacing stock; admin product/category management UI (catalog currently code-defined in `catalog_data.py`).
- P1: CAPTCHA on public forms; per-enquiry document deletion (soft-delete).
- P2: Customer portal, supplier management, multi-language/currency.
