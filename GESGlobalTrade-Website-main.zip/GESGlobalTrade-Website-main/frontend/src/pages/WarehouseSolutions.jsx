import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { ArrowRight } from "lucide-react";
import { api } from "@/lib/api";
import { Seo, PageHero, SectionHead, Spinner } from "@/components/common";
import { FinalCta } from "@/components/home/Sections2";

const IMGS = { "Warehouse Racking": "1592085198739-ffcad7f36b54", "Industrial & Commercial Shelving": "1587293852726-70cdb56c2866", "Material Handling": "1740914994657-f1cdffdc418e", "Healthcare & Specialized Storage": "1586528116311-ad8dd3c8310d", "Warehouse & Loading Solutions": "1590247813693-5541d1c609fd" };

export default function WarehouseSolutions() {
  const [c, setC] = useState(null);
  useEffect(() => { api.get("/catalog/categories/warehouse-storage-material-handling").then((r) => setC(r.data)); }, []);
  return (
    <>
      <Seo title="Warehouse, Storage & Material Handling Solutions" description="Pallet racking, shelving, mezzanines, forklifts, reach trucks, hospital storage and loading bay solutions sourced and coordinated by GES Global Trade for Oman & GCC." />
      <PageHero eyebrow="Warehouse Solutions" title="Warehouse, Storage & Material Handling Solutions" lead="Smart Storage. Efficient Handling. Reliable Supply. Professional storage, racking and material-handling solutions for warehouses, industrial facilities, offices, healthcare, logistics and commercial environments." image="https://images.unsplash.com/photo-1592085198739-ffcad7f36b54?auto=format&fit=crop&w=1600&q=70" crumbs={[{ label: "Warehouse Solutions" }]}>
        <Link to="/request-quote?type=warehouse" className="btn-primary" data-testid="warehouse-submit-cta">Submit Warehouse Requirement <ArrowRight size={16} /></Link>
        <Link to="/products/warehouse-storage-material-handling" className="btn-ghost-light">Browse all product lines</Link>
      </PageHero>
      <section className="section"><div className="container-x">
        <SectionHead eyebrow="Complete projects" title="From individual storage requirements to complete warehouse projects." lead="GES Global Trade can help identify and coordinate suitable storage, racking and material-handling solutions based on space, load requirements, operational needs and project specifications." />
        {!c ? <Spinner /> : <div className="space-y-6">{c.groups.map((g, i) => (
          <div key={g.name} className={`card overflow-hidden grid lg:grid-cols-12 ${i % 2 ? "lg:[&>img]:order-last" : ""}`} data-testid={`warehouse-group-${i}`}>
            <img src={`https://images.unsplash.com/photo-${IMGS[g.name]}?auto=format&fit=crop&w=800&q=70`} alt={g.name} loading="lazy" className="lg:col-span-4 h-56 lg:h-full w-full object-cover" />
            <div className="lg:col-span-8 p-6 md:p-8"><h3 className="h3">{g.name}</h3><ul className="mt-4 flex flex-wrap gap-2">{g.items.map((it) => <li key={it.slug}><Link to={`/product/${it.slug}`} className="badge border-slate-200 hover:border-[#0369A1] hover:text-[#0369A1] py-1.5">{it.name}</Link></li>)}</ul></div>
          </div>
        ))}</div>}
      </div></section>
      <section className="section bg-slate-50 border-y border-slate-200"><div className="container-x grid lg:grid-cols-2 gap-10 items-center">
        <div><SectionHead eyebrow="Warehouse Project RFQ" title="Need a Customized Storage Solution?" lead="Send us your warehouse dimensions, layout, BOQ, drawings or storage requirements. Our team can review the requirement and coordinate suitable sourcing solutions." /><Link to="/request-quote?type=warehouse" className="btn-primary" data-testid="warehouse-cta-2">Submit Warehouse Requirement <ArrowRight size={16} /></Link></div>
        <div className="grid grid-cols-2 gap-3 text-sm">{["Warehouse dimensions & layout", "CAD / PDF drawings", "Rack type & load capacity", "Levels, pallet size & quantity", "Existing rack photos", "BOQ & equipment requirements"].map((x) => <div key={x} className="card p-4 font-semibold text-[#0A192F]">{x}</div>)}</div>
      </div></section>
      <FinalCta />
    </>
  );
}
