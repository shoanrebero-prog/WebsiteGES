import { Link } from "react-router-dom";
import { ArrowRight } from "lucide-react";
import { Seo, PageHero, SectionHead } from "@/components/common";
import { WhyGes } from "@/components/home/Capabilities";
import { FinalCta } from "@/components/home/Sections2";

const APPROACH = ["Understand", "Identify", "Source", "Evaluate", "Quote", "Coordinate Supply"];
const ROLES = [["International Trading Partner", "Connecting regional buyers with international supply markets."], ["Global Sourcing Partner", "Identifying suitable products and supply channels for defined requirements."], ["Industrial Supply Partner", "Industrial products, equipment and materials for commercial and project use."], ["Procurement Support Partner", "Structured handling of RFQs, BOQs and technical requirements."], ["Bulk & Project Supply Partner", "Large-volume and project-based supply coordination."], ["Environmental & Water Solutions Partner", "Water treatment, wastewater and environmental equipment sourcing."]];

export default function About() {
  return (
    <>
      <Seo title="About GES Global Trade" description="Global Environmental Services & Trading SPC — an Oman & GCC-focused international trading, sourcing, procurement support and industrial supply company." />
      <PageHero eyebrow="About GES" title="An Oman & GCC-focused international trading and sourcing company." lead="Global Environmental Services & Trading SPC, operating as GES Global Trade, connects businesses in Oman and the GCC with reliable products, equipment and materials through international supply channels." image="https://images.unsplash.com/photo-1578575437130-527eed3abbec?auto=format&fit=crop&w=1600&q=70" crumbs={[{ label: "About" }]}>
        <Link to="/request-quote" className="btn-primary">Request a Quote <ArrowRight size={16} /></Link>
        <Link to="/how-we-work" className="btn-ghost-light">How we work</Link>
      </PageHero>
      <section className="section">
        <div className="container-x grid lg:grid-cols-12 gap-10">
          <div className="lg:col-span-5"><SectionHead eyebrow="Who we are" title="Trading. Sourcing. Supply." lead="GES Global Trade is a trading, sourcing, procurement support, industrial supply and project supply company. We do not present ourselves as a manufacturer. Our role is to understand your requirement and identify, source, evaluate and coordinate suitable supply options." /><div className="bg-white inline-block border border-slate-200 rounded-lg p-4"><img src="/logo.png" alt="GES Global Trade" className="h-20 w-auto" loading="lazy" /></div></div>
          <div className="lg:col-span-7 grid sm:grid-cols-2 gap-4">{ROLES.map(([t, d]) => <div key={t} className="card p-6"><h3 className="font-bold text-[#0A192F]">{t}</h3><p className="text-sm text-slate-600 mt-1.5">{d}</p></div>)}</div>
        </div>
      </section>
      <section className="section bg-[#0A192F] text-white">
        <div className="container-x">
          <SectionHead light eyebrow="Our Approach" title="Understand → Identify → Source → Evaluate → Quote → Coordinate Supply" />
          <ol className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3" data-testid="approach-steps">{APPROACH.map((s, i) => <li key={s} className="rounded-md border border-white/15 bg-white/5 p-4"><span className="mono text-xs text-sky-300">0{i + 1}</span><p className="font-bold mt-2">{s}</p></li>)}</ol>
        </div>
      </section>
      <section className="section">
        <div className="container-x grid lg:grid-cols-2 gap-10 items-center">
          <div><SectionHead eyebrow="Positioning" title="Oman & GCC-based. Globally connected." lead="We work with businesses across construction, manufacturing, infrastructure, utilities, agriculture, water, logistics and commercial sectors. Whether your requirement is a single product, a BOQ or a complete warehouse project, the process is the same: tell us what you need, and we source the right solution." /><Link to="/request-product" className="btn-navy">Tell Us What You Need <ArrowRight size={16} /></Link></div>
          <img src="https://images.unsplash.com/photo-1494412651409-8963ce7935a7?auto=format&fit=crop&w=1000&q=70" alt="International container port" loading="lazy" className="rounded-lg border border-slate-200 aspect-[4/3] object-cover w-full" />
        </div>
      </section>
      <WhyGes />
      <FinalCta />
    </>
  );
}
