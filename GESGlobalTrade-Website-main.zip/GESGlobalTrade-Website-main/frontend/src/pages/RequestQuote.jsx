import { useEffect, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { api } from "@/lib/api";
import { Seo, PageHero } from "@/components/common";
import { Field, Input, Textarea, Select, CustomerFields, QuantityUnit } from "@/components/forms/Fields";
import { FileUploader } from "@/components/forms/FileUploader";
import { useEnquiryForm, Honeypot, FormShell, FormBlock } from "@/components/forms/useEnquiryForm";
import { FormAside } from "@/components/forms/FormAside";

const TYPES = ["Product Enquiry", "RFQ", "BOQ / Bulk Requirement", "Project Requirement", "Technical Requirement", "Tender Requirement", "Warehouse / Storage Project", "General Business Enquiry"];
const TYPE_FROM_PARAM = { warehouse: "Warehouse / Storage Project", project: "Project Requirement", boq: "BOQ / Bulk Requirement", tender: "Tender Requirement" };
const WH = ["project_name", "dimensions", "layout", "rack_type", "load_capacity", "levels", "pallet_dimensions", "pallet_count", "equipment", "special_requirements"];

export default function RequestQuote() {
  const [params] = useSearchParams();
  const [cats, setCats] = useState([]);
  const [inds, setInds] = useState([]);
  useEffect(() => { api.get("/catalog/categories").then((r) => setCats(r.data)); api.get("/catalog/industries").then((r) => setInds(r.data)); }, []);
  const init = { request_type: TYPE_FROM_PARAM[params.get("type")] || "RFQ", product: params.get("product") || "", quantity: "", unit: "", delivery_location: "", required_date: "", specifications: "", preferred_brand: "", alternative: "", message: "", category_slug: params.get("category") || "", product_slug: params.get("slug") || "", industry: "", application: "" };
  WH.forEach((k) => (init[k] = ""));
  const f = useEnquiryForm({
    kind: "rfq", requestType: (r) => r.request_type, requirementInit: init,
    buildRequirement: (r) => { const o = { ...r }; WH.forEach((k) => delete o[k]); delete o.request_type; return o; },
    buildWarehouse: (r) => (r.request_type === "Warehouse / Storage Project" ? Object.fromEntries(WH.map((k) => [k, r[k]])) : undefined),
  });
  const { customer, setC, req, setR, files, setFiles, errors, busy, submit } = f;
  const isWh = req.request_type === "Warehouse / Storage Project";
  const catName = (s) => cats.find((c) => c.slug === s)?.name;

  return (
    <>
      <Seo title="Request a Quote / RFQ — BOQ, Project & Tender Requirements" description="Submit RFQs, BOQs, project, tender and warehouse storage requirements to GES Global Trade with secure document upload. Receive a reference number instantly." />
      <PageHero compact eyebrow="Request a Quote" title="Submit your RFQ, BOQ or project requirement." lead="A procurement-style request form. Attach your RFQ, BOQ, specifications or drawings — our team reviews the requirement and coordinates suitable quotation options." crumbs={[{ label: "Request a Quote" }]} />
      <FormShell onSubmit={submit} aside={<FormAside />}>
        <FormBlock step="01" title="Request type">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-2" role="radiogroup" aria-label="Request type">
            {TYPES.map((t) => <button type="button" key={t} role="radio" aria-checked={req.request_type === t} onClick={() => setR("request_type", t)} className={`rounded-md border px-3 py-3 text-xs sm:text-sm font-semibold text-left transition-colors min-h-[48px] ${req.request_type === t ? "bg-[#0A192F] border-[#0A192F] text-white" : "border-slate-200 hover:border-[#0369A1] text-slate-700"}`} data-testid={`request-type-${t.toLowerCase().replace(/[^a-z]+/g, "-")}`}>{t}</button>)}
          </div>
        </FormBlock>
        <FormBlock step="02" title="Customer details"><CustomerFields v={customer} set={setC} errors={errors} /></FormBlock>
        <FormBlock step="03" title="Requirement">
          <div className="grid sm:grid-cols-2 gap-5">
            <Field label="Product / Material Required" name="product" required error={errors.product} className="sm:col-span-2"><Textarea name="product" rows={2} value={req.product} onChange={setR} error={errors.product} placeholder="Describe the product, material or scope. For BOQs, summarise and attach the file below." /></Field>
            <Field label="Product Category" name="category_slug"><select id="category_slug" value={req.category_slug} onChange={(e) => setR("category_slug", e.target.value)} className="input" data-testid="select-category_slug"><option value="">Select category (optional)</option>{cats.map((c) => <option key={c.slug} value={c.slug}>{c.name}</option>)}</select></Field>
            <Field label="Industry" name="industry"><Select name="industry" value={req.industry} onChange={setR} options={inds.map((i) => i.name)} placeholder="Select industry (optional)" /></Field>
            <QuantityUnit v={req} set={setR} errors={errors} />
            <Field label="Delivery Location" name="delivery_location"><Input name="delivery_location" value={req.delivery_location} onChange={setR} placeholder="City / Country / Port" /></Field>
            <Field label="Required Delivery Date" name="required_date"><Input name="required_date" type="date" value={req.required_date} onChange={setR} /></Field>
            <Field label="Technical Specifications" name="specifications" className="sm:col-span-2"><Textarea name="specifications" value={req.specifications} onChange={setR} /></Field>
            <Field label="Preferred Brand" name="preferred_brand"><Input name="preferred_brand" value={req.preferred_brand} onChange={setR} /></Field>
            <Field label="Alternative / Equivalent Requirement" name="alternative"><Input name="alternative" value={req.alternative} onChange={setR} /></Field>
            <Field label="Additional Message" name="message" className="sm:col-span-2"><Textarea name="message" rows={3} value={req.message} onChange={setR} /></Field>
          </div>
          {req.category_slug && <p className="text-xs text-slate-500 mt-3">Category: {catName(req.category_slug)}</p>}
        </FormBlock>
        {isWh && (
          <FormBlock step="03b" title="Warehouse / storage project details">
            <div className="rounded-md bg-sky-50 border border-sky-200 p-4 mb-6" data-testid="warehouse-callout"><h3 className="font-bold text-[#0A192F]">Need a Customized Storage Solution?</h3><p className="text-sm text-slate-600 mt-1">Send us your warehouse dimensions, layout, BOQ, drawings or storage requirements. Our team can review the requirement and coordinate suitable sourcing solutions.</p></div>
            <div className="grid sm:grid-cols-2 gap-5">
              <Field label="Project Name / Reference" name="project_name"><Input name="project_name" value={req.project_name} onChange={setR} /></Field>
              <Field label="Warehouse Dimensions" name="dimensions"><Input name="dimensions" value={req.dimensions} onChange={setR} placeholder="L × W × clear height (m)" /></Field>
              <Field label="Warehouse Layout" name="layout" className="sm:col-span-2"><Textarea name="layout" rows={2} value={req.layout} onChange={setR} placeholder="Describe existing layout, aisles, doors, columns… or attach a drawing below" /></Field>
              <Field label="Required Rack Type" name="rack_type"><Select name="rack_type" value={req.rack_type} onChange={setR} options={["Selective Pallet Racking", "Push-Back Racking", "Cantilever Racking", "Radio Shuttle Racking", "Mobile Pallet Racking", "Longspan Racking", "Heavy-Duty Racking", "Mezzanine System", "Shelving", "Not sure — need advice"]} /></Field>
              <Field label="Load Capacity" name="load_capacity"><Input name="load_capacity" value={req.load_capacity} onChange={setR} placeholder="kg per pallet / per level" /></Field>
              <Field label="Number of Levels" name="levels"><Input name="levels" value={req.levels} onChange={setR} inputMode="numeric" /></Field>
              <Field label="Pallet Dimensions" name="pallet_dimensions"><Input name="pallet_dimensions" value={req.pallet_dimensions} onChange={setR} placeholder="e.g. 1200 × 1000 mm" /></Field>
              <Field label="Number of Pallets" name="pallet_count"><Input name="pallet_count" value={req.pallet_count} onChange={setR} inputMode="numeric" /></Field>
              <Field label="Equipment Requirements" name="equipment"><Input name="equipment" value={req.equipment} onChange={setR} placeholder="Forklifts, pallet trucks, dock shelters…" /></Field>
              <Field label="Special Requirements" name="special_requirements" className="sm:col-span-2"><Textarea name="special_requirements" rows={2} value={req.special_requirements} onChange={setR} /></Field>
            </div>
          </FormBlock>
        )}
        <FormBlock step="04" title="Documents">
          <div className="grid md:grid-cols-2 gap-6">
            <FileUploader files={files} onChange={setFiles} docType="RFQ" label="RFQ" testId="upload-rfq" />
            <FileUploader files={files} onChange={setFiles} docType="BOQ" label="BOQ" testId="upload-boq" />
            <FileUploader files={files} onChange={setFiles} docType="Technical Specification" label="Technical Specification" testId="upload-spec" />
            <FileUploader files={files} onChange={setFiles} docType="Drawing" label={isWh ? "CAD / PDF Drawing · Existing Layout" : "Drawing"} testId="upload-drawing" />
            <FileUploader files={files} onChange={setFiles} docType="Product Image" label={isWh ? "Existing Rack Photos / Product Image" : "Product Image"} testId="upload-image" />
            <FileUploader files={files} onChange={setFiles} docType="Other Documents" label="Other Documents" testId="upload-other" />
          </div>
        </FormBlock>
        <Honeypot value={f.honey} onChange={f.setHoney} />
        <button type="submit" disabled={busy} className="btn-primary w-full !py-4 text-base" data-testid="submit-rfq-btn">{busy ? "Submitting…" : isWh ? "Submit Warehouse Requirement" : "Submit Requirement"}</button>
      </FormShell>
    </>
  );
}
