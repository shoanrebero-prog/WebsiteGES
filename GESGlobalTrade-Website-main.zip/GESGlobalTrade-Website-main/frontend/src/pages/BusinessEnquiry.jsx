import { Seo, PageHero } from "@/components/common";
import { Field, Input, Textarea, Select, CustomerFields } from "@/components/forms/Fields";
import { FileUploader } from "@/components/forms/FileUploader";
import { useEnquiryForm, Honeypot, FormShell, FormBlock } from "@/components/forms/useEnquiryForm";
import { FormAside } from "@/components/forms/FormAside";

const TOPICS = ["Trading partnership", "Sourcing support", "Import / export coordination", "Bulk supply", "Distribution enquiry", "Warehouse & storage project", "Environmental & water solutions", "Other business enquiry"];

export default function BusinessEnquiry() {
  const f = useEnquiryForm({ kind: "business_enquiry", requestType: "General Business Enquiry", requirementInit: { product: "", application: "", message: "", delivery_location: "" }, buildRequirement: (r) => ({ ...r, product: r.product || "General business enquiry" }) });
  const { customer, setC, req, setR, files, setFiles, errors, busy, submit } = f;
  return (
    <>
      <Seo title="Business Enquiry" description="Contact GES Global Trade about trading partnerships, sourcing support, import/export coordination and bulk supply across Oman, the GCC and international markets." />
      <PageHero compact eyebrow="Business Enquiry" title="Let's discuss how we can support your business." lead="For partnership, sourcing, distribution and general business enquiries. Have a project requirement? Let's review it." crumbs={[{ label: "Business Enquiry" }]} />
      <FormShell onSubmit={submit} aside={<FormAside title="How we handle business enquiries" />}>
        <FormBlock step="01" title="Your details"><CustomerFields v={customer} set={setC} errors={errors} /></FormBlock>
        <FormBlock step="02" title="Enquiry">
          <div className="grid sm:grid-cols-2 gap-5">
            <Field label="Enquiry Topic" name="application"><Select name="application" value={req.application} onChange={setR} options={TOPICS} /></Field>
            <Field label="Market / Location" name="delivery_location"><Input name="delivery_location" value={req.delivery_location} onChange={setR} placeholder="Country or region" /></Field>
            <Field label="Subject" name="product" required error={errors.product} className="sm:col-span-2"><Input name="product" value={req.product} onChange={setR} error={errors.product} placeholder="Brief subject of your enquiry" /></Field>
            <Field label="Message" name="message" className="sm:col-span-2"><Textarea name="message" rows={6} value={req.message} onChange={setR} /></Field>
          </div>
        </FormBlock>
        <FormBlock step="03" title="Attachments (optional)"><FileUploader files={files} onChange={setFiles} docType="Other Documents" label="Supporting documents" testId="upload-business" /></FormBlock>
        <Honeypot value={f.honey} onChange={f.setHoney} />
        <button type="submit" disabled={busy} className="btn-primary w-full !py-4 text-base" data-testid="submit-business-enquiry-btn">{busy ? "Submitting…" : "Submit Business Enquiry"}</button>
      </FormShell>
    </>
  );
}
