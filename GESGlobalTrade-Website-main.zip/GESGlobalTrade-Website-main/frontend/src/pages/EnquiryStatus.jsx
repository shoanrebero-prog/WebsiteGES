import { useState } from "react";
import { Search, FileText, CheckCircle2 } from "lucide-react";
import { api, fmtDateTime } from "@/lib/api";
import { Seo, PageHero } from "@/components/common";
import { Field, Input } from "@/components/forms/Fields";

export default function EnquiryStatus() {
  const [v, setV] = useState({ reference: "", email: "" });
  const [res, setRes] = useState(null);
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);
  const set = (k, val) => setV((p) => ({ ...p, [k]: val }));
  const submit = async (e) => {
    e.preventDefault(); setErr(""); setRes(null); setBusy(true);
    try { const r = await api.get("/enquiries/status", { params: v }); setRes(r.data); }
    catch (ex) { setErr(ex.response?.data?.detail || "Something went wrong. Please try again or contact us via WhatsApp."); }
    finally { setBusy(false); }
  };
  return (
    <>
      <Seo title="Check Your Enquiry Status" description="Track the status of your RFQ, product request or business enquiry with GES Global Trade using your reference number." />
      <PageHero compact eyebrow="Enquiry Status" title="Check Your Enquiry Status" lead="Enter your reference number and the email used in the submission to see the current status of your requirement." crumbs={[{ label: "Enquiry Status" }]} />
      <section className="section">
        <div className="container-x max-w-2xl">
          <form onSubmit={submit} className="card p-6 md:p-8 grid sm:grid-cols-2 gap-5" data-testid="status-form">
            <Field label="Reference Number" name="reference" required><Input name="reference" value={v.reference} onChange={set} placeholder="GES-RFQ-2026-0001" className="input mono uppercase" required /></Field>
            <Field label="Email used in submission" name="email" required><Input name="email" type="email" value={v.email} onChange={set} required /></Field>
            <button className="btn-primary sm:col-span-2" disabled={busy} data-testid="status-submit-btn"><Search size={16} />{busy ? "Checking…" : "Check Status"}</button>
            {err && <p className="sm:col-span-2 text-sm text-red-600" role="alert" data-testid="status-error">{err}</p>}
          </form>
          {res && (
            <div className="card p-6 md:p-8 mt-6" data-testid="status-result">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div><p className="text-xs font-bold uppercase tracking-wider text-slate-500">Reference</p><p className="mono text-lg font-medium text-[#0A192F]">{res.reference}</p></div>
                <span className="badge border-sky-200 bg-sky-50 text-[#0369A1] py-1" data-testid="status-badge">{res.status}</span>
              </div>
              <dl className="grid sm:grid-cols-2 gap-4 mt-6 text-sm">
                <div><dt className="text-slate-500">Requirement</dt><dd className="font-semibold text-[#0A192F]">{res.product}</dd></div>
                <div><dt className="text-slate-500">Request type</dt><dd className="font-semibold text-[#0A192F]">{res.request_type}</dd></div>
                <div><dt className="text-slate-500">Received</dt><dd className="font-semibold text-[#0A192F]">{fmtDateTime(res.created_at)}</dd></div>
                <div><dt className="text-slate-500">Last update</dt><dd className="font-semibold text-[#0A192F]">{fmtDateTime(res.updated_at)}</dd></div>
              </dl>
              {res.next_action && <div className="mt-5 rounded-md bg-amber-50 border border-amber-200 p-4 text-sm text-amber-900" data-testid="status-next-action"><strong>Next action:</strong> {res.next_action}</div>}
              <h3 className="font-bold text-[#0A192F] mt-8 mb-3">Progress</h3>
              <ol className="relative border-l border-slate-200 ml-2 space-y-4">{res.timeline.map((t, i) => <li key={i} className="ml-5 relative"><span className="absolute -left-[26px] top-0.5 h-3 w-3 rounded-full bg-[#0369A1] ring-4 ring-white" /><p className="text-sm font-semibold text-[#0A192F]">{t.event}</p><p className="text-xs text-slate-500">{fmtDateTime(t.at)}</p></li>)}</ol>
              {res.documents.length > 0 && <><h3 className="font-bold text-[#0A192F] mt-8 mb-3">Submitted documents</h3><ul className="space-y-2">{res.documents.map((d, i) => <li key={i} className="flex items-center gap-2 text-sm text-slate-700"><FileText size={15} className="text-slate-400" />{d.original_filename} <span className="text-xs text-slate-400">· {d.doc_type}</span><CheckCircle2 size={14} className="text-[#059669] ml-auto" /></li>)}</ul></>}
            </div>
          )}
        </div>
      </section>
    </>
  );
}
