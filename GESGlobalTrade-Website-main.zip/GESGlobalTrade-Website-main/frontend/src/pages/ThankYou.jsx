import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { CheckCircle2, MessageCircle, Copy } from "lucide-react";
import { toast } from "sonner";
import { Seo } from "@/components/common";
import { SITE, waLink } from "@/lib/site";

export default function ThankYou() {
  const { reference } = useParams();
  const [copied, setCopied] = useState(false);
  useEffect(() => { setCopied(false); }, [reference]);
  const copy = () => { navigator.clipboard?.writeText(reference); setCopied(true); toast.success("Reference copied"); };
  return (
    <section className="section bg-slate-50 min-h-[70vh] flex items-center" data-testid="thank-you-page">
      <Seo title="Requirement Received" />
      <div className="container-x max-w-2xl">
        <div className="card p-8 md:p-12 text-center">
          <div className="mx-auto h-16 w-16 rounded-full bg-emerald-50 text-[#059669] flex items-center justify-center"><CheckCircle2 size={34} /></div>
          <h1 className="h2 mt-6">Thank You — Your Requirement Has Been Received.</h1>
          <p className="lead mt-4">Our team will review your requirement and contact you regarding suitable sourcing and quotation options.</p>
          <div className="mt-8 rounded-lg border border-slate-200 bg-slate-50 p-5">
            <p className="text-xs font-bold uppercase tracking-wider text-slate-500">Reference Number</p>
            <div className="mt-2 flex items-center justify-center gap-3">
              <span className="mono text-xl sm:text-2xl font-medium text-[#0A192F]" data-testid="reference-number">{reference}</span>
              <button onClick={copy} className="p-2 text-slate-400 hover:text-[#0369A1]" aria-label="Copy reference" data-testid="copy-reference-btn"><Copy size={16} /></button>
            </div>
            <p className="text-xs text-slate-500 mt-2">Keep this reference to <Link to="/enquiry-status" className="text-[#0369A1] font-semibold">track your enquiry status</Link>. {copied && "Copied."}</p>
          </div>
          <p className="mt-6 text-sm text-slate-600">WhatsApp: <a href={waLink(`Hello GES Global Trade, I have submitted requirement ${reference}.`)} className="font-semibold text-[#0A192F]">{SITE.phone}</a></p>
          <div className="mt-6 flex flex-col sm:flex-row gap-3 justify-center">
            <a href={waLink(`Hello GES Global Trade, I have submitted requirement ${reference}.`)} target="_blank" rel="noopener noreferrer" className="btn-whatsapp" data-testid="thank-you-whatsapp-btn"><MessageCircle size={16} />WhatsApp Us</a>
            <Link to="/products" className="btn-outline" data-testid="thank-you-products-btn">Back to Products</Link>
          </div>
        </div>
      </div>
    </section>
  );
}
