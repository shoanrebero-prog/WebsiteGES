import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { ArrowRight, MessageCircle, FileText, CheckCircle2 } from "lucide-react";
import { api } from "@/lib/api";
import { waProduct } from "@/lib/site";
import { Seo, Breadcrumbs, Spinner, SectionHead } from "@/components/common";
import { ProductCard } from "@/pages/Products";
import { QuickEnquiryModal } from "@/components/QuickEnquiryModal";
import NotFound from "@/pages/NotFound";

export default function ProductDetail() {
  const { slug } = useParams();
  const [p, setP] = useState(null);
  const [err, setErr] = useState(false);
  const [quick, setQuick] = useState(false);
  useEffect(() => { setP(null); setErr(false); api.get(`/catalog/products/${slug}`).then((r) => setP(r.data)).catch(() => setErr(true)); }, [slug]);
  if (err) return <NotFound />;
  if (!p) return <Spinner />;
  return (
    <>
      <Seo title={`${p.name} — ${p.category_name}`} description={p.overview.slice(0, 155)} />
      <section className="bg-slate-50 border-b border-slate-200"><div className="container-x py-4"><Breadcrumbs items={[{ label: "Products", to: "/products" }, { label: p.category_name, to: `/products/${p.category_slug}` }, { label: p.name }]} /></div></section>
      <section className="section !pt-10">
        <div className="container-x grid lg:grid-cols-12 gap-10">
          <div className="lg:col-span-7">
            <div className="rounded-lg overflow-hidden border border-slate-200 aspect-[16/10]"><img src={p.image} alt={p.name} className="h-full w-full object-cover" /></div>
            <div className="mt-10">
              <h2 className="h3">Overview</h2>
              <p className="lead mt-3">{p.overview}</p>
              <div className="grid sm:grid-cols-2 gap-8 mt-10">
                <div><h3 className="font-bold text-[#0A192F] mb-3">Typical applications</h3><ul className="space-y-2">{p.applications.map((a) => <li key={a} className="flex items-center gap-2 text-sm text-slate-700"><CheckCircle2 size={15} className="text-[#0369A1]" />{a}</li>)}</ul></div>
                <div><h3 className="font-bold text-[#0A192F] mb-3">Available configurations</h3><ul className="space-y-2">{p.configurations.map((a) => <li key={a} className="flex items-start gap-2 text-sm text-slate-700"><span className="mt-2 h-1.5 w-1.5 rounded-full bg-[#0369A1] shrink-0" />{a}</li>)}</ul></div>
              </div>
              <div className="mt-10 rounded-lg border border-slate-200 bg-slate-50 p-6">
                <h3 className="font-bold text-[#0A192F]">Key specifications</h3>
                <p className="text-sm text-slate-600 mt-2" data-testid="spec-note">{p.spec_note} Share your requirement, quantity and preferred brand or equivalent, and our team will review suitable options.</p>
              </div>
            </div>
          </div>
          <aside className="lg:col-span-5">
            <div className="lg:sticky lg:top-[132px] space-y-4">
              <div className="card p-6 md:p-8">
                <span className="eyebrow">{p.category_name}</span>
                <h1 className="h2 mt-3" data-testid="product-title">{p.name}</h1>
                <p className="text-sm text-slate-600 mt-3">Sourced and supplied on request for commercial, industrial and project requirements across Oman, the GCC and international markets.</p>
                <div className="mt-6 grid gap-2">
                  <button onClick={() => setQuick(true)} className="btn-primary w-full" data-testid="product-quick-quote-btn"><FileText size={16} />Request Quote</button>
                  <Link to={`/request-quote?product=${encodeURIComponent(p.name)}&category=${p.category_slug}&slug=${p.slug}`} className="btn-outline w-full" data-testid="product-full-rfq-btn">Full RFQ with documents</Link>
                  <a href={waProduct(p.name)} target="_blank" rel="noopener noreferrer" className="btn-whatsapp w-full" data-testid="product-whatsapp-btn"><MessageCircle size={16} />WhatsApp</a>
                </div>
                <Link to={`/request-product?product=${encodeURIComponent(p.name)}&category=${p.category_slug}`} className="block text-center text-sm font-semibold text-[#0369A1] mt-4 hover:underline" data-testid="product-request-variant-btn">Need a different variant or brand? Request a Product →</Link>
              </div>
              <div className="card p-6">
                <p className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-3">Related Solutions</p>
                <ul className="flex flex-wrap gap-2">{p.related_categories.map((r) => <li key={r.slug}><Link to={`/products/${r.slug}`} className="badge border-slate-200 hover:border-[#0369A1] hover:text-[#0369A1] py-1">{r.name}</Link></li>)}</ul>
                <p className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-3 mt-5">Industries</p>
                <ul className="flex flex-wrap gap-2">{p.industries.map((r) => <li key={r.slug}><Link to={`/industries/${r.slug}`} className="badge border-sky-200 bg-sky-50 text-[#0369A1] py-1">{r.name}</Link></li>)}</ul>
              </div>
            </div>
          </aside>
        </div>
      </section>
      <section className="section bg-slate-50 border-t border-slate-200">
        <div className="container-x">
          <SectionHead eyebrow="Smart Discovery" title="You May Also Need" lead="Related products and complementary solutions often requested together." />
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4" data-testid="related-products">{p.related_products.map((r) => <ProductCard key={r.slug} p={r} />)}</div>
          <div className="mt-10 flex flex-wrap items-center gap-3"><p className="text-slate-700 font-semibold">If you don't see it, ask us.</p><Link to="/request-product" className="btn-navy btn-sm">Request a Product <ArrowRight size={14} /></Link></div>
        </div>
      </section>
      <QuickEnquiryModal open={quick} onClose={() => setQuick(false)} product={p} />
    </>
  );
}
