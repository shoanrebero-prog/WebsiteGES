import { Link } from "react-router-dom";
import { ArrowRight } from "lucide-react";
import { Seo, PageHero, SectionHead } from "@/components/common";
import { HowWeWorkSteps, FinalCta } from "@/components/home/Sections2";
import { WhyGes } from "@/components/home/Capabilities";

const JOURNEY = ["Discover", "Search", "Explore Product / Solution", "Can't Find It? Request Product", "Submit Requirement / RFQ / BOQ", "Receive Reference Number", "GES Reviews", "Sourcing", "Quotation", "Supply Coordination"];

export default function HowWeWork() {
  return (
    <>
      <Seo title="How We Work — Requirement to Supply in Five Steps" description="GES Global Trade's five-step process: Requirement, Sourcing, Evaluation, Quotation, Supply." />
      <PageHero eyebrow="How We Work" title="A clear process from requirement to supply." lead="Structured communication and enquiry handling — so you always know where your requirement stands." image="https://images.unsplash.com/photo-1565793298595-6a879b1d9492?auto=format&fit=crop&w=1600&q=70" crumbs={[{ label: "How We Work" }]}>
        <Link to="/request-quote" className="btn-primary">Start a Requirement <ArrowRight size={16} /></Link>
      </PageHero>
      <section className="section"><div className="container-x"><SectionHead eyebrow="Five Steps" title="Requirement → Sourcing → Evaluation → Quotation → Supply" /><HowWeWorkSteps /></div></section>
      <section className="section bg-[#0A192F] text-white"><div className="container-x">
        <SectionHead light eyebrow="Customer Journey" title="A digital sourcing platform, not a static catalogue." lead="Every step on this website leads to a structured requirement with a reference number you can track." />
        <ol className="flex flex-wrap gap-2" data-testid="journey">{JOURNEY.map((j, i) => <li key={j} className="flex items-center gap-2"><span className="rounded-md border border-white/15 bg-white/5 px-3 py-2 text-sm font-semibold">{j}</span>{i < JOURNEY.length - 1 && <ArrowRight size={14} className="text-sky-400" />}</li>)}</ol>
        <div className="mt-8 flex flex-wrap gap-3"><Link to="/enquiry-status" className="btn-ghost-light">Check Enquiry Status</Link><Link to="/request-product" className="btn-primary">Tell Us What You Need</Link></div>
      </div></section>
      <WhyGes />
      <FinalCta />
    </>
  );
}
