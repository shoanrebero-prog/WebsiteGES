import { useSearchParams } from "react-router-dom";
import { MessageCircle } from "lucide-react";
import { Seo, PageHero } from "@/components/common";
import { Field, Input, Textarea, CustomerFields, QuantityUnit } from "@/components/forms/Fields";
import { FileUploader } from "@/components/forms/FileUploader";
import { useEnquiryForm, Honeypot, FormShell, FormBlock } from "@/components/forms/useEnquiryForm";
import { FormAside } from "@/components/forms/FormAside";
import { waLink } from "@/lib/site";

export default function RequestProduct() {
  const [params] = useSearchParams();
  const f = useEnquiryForm({ kind: "product_request", requestType: "Product Enquiry", requirementInit: { product: params.get("product") || "", quantity: "", unit: "", preferred_brand: "", alternative: "", specifications: "", delivery_location: "", required_date: "", message: "", category_slug: params.get("category") || "" } });
  const { customer, setC, req, setR, files, setFiles, errors, busy, submit } = f;
  const waMsg = waLink(`Hello GES Global Trade, I would like to request a product: ${req.product || "[product]"}${req.quantity ? `, quantity ${req.quantity} ${req.unit}` : ""}. ${req.specifications || ""}`);
  return (
    <>
      <Seo title="Request a Product — Tell Us What You Need" description="Can't find the product? Send GES Global Trade your requirement, specification, quantity and delivery location. We'll review suitable sourcing options." />
      <PageHero compact eyebrow="Request a Product" title="Can't Find the Product? Tell Us What You Need." lead="Your requirement doesn't have to be listed in our catalogue. Send us the details and we'll review suitable sourcing options." crumbs={[{ label: "Request a Product" }]} />
      <FormShell onSubmit={submit} aside={<FormAside />}>
        <FormBlock step="01" title="Your details"><CustomerFields v={customer} set={setC} errors={errors} /></FormBlock>
        <FormBlock step="02" title="Product required">
          <div className="grid sm:grid-cols-2 gap-5">
            <Field label="Product Required" name="product" required error={errors.product} className="sm:col-span-2"><Input name="product" value={req.product} onChange={setR} error={errors.product} placeholder="e.g. 4-core armoured cable 25mm², submersible pump 5HP…" /></Field>
            <QuantityUnit v={req} set={setR} errors={errors} />
            <Field label="Preferred Brand" name="preferred_brand"><Input name="preferred_brand" value={req.preferred_brand} onChange={setR} /></Field>
            <Field label="Preferred Equivalent / Alternative" name="alternative"><Input name="alternative" value={req.alternative} onChange={setR} placeholder="Acceptable equivalents, if any" /></Field>
            <Field label="Required Specification" name="specifications" className="sm:col-span-2"><Textarea name="specifications" value={req.specifications} onChange={setR} placeholder="Technical details, standards, dimensions, ratings, application…" /></Field>
            <Field label="Delivery Location" name="delivery_location"><Input name="delivery_location" value={req.delivery_location} onChange={setR} placeholder="City / Country / Port" /></Field>
            <Field label="Required Delivery Date" name="required_date"><Input name="required_date" type="date" value={req.required_date} onChange={setR} /></Field>
            <Field label="Additional Requirements" name="message" className="sm:col-span-2"><Textarea name="message" rows={3} value={req.message} onChange={setR} /></Field>
          </div>
        </FormBlock>
        <FormBlock step="03" title="Attachments (optional)">
          <div className="grid md:grid-cols-2 gap-6">
            <FileUploader files={files} onChange={setFiles} docType="Product Image" label="Upload Product Image" hint="JPG, PNG, PDF · multiple files" testId="upload-product-image" />
            <FileUploader files={files} onChange={setFiles} docType="Technical Specification" label="Upload Specification" hint="PDF, DOC, XLS, images · multiple files" testId="upload-specification" />
          </div>
        </FormBlock>
        <Honeypot value={f.honey} onChange={f.setHoney} />
        <div className="flex flex-col sm:flex-row gap-3">
          <button type="submit" disabled={busy} className="btn-primary flex-1 !py-3.5" data-testid="submit-product-request-btn">{busy ? "Submitting…" : "Submit Product Request"}</button>
          <a href={waMsg} target="_blank" rel="noopener noreferrer" className="btn-whatsapp flex-1 !py-3.5" data-testid="send-whatsapp-btn"><MessageCircle size={16} />Send via WhatsApp</a>
        </div>
      </FormShell>
    </>
  );
}
