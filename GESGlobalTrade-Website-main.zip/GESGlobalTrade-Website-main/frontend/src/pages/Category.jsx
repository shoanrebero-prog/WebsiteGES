import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { ArrowRight, MessageCircle } from "lucide-react";
import { api } from "@/lib/api";
import { waProduct } from "@/lib/site";
import { Seo, PageHero, Spinner, SectionHead } from "@/components/common";
import { ProductCard } from "@/pages/Products";
import NotFound from "@/pages/NotFound";

export default function Category() {
  const { slug } = useParams();
  const [c, setC] = useState(null);
  const [err, setErr] = useState(false);
  useEffect(() => { setC(null); setErr(false); api.get(`/catalog/categories/${slug}`).then((r) => setC(r.data)).catch(() => setErr(true)); }, [slug]);
  if (err) return <NotFound />;
  if (!c) return <Spinner />;
  return (
    <>
      <Seo title={`${c.name} — Sourcing & Supply`} description={c.description} />
      <PageHero compact eyebrow={`Category ${c.code}`} title={c.name} lead={c.description} image={c.image} crumbs={[{ label: "Products", to: "/products" }, { label: c.name }]}>
        <Link to={`/request-quote?category=${c.slug}`} className="btn-primary" data-testid="category-rfq-btn">Request a Quote <ArrowRight size={16} /></Link>
        <a href={waProduct(c.name)} target="_blank" rel="noopener noreferrer" className="btn-whatsapp" data-testid="category-whatsapp-btn"><MessageCircle size={16} />WhatsApp</a>
      </PageHero>
      <section className="section">
        <div className="container-x grid lg:grid-cols-12 gap-10">
          <div className="lg:col-span-8">
            {c.groups ? c.groups.map((g) => (
              <div key={g.name} className="mb-12"><h2 className="h3 mb-5">{g.name}</h2><div className="grid sm:grid-cols-2 xl:grid-cols-3 gap-4">{g.items.map((it) => <ProductCard key={it.slug} p={c.products.find((p) => p.slug === it.slug)} />)}</div></div>
            )) : (
              <><h2 className="h3 mb-5">Product lines</h2><div className="grid sm:grid-cols-2 xl:grid-cols-3 gap-4" data-testid="category-products">{c.products.map((p) => <ProductCard key={p.slug} p={p} />)}</div></>
            )}
          </div>
          <aside className="lg:col-span-4 space-y-5">
            <div className="card p-6 bg-[#0A192F] text-white border-[#0A192F]">
              <h3 className="font-bold text-lg">Have a requirement in this category?</h3>
              <p className="text-sm text-slate-300 mt-2">Send quantity, specification and delivery location. Our team reviews suitable sourcing and quotation options.</p>
              <Link to={`/request-quote?category=${c.slug}`} className="btn-primary w-full mt-5">Request a Quote</Link>
              <Link to={`/request-product?category=${c.slug}`} className="btn-ghost-light w-full mt-2">Product not listed? Request it</Link>
            </div>
            <div className="card p-6">
              <p className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-3">Typical applications</p>
              <ul className="flex flex-wrap gap-2">{c.applications.map((a) => <li key={a.slug}><Link to={`/products?application=${a.slug}`} className="badge border-sky-200 bg-sky-50 text-[#0369A1]">{a.name}</Link></li>)}</ul>
              <p className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-3 mt-6">Industries served</p>
              <ul className="flex flex-wrap gap-2">{c.industries.map((a) => <li key={a.slug}><Link to={`/industries/${a.slug}`} className="badge border-slate-200 hover:border-[#0369A1]">{a.name}</Link></li>)}</ul>
            </div>
            <div className="card p-6">
              <p className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-3">You may also need</p>
              <ul className="space-y-2">{c.related.map((r) => <li key={r.slug}><Link to={`/products/${r.slug}`} className="flex items-center gap-3 group"><img src={r.thumb} alt="" className="h-12 w-16 rounded object-cover" loading="lazy" /><span className="text-sm font-semibold text-[#0A192F] group-hover:text-[#0369A1]">{r.name}</span></Link></li>)}</ul>
            </div>
          </aside>
        </div>
      </section>
      {c.slug === "warehouse-storage-material-handling" && (
        <section className="section bg-slate-50 border-t border-slate-200"><div className="container-x"><SectionHead eyebrow="Warehouse Projects" title="Need a Customized Storage Solution?" lead="From individual storage requirements to complete warehouse projects, GES Global Trade can help identify and coordinate suitable storage, racking and material-handling solutions based on space, load requirements, operational needs and project specifications." /><Link to="/request-quote?type=warehouse" className="btn-primary" data-testid="category-warehouse-cta">Submit Warehouse Requirement <ArrowRight size={16} /></Link></div></section>
      )}
    </>
  );
}
