import { Link } from "react-router-dom";
import { ArrowRight, FileSpreadsheet, Boxes, HardHat, Factory, Zap, Droplets, Warehouse, Forklift, Leaf } from "lucide-react";
import { Seo, PageHero, SectionHead } from "@/components/common";
import { FinalCta } from "@/components/home/Sections2";

const SCOPES = [[FileSpreadsheet, "BOQ sourcing"], [Boxes, "Bulk procurement"], [HardHat, "Project materials"], [Factory, "Industrial equipment"], [HardHat, "Construction materials"], [Zap, "Electrical requirements"], [Droplets, "Water & irrigation"], [Warehouse, "Warehouse systems"], [Forklift, "Material handling"], [Leaf, "Environmental solutions"]];

export default function ProjectSupply() {
  return (
    <>
      <Seo title="Bulk & Project Supply — BOQ Sourcing & Project Materials" description="From single requirements to complete project supply: BOQ sourcing, bulk procurement, project materials, industrial equipment, electrical, water and warehouse systems." />
      <PageHero eyebrow="Bulk & Project Supply" title="From Single Requirements to Complete Project Supply" lead="Send us your BOQ, tender requirement or project material list. We consolidate sourcing, evaluation and quotation coordination into one structured process." image="https://images.unsplash.com/photo-1504307651254-35680f356dfd?auto=format&fit=crop&w=1600&q=70" crumbs={[{ label: "Project Supply" }]}>
        <Link to="/request-quote?type=project" className="btn-primary" data-testid="project-supply-cta">Submit Project Requirement <ArrowRight size={16} /></Link>
        <Link to="/request-quote?type=boq" className="btn-ghost-light">Have a BOQ? Send it to us.</Link>
      </PageHero>
      <section className="section"><div className="container-x"><SectionHead eyebrow="Scope" title="What we support" lead="Project and bulk requirements across the categories our customers request most." /><div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">{SCOPES.map(([I, t]) => <div key={t} className="card p-5"><I size={20} className="text-[#0369A1]" /><p className="font-bold text-[#0A192F] mt-3 text-sm">{t}</p></div>)}</div></div></section>
      <section className="section bg-[#0A192F] text-white"><div className="container-x grid lg:grid-cols-3 gap-6">
        {[["BOQ & Tender", "Upload your BOQ or tender schedule. We review line items, identify suitable options and coordinate consolidated quotation options."], ["Bulk Quantities", "Large-volume requirements for distributors, contractors and industrial facilities — coordinated through international supply channels."], ["Phased Project Supply", "Requirements that span multiple categories and delivery phases handled under one reference for clear communication."]].map(([t, d]) => <div key={t} className="rounded-lg border border-white/15 bg-white/5 p-7"><h3 className="font-bold text-lg">{t}</h3><p className="text-sm text-slate-300 mt-2 leading-relaxed">{d}</p></div>)}
      </div></section>
      <FinalCta />
    </>
  );
}
