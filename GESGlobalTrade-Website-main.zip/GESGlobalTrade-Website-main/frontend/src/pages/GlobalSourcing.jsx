import { Link } from "react-router-dom";
import { ArrowRight } from "lucide-react";
import { Seo, PageHero, SectionHead } from "@/components/common";
import { SourcingProcess } from "@/components/home/Sections";
import { FinalCta, HowWeWorkSteps } from "@/components/home/Sections2";

export default function GlobalSourcing() {
  return (
    <>
      <Seo title="Global Sourcing — One Reliable Point of Coordination" description="GES Global Trade identifies, sources and coordinates products through international supply channels according to specifications, commercial requirements and delivery needs." />
      <PageHero eyebrow="Global Sourcing" title="Global Sourcing. One Reliable Point of Coordination." lead="GES Global Trade helps customers identify, source and coordinate suitable products through international supply channels according to specifications, commercial requirements and delivery needs." image="https://images.unsplash.com/photo-1519003722824-194d4455a60c?auto=format&fit=crop&w=1600&q=70" crumbs={[{ label: "Global Sourcing" }]}>
        <Link to="/request-quote" className="btn-primary">Request a Quote <ArrowRight size={16} /></Link>
        <Link to="/request-product" className="btn-ghost-light">Request a Product</Link>
      </PageHero>
      <section className="section"><div className="container-x"><SectionHead eyebrow="Sourcing Process" title="A structured, seven-stage sourcing process." lead="Each requirement moves through a consistent evaluation process — so you deal with one coordinated point of contact rather than multiple suppliers." /><SourcingProcess /></div></section>
      <section className="section bg-slate-50 border-y border-slate-200">
        <div className="container-x grid lg:grid-cols-2 gap-10 items-center">
          <img src="https://images.unsplash.com/photo-1581094288338-2314dddb7ece?auto=format&fit=crop&w=1000&q=70" alt="Engineers reviewing technical drawings" loading="lazy" className="rounded-lg border border-slate-200 aspect-[4/3] object-cover w-full" />
          <div><SectionHead eyebrow="Import & Export" title="Coordinating international supply for regional requirements." lead="From specification matching to supply coordination, we handle communication with international supply channels so that your team receives clear, comparable quotation options. Supplier networks remain confidential; the customer relationship stays with you and GES." /><ul className="grid sm:grid-cols-2 gap-2 text-sm text-slate-700">{["Specification-based sourcing", "Equivalent / alternative options", "Commercial evaluation", "Quotation coordination", "Bulk & project quantities", "Delivery coordination support"].map((x) => <li key={x} className="flex items-center gap-2"><span className="h-1.5 w-1.5 rounded-full bg-[#0369A1]" />{x}</li>)}</ul></div>
        </div>
      </section>
      <section className="section"><div className="container-x"><SectionHead eyebrow="How We Work" title="Five steps from requirement to supply." /><HowWeWorkSteps /></div></section>
      <FinalCta />
    </>
  );
}
