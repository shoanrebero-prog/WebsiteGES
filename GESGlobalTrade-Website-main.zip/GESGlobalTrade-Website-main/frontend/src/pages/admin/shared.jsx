import { Link } from "react-router-dom";
import { fmtDate } from "@/lib/api";

export const STATUS_STYLE = { New: "bg-sky-50 text-[#0369A1] border-sky-200", "Under Review": "bg-indigo-50 text-indigo-700 border-indigo-200", Sourcing: "bg-amber-50 text-amber-700 border-amber-200", "Supplier Evaluation": "bg-orange-50 text-orange-700 border-orange-200", "Quotation Prepared": "bg-violet-50 text-violet-700 border-violet-200", "Awaiting Customer": "bg-yellow-50 text-yellow-800 border-yellow-200", Completed: "bg-emerald-50 text-emerald-700 border-emerald-200", Closed: "bg-slate-100 text-slate-600 border-slate-200" };
export const PRIORITY_STYLE = { High: "bg-red-50 text-red-700 border-red-200", Medium: "bg-amber-50 text-amber-700 border-amber-200", Normal: "bg-slate-50 text-slate-600 border-slate-200" };
export const KIND_LABEL = { rfq: "RFQ", product_request: "Product Request", business_enquiry: "Business Enquiry", quick_enquiry: "Quick Enquiry", warehouse_project: "Warehouse Project" };

export const StatusBadge = ({ s }) => <span className={`badge ${STATUS_STYLE[s] || STATUS_STYLE.Closed}`} data-testid="status-badge">{s}</span>;
export const PriorityBadge = ({ p }) => <span className={`badge ${PRIORITY_STYLE[p] || PRIORITY_STYLE.Normal}`} data-testid="priority-badge">{p} Priority</span>;

export const PageTitle = ({ title, sub, children }) => (
  <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-6">
    <div><h1 className="text-2xl font-bold text-[#0A192F]" data-testid="admin-page-title">{title}</h1>{sub && <p className="text-sm text-slate-500 mt-1">{sub}</p>}</div>
    {children && <div className="flex flex-wrap gap-2">{children}</div>}
  </div>
);

export const Panel = ({ title, action, children, className = "" }) => (
  <section className={`bg-white rounded-lg border border-slate-200 ${className}`}>
    {(title || action) && <div className="flex items-center justify-between px-5 py-3.5 border-b border-slate-200"><h2 className="font-bold text-[#0A192F] text-sm">{title}</h2>{action}</div>}
    <div className="p-5">{children}</div>
  </section>
);

export const AdminEmpty = ({ title, text, testId }) => <div className="py-10 text-center" data-testid={testId || "admin-empty"}><p className="font-semibold text-[#0A192F]">{title}</p>{text && <p className="text-sm text-slate-500 mt-1">{text}</p>}</div>;

export const EnquiryRow = ({ e, compact }) => (
  <tr className="border-b border-slate-100 hover:bg-slate-50 transition-colors" data-testid={`enquiry-row-${e.reference}`}>
    <td className="px-4 py-3"><Link to={`/admin/enquiries/${e.id}`} className="mono text-xs font-medium text-[#0369A1] hover:underline">{e.reference}</Link><p className="text-[11px] text-slate-400">{KIND_LABEL[e.kind]}</p></td>
    <td className="px-4 py-3"><p className="font-semibold text-sm text-[#0A192F] truncate max-w-[220px]">{e.customer.company_name || e.customer.full_name}</p><p className="text-xs text-slate-500">{e.customer.country}</p></td>
    <td className="px-4 py-3 text-sm text-slate-700 max-w-[260px] truncate">{e.requirement.product}</td>
    {!compact && <td className="px-4 py-3 hidden lg:table-cell"><PriorityBadge p={e.priority} /></td>}
    <td className="px-4 py-3"><StatusBadge s={e.status} /></td>
    {!compact && <td className="px-4 py-3 text-xs text-slate-500 hidden md:table-cell">{e.assigned_to || "—"}</td>}
    <td className="px-4 py-3 text-xs text-slate-500 whitespace-nowrap">{fmtDate(e.created_at)}</td>
  </tr>
);

export const EnquiryTable = ({ items, compact }) => (
  <div className="overflow-x-auto -mx-5 -mb-5"><table className="w-full text-left min-w-[640px]">
    <thead><tr className="text-[11px] uppercase tracking-wider text-slate-500 border-b border-slate-200"><th className="px-4 py-2.5 font-semibold">Reference</th><th className="px-4 py-2.5 font-semibold">Customer</th><th className="px-4 py-2.5 font-semibold">Requirement</th>{!compact && <th className="px-4 py-2.5 font-semibold hidden lg:table-cell">Priority</th>}<th className="px-4 py-2.5 font-semibold">Status</th>{!compact && <th className="px-4 py-2.5 font-semibold hidden md:table-cell">Assigned</th>}<th className="px-4 py-2.5 font-semibold">Received</th></tr></thead>
    <tbody>{items.map((e) => <EnquiryRow key={e.id} e={e} compact={compact} />)}</tbody>
  </table></div>
);
