import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { adminApi } from "@/lib/api";
import { Spinner } from "@/components/common";
import { PageTitle, Panel, AdminEmpty, StatusBadge, PriorityBadge } from "./shared";

export default function FollowUps() {
  const [d, setD] = useState(null);
  useEffect(() => { adminApi.get("/followups").then((r) => setD(r.data)); }, []);
  if (!d) return <Spinner />;
  const List = ({ items, empty }) => items.length ? <ul className="divide-y divide-slate-100">{items.map((e) => <li key={e.id} className="py-3 flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-4" data-testid="followup-item"><span className="mono text-xs text-slate-500 w-24 shrink-0">{e.follow_up_date}</span><Link to={`/admin/enquiries/${e.id}`} className="font-semibold text-sm text-[#0A192F] hover:text-[#0369A1] flex-1 min-w-0 truncate">{e.reference} · {e.customer.company_name || e.customer.full_name}</Link><span className="text-xs text-slate-500 truncate max-w-[220px]">{e.follow_up_note || e.requirement.product}</span><span className="text-xs text-slate-500">{e.assigned_to || "Unassigned"}</span><PriorityBadge p={e.priority} /><StatusBadge s={e.status} /></li>)}</ul> : <AdminEmpty title={empty} />;
  return (
    <div data-testid="admin-followups">
      <PageTitle title="Follow-ups" sub="Scheduled from enquiry records. Only actual follow-ups are shown." />
      <div className="space-y-4">
        <Panel title={`Overdue Follow-ups (${d.overdue.length})`}><List items={d.overdue} empty="No overdue follow-ups" /></Panel>
        <Panel title={`Today's Follow-ups (${d.today.length})`}><List items={d.today} empty="No follow-ups due today" /></Panel>
        <Panel title={`Upcoming Follow-ups (${d.upcoming.length})`}><List items={d.upcoming} empty="No upcoming follow-ups scheduled" /></Panel>
      </div>
    </div>
  );
}
