import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Inbox, Sparkles, FileText, PackageSearch, Building2, Warehouse, CalendarClock, CheckCircle2, ArrowRight } from "lucide-react";
import { adminApi } from "@/lib/api";
import { Spinner } from "@/components/common";
import { PageTitle, Panel, AdminEmpty, EnquiryTable } from "./shared";

const KPIS = [["total", "Total Enquiries", Inbox], ["new", "New Enquiries", Sparkles], ["active_rfqs", "Active RFQs", FileText], ["product_requests", "Product Requests", PackageSearch], ["project_requests", "Project Requests", Building2], ["warehouse_projects", "Warehouse Projects", Warehouse], ["pending_followups", "Pending Follow-ups", CalendarClock], ["completed", "Completed Requests", CheckCircle2]];

export default function Dashboard() {
  const [d, setD] = useState(null);
  useEffect(() => { adminApi.get("/dashboard").then((r) => setD(r.data)); }, []);
  if (!d) return <Spinner />;
  const fu = d.followups;
  return (
    <div data-testid="admin-dashboard">
      <PageTitle title="Dashboard" sub="Live overview from actual enquiry data."><Link to="/admin/enquiries" className="btn-outline btn-sm">All enquiries</Link><a href={`${process.env.REACT_APP_BACKEND_URL}/api/admin/enquiries/export`} className="btn-primary btn-sm" data-testid="export-csv-btn">Export CSV</a></PageTitle>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6" data-testid="kpi-grid">
        {KPIS.map(([k, label, I]) => <div key={k} className="bg-white rounded-lg border border-slate-200 p-4 md:p-5" data-testid={`kpi-${k}`}><div className="flex items-center justify-between"><p className="text-xs font-semibold text-slate-500 leading-tight">{label}</p><I size={16} className="text-[#0369A1]" /></div><p className="text-2xl md:text-3xl font-bold text-[#0A192F] mt-2 mono">{d.kpis[k]}</p></div>)}
      </div>
      {d.kpis.total === 0 && <div className="mb-6 rounded-lg border border-dashed border-slate-300 bg-white p-8 text-center" data-testid="dashboard-empty"><p className="font-semibold text-[#0A192F]">No enquiry data yet.</p><p className="text-sm text-slate-500 mt-1">Analytics will appear as enquiries are received.</p></div>}
      <div className="grid lg:grid-cols-3 gap-4">
        <Panel title="Recent enquiries" className="lg:col-span-2" action={<Link to="/admin/enquiries" className="text-xs font-semibold text-[#0369A1] flex items-center gap-1">View all <ArrowRight size={12} /></Link>}>
          {d.recent.length ? <EnquiryTable items={d.recent} compact /> : <AdminEmpty title="No enquiries yet" text="No RFQs have been received." />}
        </Panel>
        <Panel title="Follow-ups">
          {[["Overdue", fu.overdue, "text-red-600"], ["Today", fu.today, "text-amber-600"], ["Upcoming", fu.upcoming, "text-[#0369A1]"]].map(([l, list, c]) => (
            <div key={l} className="mb-4 last:mb-0"><p className={`text-xs font-bold uppercase tracking-wider ${c}`}>{l} · {list.length}</p>
              {list.length ? <ul className="mt-2 space-y-1.5">{list.slice(0, 4).map((e) => <li key={e.id}><Link to={`/admin/enquiries/${e.id}`} className="flex justify-between text-sm hover:text-[#0369A1]"><span className="truncate">{e.customer.company_name || e.customer.full_name}</span><span className="mono text-xs text-slate-400">{e.follow_up_date}</span></Link></li>)}</ul> : <p className="text-xs text-slate-400 mt-1">None</p>}
            </div>
          ))}
          <Link to="/admin/followups" className="btn-outline btn-sm w-full mt-4">Manage follow-ups</Link>
        </Panel>
      </div>
    </div>
  );
}
