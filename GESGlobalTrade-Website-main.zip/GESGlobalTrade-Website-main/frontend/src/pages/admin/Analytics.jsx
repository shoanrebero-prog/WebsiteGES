import { useEffect, useState } from "react";
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid, AreaChart, Area, PieChart, Pie, Cell } from "recharts";
import { adminApi } from "@/lib/api";
import { Spinner } from "@/components/common";
import { PageTitle, Panel, AdminEmpty } from "./shared";

const COLORS = ["#0369A1", "#0EA5E9", "#0A192F", "#059669", "#38BDF8", "#64748B", "#F59E0B", "#6366F1"];
const HBar = ({ data, testId }) => data.length ? <ResponsiveContainer width="100%" height={Math.max(180, data.length * 34)}><BarChart data={data} layout="vertical" margin={{ left: 8, right: 16 }}><CartesianGrid horizontal={false} stroke="#E2E8F0" /><XAxis type="number" allowDecimals={false} tick={{ fontSize: 11 }} /><YAxis type="category" dataKey="name" width={150} tick={{ fontSize: 11 }} /><Tooltip /><Bar dataKey="value" fill="#0369A1" radius={[0, 4, 4, 0]} /></BarChart></ResponsiveContainer> : <AdminEmpty title="No data yet" text="Analytics will appear once customer activity is recorded." testId={testId} />;

export default function Analytics() {
  const [d, setD] = useState(null);
  useEffect(() => { adminApi.get("/analytics").then((r) => setD(r.data)); }, []);
  if (!d) return <Spinner />;
  const empty = d.total === 0;
  return (
    <div data-testid="admin-analytics">
      <PageTitle title="Analytics" sub="Computed live from submitted enquiries. No demo data." />
      {empty && <div className="mb-4 rounded-lg border border-dashed border-slate-300 bg-white p-8 text-center" data-testid="analytics-empty"><p className="font-semibold text-[#0A192F]">No enquiry data yet.</p><p className="text-sm text-slate-500 mt-1">Analytics will appear as enquiries are received.</p></div>}
      <div className="grid lg:grid-cols-2 gap-4">
        <Panel title="Enquiries by month" className="lg:col-span-2"><ResponsiveContainer width="100%" height={240}><AreaChart data={d.by_month}><defs><linearGradient id="a" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#0369A1" stopOpacity={.3} /><stop offset="100%" stopColor="#0369A1" stopOpacity={0} /></linearGradient></defs><CartesianGrid vertical={false} stroke="#E2E8F0" /><XAxis dataKey="month" tick={{ fontSize: 11 }} /><YAxis allowDecimals={false} tick={{ fontSize: 11 }} width={30} /><Tooltip /><Area type="monotone" dataKey="value" stroke="#0369A1" strokeWidth={2} fill="url(#a)" /></AreaChart></ResponsiveContainer></Panel>
        <Panel title="Request status funnel"><HBar data={d.funnel.filter((x) => x.value > 0)} /></Panel>
        <Panel title="Requests by type">{d.by_kind.length ? <ResponsiveContainer width="100%" height={240}><PieChart><Pie data={d.by_kind} dataKey="value" nameKey="name" innerRadius={55} outerRadius={90} paddingAngle={2}>{d.by_kind.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}</Pie><Tooltip /></PieChart></ResponsiveContainer> : <AdminEmpty title="No data yet" />}<ul className="flex flex-wrap gap-3 text-xs mt-2">{d.by_kind.map((k, i) => <li key={k.name} className="flex items-center gap-1.5"><span className="h-2.5 w-2.5 rounded-sm" style={{ background: COLORS[i % COLORS.length] }} />{k.name} ({k.value})</li>)}</ul></Panel>
        <Panel title="RFQs by product category"><HBar data={d.by_category} /></Panel>
        <Panel title="Requests by industry"><HBar data={d.by_industry} /></Panel>
        <Panel title="Requests by country"><HBar data={d.by_country} /></Panel>
        <Panel title="Requests by application"><HBar data={d.by_application} /></Panel>
        <Panel title="Enquiry workload (open, by assignee)"><HBar data={d.workload} /></Panel>
        <Panel title="Pending follow-ups"><div className="grid grid-cols-3 gap-3 text-center">{[["Overdue", d.followups.overdue.length, "text-red-600"], ["Today", d.followups.today.length, "text-amber-600"], ["Upcoming", d.followups.upcoming.length, "text-[#0369A1]"]].map(([l, v, c]) => <div key={l} className="rounded-lg border border-slate-200 p-4"><p className={`text-3xl font-bold mono ${c}`}>{v}</p><p className="text-xs text-slate-500 mt-1">{l}</p></div>)}</div></Panel>
      </div>
    </div>
  );
}
