import { useEffect, useState } from "react";
import { Search } from "lucide-react";
import { adminApi, api } from "@/lib/api";
import { Spinner } from "@/components/common";
import { PageTitle, Panel, AdminEmpty, EnquiryTable, KIND_LABEL } from "./shared";

export default function Enquiries() {
  const [f, setF] = useState({ q: "", status: "", kind: "", priority: "", sort: "created_at", order: "desc", page: 1 });
  const [data, setData] = useState(null);
  const [statuses, setStatuses] = useState([]);
  useEffect(() => { api.get("/meta").then((r) => setStatuses(r.data.statuses)); }, []);
  useEffect(() => { const t = setTimeout(() => adminApi.get("/enquiries", { params: { ...f, page_size: 25 } }).then((r) => setData(r.data)), 200); return () => clearTimeout(t); }, [f]);
  const set = (k, v) => setF((p) => ({ ...p, [k]: v, page: 1 }));
  const pages = data ? Math.max(1, Math.ceil(data.total / data.page_size)) : 1;
  return (
    <div data-testid="admin-enquiries">
      <PageTitle title="Enquiries & RFQs" sub={data ? `${data.total} record(s)` : ""}><a href={`${process.env.REACT_APP_BACKEND_URL}/api/admin/enquiries/export`} className="btn-outline btn-sm">Export CSV</a></PageTitle>
      <Panel>
        <div className="grid sm:grid-cols-2 lg:grid-cols-6 gap-2 mb-5">
          <div className="relative lg:col-span-2"><Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" /><input value={f.q} onChange={(e) => set("q", e.target.value)} placeholder="Search reference, company, email, product…" className="input pl-9 !min-h-0 !py-2" data-testid="enquiries-search" /></div>
          <select value={f.status} onChange={(e) => set("status", e.target.value)} className="input !min-h-0 !py-2" data-testid="filter-status"><option value="">All statuses</option>{statuses.map((s) => <option key={s}>{s}</option>)}</select>
          <select value={f.kind} onChange={(e) => set("kind", e.target.value)} className="input !min-h-0 !py-2" data-testid="filter-kind"><option value="">All types</option>{Object.entries(KIND_LABEL).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select>
          <select value={f.priority} onChange={(e) => set("priority", e.target.value)} className="input !min-h-0 !py-2" data-testid="filter-priority"><option value="">All priorities</option>{["High", "Medium", "Normal"].map((s) => <option key={s}>{s}</option>)}</select>
          <select value={`${f.sort}:${f.order}`} onChange={(e) => { const [s, o] = e.target.value.split(":"); setF((p) => ({ ...p, sort: s, order: o })); }} className="input !min-h-0 !py-2" data-testid="sort-select"><option value="created_at:desc">Newest first</option><option value="created_at:asc">Oldest first</option><option value="priority_score:desc">Priority</option><option value="updated_at:desc">Recently updated</option><option value="follow_up_date:asc">Follow-up date</option></select>
        </div>
        {!data ? <Spinner /> : data.items.length ? <EnquiryTable items={data.items} /> : <AdminEmpty title="No enquiries yet" text="No RFQs have been received matching these filters." testId="enquiries-empty" />}
        {data && pages > 1 && <div className="flex items-center justify-between pt-5 mt-5 border-t border-slate-100 text-sm"><button disabled={f.page <= 1} onClick={() => setF((p) => ({ ...p, page: p.page - 1 }))} className="btn-outline btn-sm">Previous</button><span className="text-slate-500">Page {f.page} of {pages}</span><button disabled={f.page >= pages} onClick={() => setF((p) => ({ ...p, page: p.page + 1 }))} className="btn-outline btn-sm">Next</button></div>}
      </Panel>
    </div>
  );
}
