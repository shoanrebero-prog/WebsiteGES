import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { ArrowLeft, Download, FileText, Send, Mail, Phone, Building2, MapPin } from "lucide-react";
import { toast } from "sonner";
import { adminApi, api, fmtDateTime } from "@/lib/api";
import { Spinner } from "@/components/common";
import { Panel, StatusBadge, PriorityBadge, KIND_LABEL } from "./shared";

const Row = ({ l, v }) => v ? <div className="grid grid-cols-3 gap-2 py-2 border-b border-slate-100 last:border-0 text-sm"><dt className="text-slate-500">{l}</dt><dd className="col-span-2 font-medium text-[#0A192F] whitespace-pre-wrap break-words">{v}</dd></div> : null;

export default function EnquiryDetail() {
  const { id } = useParams();
  const [e, setE] = useState(null);
  const [meta, setMeta] = useState({ statuses: [] });
  const [team, setTeam] = useState([]);
  const [note, setNote] = useState("");
  const load = () => adminApi.get(`/enquiries/${id}`).then((r) => setE(r.data)).catch(() => toast.error("Enquiry not found"));
  useEffect(() => { load(); api.get("/meta").then((r) => setMeta(r.data)); adminApi.get("/settings").then((r) => setTeam(r.data.team_members || [])); }, [id]);
  const patch = async (body) => { try { const r = await adminApi.patch(`/enquiries/${id}`, body); setE(r.data); toast.success("Updated"); } catch { toast.error("Update failed"); } };
  const addNote = async (ev) => { ev.preventDefault(); if (!note.trim()) return; await adminApi.post(`/enquiries/${id}/notes`, { text: note }); setNote(""); load(); };
  const download = async (d) => { try { const r = await adminApi.get(`/documents/${d.id}/download`, { responseType: "blob" }); const u = URL.createObjectURL(r.data); const a = document.createElement("a"); a.href = u; a.download = d.original_filename; a.click(); URL.revokeObjectURL(u); } catch { toast.error("Document temporarily unavailable"); } };
  if (!e) return <Spinner />;
  const c = e.customer, r = e.requirement;
  return (
    <div data-testid="admin-enquiry-detail">
      <Link to="/admin/enquiries" className="text-sm font-semibold text-[#0369A1] flex items-center gap-1 mb-4"><ArrowLeft size={14} />Back to enquiries</Link>
      <div className="flex flex-col md:flex-row md:items-start justify-between gap-4 mb-6">
        <div><p className="text-xs font-bold uppercase tracking-wider text-slate-500">{KIND_LABEL[e.kind]} · {e.request_type}</p><h1 className="text-2xl font-bold text-[#0A192F] mono mt-1" data-testid="detail-reference">{e.reference}</h1><p className="text-sm text-slate-500 mt-1">Received {fmtDateTime(e.created_at)} · Updated {fmtDateTime(e.updated_at)}</p></div>
        <div className="flex flex-wrap gap-2"><StatusBadge s={e.status} /><PriorityBadge p={e.priority} /></div>
      </div>
      <div className="grid lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2 space-y-4">
          <Panel title="Customer"><dl><Row l="Name" v={c.full_name} /><Row l="Company" v={c.company_name} /><Row l="Country" v={c.country} /><Row l="Email" v={<a href={`mailto:${c.email}`} className="text-[#0369A1] flex items-center gap-1"><Mail size={13} />{c.email}</a>} /><Row l="Phone" v={<a href={`https://wa.me/${c.phone.replace(/\D/g, "")}`} target="_blank" rel="noreferrer" className="text-[#0369A1] flex items-center gap-1"><Phone size={13} />{c.phone}</a>} />{e.customer_id && <Row l="CRM" v={<Link to={`/admin/customers/${e.customer_id}`} className="text-[#0369A1] flex items-center gap-1"><Building2 size={13} />View customer profile & history</Link>} />}</dl></Panel>
          <Panel title="Requirement"><dl><Row l="Product" v={r.product} /><Row l="Quantity" v={r.quantity ? `${r.quantity} ${r.unit || ""}` : ""} /><Row l="Delivery location" v={r.delivery_location && <span className="flex items-center gap-1"><MapPin size={13} />{r.delivery_location}</span>} /><Row l="Required date" v={r.required_date} /><Row l="Specifications" v={r.specifications} /><Row l="Preferred brand" v={r.preferred_brand} /><Row l="Alternative" v={r.alternative} /><Row l="Industry" v={r.industry} /><Row l="Application / topic" v={r.application} /><Row l="Category" v={r.category_slug} /><Row l="Message" v={r.message} /><Row l="Source page" v={e.source_page} /></dl></Panel>
          {e.warehouse && <Panel title="Warehouse / storage project"><dl>{Object.entries(e.warehouse).map(([k, v]) => <Row key={k} l={k.replace(/_/g, " ")} v={v} />)}</dl></Panel>}
          <Panel title={`Documents (${e.documents.length})`}>{e.documents.length ? <ul className="divide-y divide-slate-100">{e.documents.map((d) => <li key={d.id} className="flex items-center gap-3 py-2.5 text-sm" data-testid="document-row"><FileText size={16} className="text-slate-400" /><div className="flex-1 min-w-0"><p className="font-medium truncate">{d.original_filename}</p><p className="text-xs text-slate-500">{d.doc_type} · {(d.size / 1024).toFixed(0)} KB · {fmtDateTime(d.uploaded_at)}</p></div><button onClick={() => download(d)} className="btn-outline btn-sm" data-testid="download-doc-btn"><Download size={14} />Download</button></li>)}</ul> : <p className="text-sm text-slate-500">No documents uploaded.</p>}</Panel>
          <Panel title="Internal notes">
            <form onSubmit={addNote} className="flex gap-2 mb-4"><input value={note} onChange={(ev) => setNote(ev.target.value)} placeholder="Add an internal note (never visible to customers)…" className="input !min-h-0 !py-2" data-testid="note-input" /><button className="btn-primary btn-sm" data-testid="add-note-btn"><Send size={14} /></button></form>
            {e.notes.length ? <ul className="space-y-3">{[...e.notes].reverse().map((n) => <li key={n.id} className="rounded-md bg-slate-50 border border-slate-200 p-3 text-sm" data-testid="note-item"><p className="text-slate-800 whitespace-pre-wrap">{n.text}</p><p className="text-xs text-slate-400 mt-1">{n.author} · {fmtDateTime(n.created_at)}</p></li>)}</ul> : <p className="text-sm text-slate-500">No internal notes yet.</p>}
          </Panel>
        </div>
        <div className="space-y-4">
          <Panel title="Internal">
            <label className="label" htmlFor="status">Status</label><select id="status" value={e.status} onChange={(ev) => patch({ status: ev.target.value })} className="input !min-h-0 !py-2 mb-4" data-testid="status-select">{meta.statuses.map((s) => <option key={s}>{s}</option>)}</select>
            <label className="label" htmlFor="assigned">Assigned to</label><select id="assigned" value={e.assigned_to} onChange={(ev) => patch({ assigned_to: ev.target.value })} className="input !min-h-0 !py-2 mb-4" data-testid="assign-select"><option value="">Unassigned</option>{team.map((t) => <option key={t}>{t}</option>)}</select>
            <label className="label" htmlFor="priority">Priority <span className="text-slate-400 font-normal">(score {e.priority_score})</span></label><select id="priority" value={e.priority} onChange={(ev) => patch({ priority: ev.target.value })} className="input !min-h-0 !py-2 mb-4" data-testid="priority-select">{["High", "Medium", "Normal"].map((s) => <option key={s}>{s}</option>)}</select>
            <label className="label" htmlFor="fu">Follow-up date</label><input id="fu" type="date" value={e.follow_up_date || ""} onChange={(ev) => patch({ follow_up_date: ev.target.value })} className="input !min-h-0 !py-2 mb-4" data-testid="followup-date-input" />
            <label className="label" htmlFor="fun">Follow-up note</label><textarea id="fun" defaultValue={e.follow_up_note} onBlur={(ev) => ev.target.value !== e.follow_up_note && patch({ follow_up_note: ev.target.value })} rows={2} className="input" data-testid="followup-note-input" />
          </Panel>
          <Panel title="Timeline"><ol className="relative border-l border-slate-200 ml-1.5 space-y-4" data-testid="timeline">{[...e.history].reverse().map((h, i) => <li key={i} className="ml-4 relative"><span className="absolute -left-[22px] top-1 h-2.5 w-2.5 rounded-full bg-[#0369A1] ring-4 ring-white" /><p className="text-sm font-semibold text-[#0A192F]">{h.event}</p><p className="text-xs text-slate-500">{fmtDateTime(h.at)} · {h.by}</p></li>)}</ol></Panel>
        </div>
      </div>
    </div>
  );
}
