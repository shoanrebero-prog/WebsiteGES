import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { ArrowLeft, Search, Send } from "lucide-react";
import { adminApi, fmtDate, fmtDateTime } from "@/lib/api";
import { Spinner } from "@/components/common";
import { PageTitle, Panel, AdminEmpty, EnquiryTable } from "./shared";

export default function Customers() {
  const { id } = useParams();
  const [list, setList] = useState(null);
  const [q, setQ] = useState("");
  const [c, setC] = useState(null);
  const [note, setNote] = useState("");
  useEffect(() => { if (id) return; const t = setTimeout(() => adminApi.get("/customers", { params: { q } }).then((r) => setList(r.data)), 200); return () => clearTimeout(t); }, [q, id]);
  const loadC = () => adminApi.get(`/customers/${id}`).then((r) => setC(r.data));
  useEffect(() => { if (id) { setC(null); loadC(); } }, [id]);
  const addNote = async (e) => { e.preventDefault(); if (!note.trim()) return; await adminApi.post(`/customers/${id}/notes`, { text: note }); setNote(""); loadC(); };

  if (id) {
    if (!c) return <Spinner />;
    const byKind = c.enquiries.reduce((a, e) => ({ ...a, [e.kind]: (a[e.kind] || 0) + 1 }), {});
    return (
      <div data-testid="admin-customer-detail">
        <Link to="/admin/customers" className="text-sm font-semibold text-[#0369A1] flex items-center gap-1 mb-4"><ArrowLeft size={14} />All customers</Link>
        <PageTitle title={c.company_name} sub={`${c.country} · First enquiry ${fmtDate(c.first_seen)} · Last activity ${fmtDate(c.last_seen)}`} />
        <div className="grid lg:grid-cols-3 gap-4">
          <div className="lg:col-span-2 space-y-4">
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">{[["Total", c.enquiries.length], ["RFQs", byKind.rfq || 0], ["Product req.", byKind.product_request || 0], ["Warehouse", byKind.warehouse_project || 0], ["Business", byKind.business_enquiry || 0]].map(([l, v]) => <div key={l} className="bg-white border border-slate-200 rounded-lg p-4"><p className="text-xs text-slate-500">{l}</p><p className="text-2xl font-bold text-[#0A192F] mono">{v}</p></div>)}</div>
            <Panel title="Enquiry history">{c.enquiries.length ? <EnquiryTable items={c.enquiries} /> : <AdminEmpty title="No enquiries" />}</Panel>
            <Panel title="Documents"><ul className="text-sm divide-y divide-slate-100">{c.enquiries.flatMap((e) => e.documents.map((d) => <li key={d.id} className="py-2 flex justify-between gap-3"><span className="truncate">{d.original_filename}</span><Link to={`/admin/enquiries/${e.id}`} className="mono text-xs text-[#0369A1] shrink-0">{e.reference}</Link></li>))}</ul>{!c.enquiries.some((e) => e.documents.length) && <p className="text-sm text-slate-500">No documents on file.</p>}</Panel>
          </div>
          <div className="space-y-4">
            <Panel title="Contacts"><ul className="space-y-3 text-sm">{c.contacts.map((p) => <li key={p.email}><p className="font-semibold text-[#0A192F]">{p.name}</p><a href={`mailto:${p.email}`} className="text-[#0369A1] block">{p.email}</a><span className="text-slate-500">{p.phone}</span></li>)}</ul></Panel>
            <Panel title="Customer notes"><form onSubmit={addNote} className="flex gap-2 mb-3"><input value={note} onChange={(e) => setNote(e.target.value)} className="input !min-h-0 !py-2" placeholder="Internal note…" data-testid="customer-note-input" /><button className="btn-primary btn-sm" data-testid="customer-add-note"><Send size={14} /></button></form>{c.notes?.length ? <ul className="space-y-2 text-sm">{[...c.notes].reverse().map((n) => <li key={n.id} className="bg-slate-50 border border-slate-200 rounded p-2.5"><p>{n.text}</p><p className="text-xs text-slate-400 mt-1">{fmtDateTime(n.created_at)}</p></li>)}</ul> : <p className="text-sm text-slate-500">No notes.</p>}</Panel>
          </div>
        </div>
      </div>
    );
  }
  return (
    <div data-testid="admin-customers">
      <PageTitle title="Customers" sub="Companies and contacts built automatically from enquiries." />
      <Panel>
        <div className="relative mb-4 max-w-md"><Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" /><input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search company, email, country…" className="input pl-9 !min-h-0 !py-2" data-testid="customers-search" /></div>
        {!list ? <Spinner /> : list.length ? <div className="overflow-x-auto -mx-5 -mb-5"><table className="w-full text-left min-w-[560px]"><thead><tr className="text-[11px] uppercase tracking-wider text-slate-500 border-b border-slate-200"><th className="px-4 py-2.5">Company</th><th className="px-4 py-2.5">Country</th><th className="px-4 py-2.5">Contacts</th><th className="px-4 py-2.5">Enquiries</th><th className="px-4 py-2.5">Last activity</th></tr></thead><tbody>{list.map((x) => <tr key={x.id} className="border-b border-slate-100 hover:bg-slate-50" data-testid="customer-row"><td className="px-4 py-3"><Link to={`/admin/customers/${x.id}`} className="font-semibold text-[#0A192F] hover:text-[#0369A1]">{x.company_name}</Link></td><td className="px-4 py-3 text-sm text-slate-600">{x.country}</td><td className="px-4 py-3 text-sm text-slate-600">{x.contacts.map((p) => p.name).join(", ")}</td><td className="px-4 py-3 mono text-sm">{x.enquiry_count}</td><td className="px-4 py-3 text-xs text-slate-500">{fmtDate(x.last_seen)}</td></tr>)}</tbody></table></div> : <AdminEmpty title="No customers yet" text="Customer records are created automatically when enquiries are received." testId="customers-empty" />}
      </Panel>
    </div>
  );
}
