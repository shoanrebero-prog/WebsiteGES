import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Bell, CheckCheck } from "lucide-react";
import { adminApi, fmtDateTime } from "@/lib/api";
import { Spinner } from "@/components/common";
import { PageTitle, Panel, AdminEmpty } from "./shared";

export default function Notifications() {
  const [d, setD] = useState(null);
  const load = () => adminApi.get("/notifications").then((r) => setD(r.data));
  useEffect(() => { load(); }, []);
  const markAll = async () => { await adminApi.post("/notifications/read"); load(); };
  if (!d) return <Spinner />;
  return (
    <div data-testid="admin-notifications">
      <PageTitle title="Notifications" sub={`${d.unread} unread · ${d.followups_due_today} follow-up(s) due today · ${d.followups_overdue} overdue`}><button onClick={markAll} className="btn-outline btn-sm" data-testid="mark-all-read-btn"><CheckCheck size={14} />Mark all read</button></PageTitle>
      {(d.followups_due_today > 0 || d.followups_overdue > 0) && <div className="mb-4 rounded-lg border border-amber-200 bg-amber-50 p-4 text-sm text-amber-900 flex items-center justify-between gap-3" data-testid="followup-alert"><span><strong>Follow-ups:</strong> {d.followups_due_today} due today, {d.followups_overdue} overdue.</span><Link to="/admin/followups" className="font-semibold underline">Open follow-ups</Link></div>}
      <Panel>{d.items.length ? <ul className="divide-y divide-slate-100">{d.items.map((n) => <li key={n.id} className={`py-3 flex gap-3 ${n.read ? "opacity-60" : ""}`} data-testid="notification-item"><span className={`mt-1 h-2 w-2 rounded-full shrink-0 ${n.read ? "bg-slate-300" : "bg-[#0369A1]"}`} /><div className="flex-1 min-w-0"><p className="text-sm font-semibold text-[#0A192F]">{n.title}</p><p className="text-sm text-slate-600 truncate">{n.message}</p><p className="text-xs text-slate-400 mt-0.5">{fmtDateTime(n.created_at)}</p></div>{n.enquiry_id && <Link to={`/admin/enquiries/${n.enquiry_id}`} className="btn-outline btn-sm shrink-0">Open</Link>}</li>)}</ul> : <AdminEmpty title="No notifications yet" text="Notifications appear when enquiries, documents and status updates occur." testId="notifications-empty" />}</Panel>
    </div>
  );
}
