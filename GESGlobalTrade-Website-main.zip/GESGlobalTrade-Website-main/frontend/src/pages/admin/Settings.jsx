import { useEffect, useState } from "react";
import { toast } from "sonner";
import { adminApi } from "@/lib/api";
import { Spinner } from "@/components/common";
import { PageTitle, Panel } from "./shared";
import { Field, Input } from "@/components/forms/Fields";

const FIELDS = [["legal_name", "Legal company name"], ["brand_name", "Brand name"], ["region", "Region"], ["email", "Public email"], ["phone", "Phone / WhatsApp (display)"], ["whatsapp", "WhatsApp number (digits only)"], ["notification_email", "Internal notification email"]];

export default function SettingsPage() {
  const [s, setS] = useState(null);
  const [team, setTeam] = useState("");
  const [key, setKey] = useState(localStorage.getItem("ges_admin_key") || "");
  useEffect(() => { adminApi.get("/settings").then((r) => { setS(r.data); setTeam((r.data.team_members || []).join(", ")); }); }, []);
  if (!s) return <Spinner />;
  const set = (k, v) => setS((p) => ({ ...p, [k]: v }));
  const save = async (e) => { e.preventDefault(); try { const body = Object.fromEntries(FIELDS.map(([k]) => [k, s[k]])); body.team_members = team.split(",").map((x) => x.trim()).filter(Boolean); const r = await adminApi.put("/settings", body); setS(r.data); toast.success("Settings saved"); } catch { toast.error("Could not save settings"); } };
  return (
    <div data-testid="admin-settings">
      <PageTitle title="Settings" sub="Company information, team members and configuration." />
      <div className="grid lg:grid-cols-3 gap-4">
        <form onSubmit={save} className="lg:col-span-2 space-y-4">
          <Panel title="Company & contact information"><div className="grid sm:grid-cols-2 gap-4">{FIELDS.map(([k, l]) => <Field key={k} label={l} name={k}><Input name={k} value={s[k]} onChange={set} /></Field>)}<Field label="Team members (comma separated, used for assignment)" name="team" className="sm:col-span-2"><input id="team" value={team} onChange={(e) => setTeam(e.target.value)} className="input" data-testid="input-team" /></Field></div><button className="btn-primary mt-5" data-testid="save-settings-btn">Save settings</button></Panel>
        </form>
        <div className="space-y-4">
          <Panel title="Email notifications"><p className="text-sm text-slate-600">Email delivery is <strong>not configured</strong>. Architecture is ready: when an email provider (e.g. Resend) is connected, new enquiries notify <span className="font-medium">{s.notification_email}</span> and customers receive a confirmation. Until then, notifications appear in the admin Notification Center.</p></Panel>
          <Panel title="Admin access"><p className="text-sm text-slate-600 mb-3">Admin login is deferred. If <code className="mono text-xs bg-slate-100 px-1 rounded">ADMIN_API_KEY</code> is set on the server, enter it here to authorise this browser.</p><input type="password" value={key} onChange={(e) => setKey(e.target.value)} className="input mb-2" placeholder="Admin API key" data-testid="admin-key-input" /><button onClick={() => { localStorage.setItem("ges_admin_key", key); toast.success("Key saved in this browser"); }} className="btn-outline btn-sm" data-testid="save-admin-key-btn">Save key</button></Panel>
          <Panel title="Roles (planned)"><ul className="text-sm text-slate-600 space-y-1"><li>• Super Admin — full access</li><li>• Sales / Enquiry Manager</li><li>• Procurement / Sourcing</li><li>• Viewer — read-only</li></ul><p className="text-xs text-slate-400 mt-2">Role-based permissions activate together with admin authentication.</p></Panel>
        </div>
      </div>
    </div>
  );
}
