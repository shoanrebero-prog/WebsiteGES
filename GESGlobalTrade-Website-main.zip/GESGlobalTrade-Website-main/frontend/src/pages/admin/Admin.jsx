import { useEffect, useState } from "react";
import { Routes, Route, NavLink, Link, useLocation } from "react-router-dom";
import { LayoutDashboard, Inbox, Users, CalendarClock, Bell, BarChart3, Settings, Menu, X, ExternalLink, ShieldAlert } from "lucide-react";
import { Toaster } from "sonner";
import { adminApi } from "@/lib/api";
import Dashboard from "./Dashboard";
import Enquiries from "./Enquiries";
import EnquiryDetail from "./EnquiryDetail";
import Customers from "./Customers";
import FollowUps from "./FollowUps";
import Notifications from "./Notifications";
import Analytics from "./Analytics";
import SettingsPage from "./Settings";

const NAV = [["", "Dashboard", LayoutDashboard], ["enquiries", "Enquiries & RFQs", Inbox], ["customers", "Customers", Users], ["followups", "Follow-ups", CalendarClock], ["notifications", "Notifications", Bell], ["analytics", "Analytics", BarChart3], ["settings", "Settings", Settings]];

export default function Admin() {
  const [open, setOpen] = useState(false);
  const [unread, setUnread] = useState(0);
  const loc = useLocation();
  useEffect(() => { setOpen(false); document.title = "Admin Console | GES Global Trade"; }, [loc.pathname]);
  useEffect(() => { const load = () => adminApi.get("/notifications", { params: { limit: 1 } }).then((r) => setUnread(r.data.unread + r.data.followups_overdue)).catch(() => {}); load(); const t = setInterval(load, 30000); return () => clearInterval(t); }, [loc.pathname]);

  const Side = () => (
    <nav className="flex flex-col h-full" aria-label="Admin navigation">
      <div className="p-5 border-b border-slate-200 flex items-center justify-between"><Link to="/admin"><img src="/logo-header.png" alt="GES Global Trade" className="h-9 w-auto" /></Link><button className="lg:hidden p-2" onClick={() => setOpen(false)} aria-label="Close menu"><X size={18} /></button></div>
      <p className="px-5 pt-5 pb-2 text-[10px] font-bold uppercase tracking-[0.2em] text-slate-400">Procurement Console</p>
      <div className="px-3 space-y-0.5">
        {NAV.map(([to, label, I]) => <NavLink key={to} to={`/admin/${to}`} end={to === ""} data-testid={`admin-nav-${to || "dashboard"}`} className={({ isActive }) => `flex items-center gap-3 rounded-md px-3 py-2.5 text-sm font-semibold transition-colors ${isActive ? "bg-[#0A192F] text-white" : "text-slate-600 hover:bg-slate-100 hover:text-[#0A192F]"}`}><I size={17} />{label}{to === "notifications" && unread > 0 && <span className="ml-auto rounded-full bg-[#0369A1] text-white text-[10px] px-1.5 py-0.5" data-testid="admin-unread-badge">{unread}</span>}</NavLink>)}
      </div>
      <div className="mt-auto p-5 border-t border-slate-200 text-xs text-slate-500 space-y-2">
        <p className="flex items-start gap-2"><ShieldAlert size={14} className="text-amber-500 shrink-0 mt-0.5" />Authentication not enabled yet. Set ADMIN_API_KEY to gate this console until admin login is added.</p>
        <Link to="/" className="flex items-center gap-1 font-semibold text-[#0369A1]"><ExternalLink size={12} />View website</Link>
      </div>
    </nav>
  );

  return (
    <div className="min-h-screen bg-slate-50 lg:flex" data-testid="admin-layout">
      <Toaster position="top-right" richColors />
      <aside className="hidden lg:block w-[260px] shrink-0 bg-white border-r border-slate-200 sticky top-0 h-screen"><Side /></aside>
      {open && <div className="lg:hidden fixed inset-0 z-50"><div className="absolute inset-0 bg-[#0A192F]/60" onClick={() => setOpen(false)} /><div className="absolute inset-y-0 left-0 w-72 bg-white shadow-xl"><Side /></div></div>}
      <div className="flex-1 min-w-0">
        <header className="lg:hidden sticky top-0 z-40 bg-white border-b border-slate-200 h-14 flex items-center justify-between px-4"><button onClick={() => setOpen(true)} aria-label="Open menu" className="p-2" data-testid="admin-mobile-menu"><Menu size={20} /></button><img src="/logo-header.png" alt="GES" className="h-8" /><Link to="/admin/notifications" className="relative p-2"><Bell size={18} />{unread > 0 && <span className="absolute top-1 right-1 h-2 w-2 rounded-full bg-[#0369A1]" />}</Link></header>
        <main className="p-4 sm:p-6 lg:p-8 max-w-[1400px]">
          <Routes>
            <Route index element={<Dashboard />} />
            <Route path="enquiries" element={<Enquiries />} />
            <Route path="enquiries/:id" element={<EnquiryDetail />} />
            <Route path="customers" element={<Customers />} />
            <Route path="customers/:id" element={<Customers />} />
            <Route path="followups" element={<FollowUps />} />
            <Route path="notifications" element={<Notifications />} />
            <Route path="analytics" element={<Analytics />} />
            <Route path="settings" element={<SettingsPage />} />
          </Routes>
        </main>
      </div>
    </div>
  );
}
