import { useEffect, useState } from "react";
import { Link, useParams, useNavigate } from "react-router-dom";
import { ArrowRight, Building2 } from "lucide-react";
import { api } from "@/lib/api";
import { Seo, PageHero, Spinner, SectionHead } from "@/components/common";
import { IND_ICONS } from "@/components/home/Sections2";
import { ProductCard } from "@/pages/Products";
import { FinalCta } from "@/components/home/Sections2";

export default function Industries() {
  const { slug } = useParams();
  const nav = useNavigate();
  const [inds, setInds] = useState(null);
  const [prods, setProds] = useState(null);
  useEffect(() => { api.get("/catalog/industries").then((r) => setInds(r.data)); }, []);
  useEffect(() => { if (!slug) { setProds(null); return; } setProds(null); api.get("/catalog/products", { params: { industry: slug, limit: 12 } }).then((r) => setProds(r.data.items)); }, [slug]);
  if (!inds) return <Spinner />;
  const active = inds.find((i) => i.slug === slug);
  return (
    <>
      <Seo title={active ? `${active.name} — Industry Solutions` : "Industries We Serve"} description={active ? active.description : "Industrial supply and sourcing solutions for construction, manufacturing, infrastructure, utilities, agriculture, water, logistics, healthcare and commercial sectors."} />
      <PageHero compact eyebrow="Industries" title={active ? active.name : "Industries we serve"} lead={active ? active.description : "Select an industry to see related products and sourcing solutions."} image={active?.image} crumbs={active ? [{ label: "Industries", to: "/industries" }, { label: active.name }] : [{ label: "Industries" }]} />
      <section className="section !pt-10">
        <div className="container-x">
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2 mb-12" data-testid="industry-grid">
            {inds.map((x) => { const I = IND_ICONS[x.slug] || Building2; const on = x.slug === slug; return (
              <button key={x.slug} onClick={() => nav(on ? "/industries" : `/industries/${x.slug}`)} aria-pressed={on} className={`rounded-md border p-4 text-left text-sm font-semibold flex flex-col gap-2 transition-colors min-h-[84px] ${on ? "bg-[#0A192F] border-[#0A192F] text-white" : "border-slate-200 hover:border-[#0369A1] hover:text-[#0369A1]"}`} data-testid={`industry-btn-${x.slug}`}><I size={18} className={on ? "text-sky-300" : "text-[#0369A1]"} /><span className="leading-tight">{x.name}</span></button>
            ); })}
          </div>
          {active ? (
            <div className="grid lg:grid-cols-12 gap-10">
              <div className="lg:col-span-4">
                <SectionHead eyebrow="Related solutions" title={`Supply for ${active.name}`} lead={active.description} />
                <ul className="space-y-2">{active.categories.map((c) => <li key={c.slug}><Link to={`/products/${c.slug}`} className="flex items-center justify-between rounded-md border border-slate-200 px-4 py-3 text-sm font-semibold hover:border-[#0369A1] hover:text-[#0369A1] group">{c.name}<ArrowRight size={14} className="group-hover:translate-x-1 transition-transform" /></Link></li>)}</ul>
                <Link to={`/request-quote`} className="btn-primary mt-6 w-full" data-testid="industry-rfq-btn">Request a Quote for this industry</Link>
              </div>
              <div className="lg:col-span-8">{prods ? <div className="grid sm:grid-cols-2 xl:grid-cols-3 gap-4" data-testid="industry-products">{prods.map((p) => <ProductCard key={p.slug + p.category_slug} p={p} />)}</div> : <Spinner />}<Link to={`/products?industry=${active.slug}`} className="btn-outline mt-6">View all products for {active.name} <ArrowRight size={16} /></Link></div>
            </div>
          ) : (
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">{inds.map((x) => <Link key={x.slug} to={`/industries/${x.slug}`} className="card card-hover overflow-hidden group" data-testid={`industry-card-${x.slug}`}><div className="aspect-[16/9] overflow-hidden"><img src={x.image} alt={x.name} loading="lazy" className="h-full w-full object-cover group-hover:scale-105 transition-transform duration-500" /></div><div className="p-5"><h3 className="font-bold text-[#0A192F]">{x.name}</h3><p className="text-sm text-slate-600 mt-1">{x.description}</p><p className="text-xs text-[#0369A1] font-semibold mt-3">{x.categories.length} related categories →</p></div></Link>)}</div>
          )}
        </div>
      </section>
      <FinalCta />
    </>
  );
}
