import { useEffect, useState } from "react";
import { Link, useSearchParams } from "react-router-dom";
import { ArrowRight, Search, X } from "lucide-react";
import { api } from "@/lib/api";
import { Seo, PageHero, Spinner, Empty } from "@/components/common";
import { CategoryCard } from "@/components/home/Sections";

const ProductCard = ({ p }) => (
  <Link to={`/product/${p.slug}`} className="card card-hover overflow-hidden group" data-testid={`product-card-${p.slug}`}>
    <div className="aspect-[16/10] overflow-hidden"><img src={p.thumb} alt={p.name} loading="lazy" className="h-full w-full object-cover group-hover:scale-105 transition-transform duration-500" /></div>
    <div className="p-4"><p className="text-[11px] font-semibold uppercase tracking-wider text-[#0369A1]">{p.category_name}</p><h3 className="font-bold text-[#0A192F] mt-1 leading-snug">{p.name}</h3></div>
  </Link>
);
export { ProductCard };

export default function Products() {
  const [params, setParams] = useSearchParams();
  const q = params.get("q") || "", application = params.get("application") || "", industry = params.get("industry") || "", category = params.get("category") || "";
  const filtering = q || application || industry || category;
  const [cats, setCats] = useState(null);
  const [res, setRes] = useState(null);
  const [term, setTerm] = useState(q);
  const [apps, setApps] = useState([]);
  useEffect(() => { api.get("/catalog/categories").then((r) => setCats(r.data)); api.get("/catalog/applications").then((r) => setApps(r.data)); }, []);
  useEffect(() => { setTerm(q); if (!filtering) { setRes(null); return; } setRes(null); api.get("/catalog/products", { params: { q: q || undefined, application: application || undefined, industry: industry || undefined, category: category || undefined } }).then((r) => setRes(r.data)); }, [q, application, industry, category, filtering]);
  const submit = (e) => { e.preventDefault(); setParams(term.trim() ? { q: term.trim() } : {}); };

  return (
    <>
      <Seo title="Products & Categories" description="Searchable B2B product catalogue: electrical cables, steel, pipes & valves, pumps, generators, agriculture & irrigation, warehouse racking, material handling and more." />
      <PageHero compact eyebrow="Product Platform" title="Products & Categories" lead="A searchable B2B catalogue across 21 industrial supply categories. Every line is available on request for quotation — and anything not listed can still be sourced." crumbs={[{ label: "Products" }]} />
      <section className="bg-white border-b border-slate-200 sticky top-16 lg:top-[108px] z-20">
        <div className="container-x py-3 flex flex-col md:flex-row gap-3 md:items-center">
          <form onSubmit={submit} className="flex-1 flex gap-2" role="search">
            <div className="relative flex-1"><Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" /><input value={term} onChange={(e) => setTerm(e.target.value)} placeholder="Search products, e.g. submersible pump, pallet racking, XLPE cable" className="input pl-9" data-testid="products-search-input" aria-label="Search products" /></div>
            <button className="btn-primary" data-testid="products-search-btn">Search</button>
          </form>
          <select value={application} onChange={(e) => setParams(e.target.value ? { application: e.target.value } : {})} className="input md:w-60" aria-label="Filter by application" data-testid="products-application-filter"><option value="">All applications</option>{apps.map((a) => <option key={a.slug} value={a.slug}>{a.name}</option>)}</select>
          {filtering && <button onClick={() => setParams({})} className="btn-outline btn-sm" data-testid="products-clear-btn"><X size={14} />Clear</button>}
        </div>
      </section>
      <section className="section">
        <div className="container-x">
          {!filtering && (cats ? <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4" data-testid="categories-grid">{cats.map((c) => <CategoryCard key={c.slug} c={c} />)}</div> : <Spinner />)}
          {filtering && !res && <Spinner />}
          {filtering && res && (
            <>
              <p className="text-sm text-slate-600 mb-6" data-testid="products-result-count"><span className="font-semibold text-[#0A192F]">{res.total}</span> product lines found{q && <> for "<span className="font-semibold">{q}</span>"</>}</p>
              {res.total > 0 ? <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4" data-testid="products-grid">{res.items.map((p) => <ProductCard key={p.slug + p.category_slug} p={p} />)}</div> : (
                <div className="rounded-xl border border-sky-200 bg-sky-50 p-10 md:p-14 text-center" data-testid="products-no-results">
                  <h2 className="h2">Can't Find What You're Looking For?</h2>
                  <p className="lead mt-3">Tell us what you need. We'll work on the sourcing.</p>
                  <Link to={`/request-product?product=${encodeURIComponent(q)}`} className="btn-primary mt-6" data-testid="products-request-product-btn">Request a Product <ArrowRight size={16} /></Link>
                </div>
              )}
            </>
          )}
          {filtering && res && res.total > 0 && <div className="mt-12 card p-6 md:p-8 flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-50"><div><h3 className="h3">Need something not shown here?</h3><p className="text-slate-600 text-sm mt-1">Send the details and we'll review suitable sourcing options.</p></div><Link to="/request-product" className="btn-navy shrink-0">Request a Product</Link></div>}
        </div>
      </section>
    </>
  );
}
