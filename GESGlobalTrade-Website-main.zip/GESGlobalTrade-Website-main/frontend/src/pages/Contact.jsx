import { Link } from "react-router-dom";
import { Mail, MessageCircle, FileText, Globe } from "lucide-react";
import { Seo, PageHero } from "@/components/common";
import { SITE, waLink } from "@/lib/site";

export default function Contact() {
  return (
    <>
      <Seo title="Contact GES Global Trade" description="Contact Global Environmental Services & Trading SPC (GES Global Trade), Oman & GCC. Email info@GESGlobalTrade.com or WhatsApp +971 52 228 2043." />
      <PageHero compact eyebrow="Contact" title="Talk to our trading & sourcing team." lead="Reach us by email or WhatsApp, or submit a structured requirement and receive a reference number instantly." crumbs={[{ label: "Contact" }]} />
      <section className="section">
        <div className="container-x grid lg:grid-cols-12 gap-10">
          <div className="lg:col-span-5">
            <img src="/logo.png" alt="GES Global Trade" className="h-24 w-auto" />
            <h2 className="h3 mt-6" data-testid="contact-legal-name">{SITE.legalName}</h2>
            <p className="text-slate-700 font-semibold">{SITE.brand}</p>
            <p className="text-slate-600 flex items-center gap-2 mt-1"><Globe size={15} className="text-[#0369A1]" />{SITE.region}</p>
            <dl className="mt-8 space-y-4 text-sm">
              <div><dt className="text-xs font-bold uppercase tracking-wider text-slate-500">Email</dt><dd><a href={`mailto:${SITE.email}`} className="font-semibold text-[#0A192F] hover:text-[#0369A1]" data-testid="contact-email-link">{SITE.email}</a></dd></div>
              <div><dt className="text-xs font-bold uppercase tracking-wider text-slate-500">Phone / WhatsApp</dt><dd><a href={waLink()} className="font-semibold text-[#0A192F] hover:text-[#0369A1]" data-testid="contact-phone-link">{SITE.phone}</a></dd></div>
              <div><dt className="text-xs font-bold uppercase tracking-wider text-slate-500">Website</dt><dd className="font-semibold text-[#0A192F]">{SITE.domain}</dd></div>
            </dl>
            <p className="text-xs text-slate-500 mt-8">Company registration and relevant business documentation are available upon request.</p>
          </div>
          <div className="lg:col-span-7 grid sm:grid-cols-3 gap-4 content-start">
            <a href={`mailto:${SITE.email}`} className="card card-hover p-6" data-testid="contact-email-btn"><Mail className="text-[#0369A1]" /><h3 className="font-bold mt-4 text-[#0A192F]">Email Us</h3><p className="text-sm text-slate-600 mt-1">For detailed enquiries, documents and correspondence.</p></a>
            <a href={waLink()} target="_blank" rel="noopener noreferrer" className="card card-hover p-6" data-testid="contact-whatsapp-btn"><MessageCircle className="text-[#059669]" /><h3 className="font-bold mt-4 text-[#0A192F]">WhatsApp</h3><p className="text-sm text-slate-600 mt-1">Quick questions and product enquiries.</p></a>
            <Link to="/request-quote" className="card card-hover p-6 bg-[#0A192F] border-[#0A192F]" data-testid="contact-rfq-btn"><FileText className="text-sky-300" /><h3 className="font-bold mt-4 text-white">Request a Quote</h3><p className="text-sm text-slate-300 mt-1">Structured RFQ / BOQ submission with document upload.</p></Link>
            <div className="sm:col-span-3 card p-6 bg-sky-50 border-sky-200"><h3 className="font-bold text-[#0A192F]">If you don't see it, ask us.</h3><p className="text-sm text-slate-600 mt-1">Can't find what you need? We can still work on the sourcing. <Link to="/request-product" className="font-semibold text-[#0369A1]">Request a Product →</Link></p></div>
          </div>
        </div>
      </section>
    </>
  );
}
