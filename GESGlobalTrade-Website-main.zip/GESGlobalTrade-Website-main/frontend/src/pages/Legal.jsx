import { Seo, PageHero } from "@/components/common";
import { SITE } from "@/lib/site";

const PRIVACY = [
  ["Information we collect", "When you submit an enquiry, RFQ, product request or business enquiry, we collect the information you provide, such as your name, company, country, email, phone / WhatsApp number, requirement details and any documents you upload."],
  ["How we use information", "Information is used solely to review your requirement, identify suitable sourcing options, prepare quotations, coordinate supply and communicate with you about your enquiry. We may keep records of previous enquiries to serve repeat customers more effectively."],
  ["Uploaded documents", "Uploaded documents (RFQs, BOQs, drawings, specifications, images) are stored privately in secured storage and are accessible only to authorised GES Global Trade personnel. Documents are never published or exposed through public links."],
  ["Sharing", "We do not sell personal information. Requirement details may be shared with supply channels only to the extent necessary to obtain sourcing and quotation information, without disclosing more than required."],
  ["Retention and access", "Records are retained for as long as reasonably necessary for business, legal and accounting purposes. You may request access to, correction of or deletion of your information by contacting us."],
  ["Contact", `For privacy questions, contact ${SITE.legalName} at ${SITE.email}.`],
];
const TERMS = [
  ["Nature of services", `${SITE.legalName} (trading as ${SITE.brand}) is a trading, sourcing, procurement support and industrial supply company. Unless explicitly stated in writing, GES Global Trade does not act as a manufacturer, exclusive distributor or authorised dealer of any product.`],
  ["Enquiries and quotations", "Submission of an enquiry, RFQ, BOQ or product request does not constitute an order or a commitment by either party. Any quotation issued is subject to the terms stated in that quotation, including validity, pricing, availability and delivery conditions."],
  ["Product information", "Product information on this website is indicative and describes categories of products that may be sourced and supplied on request. Specifications, configurations and availability are confirmed on a case-by-case basis according to the customer's requirement. No certification, standard or compliance claim is made unless confirmed in writing."],
  ["Documents", "Customers are responsible for ensuring that they have the right to share any uploaded documents. Uploaded files are used only to evaluate the customer's requirement."],
  ["Website use", "Content on this website may not be copied or reused without permission. We aim to keep information accurate but do not warrant that all content is complete or error-free."],
  ["Governing law", "These terms are governed by the applicable laws of the Sultanate of Oman unless otherwise agreed in writing."],
  ["Contact", `Questions about these terms may be sent to ${SITE.email}.`],
];

export default function Legal({ kind }) {
  const privacy = kind === "privacy";
  const items = privacy ? PRIVACY : TERMS;
  return (
    <>
      <Seo title={privacy ? "Privacy Policy" : "Terms & Conditions"} description={privacy ? "How GES Global Trade handles enquiry information and uploaded documents." : "Terms and conditions for use of GESGlobalTrade.com and enquiry services."} />
      <PageHero compact eyebrow="Legal" title={privacy ? "Privacy Policy" : "Terms & Conditions"} crumbs={[{ label: privacy ? "Privacy Policy" : "Terms & Conditions" }]} />
      <section className="section"><div className="container-x max-w-3xl space-y-8" data-testid="legal-content">
        {items.map(([h, t]) => <div key={h}><h2 className="h3">{h}</h2><p className="text-slate-600 mt-2 leading-relaxed">{t}</p></div>)}
      </div></section>
    </>
  );
}
