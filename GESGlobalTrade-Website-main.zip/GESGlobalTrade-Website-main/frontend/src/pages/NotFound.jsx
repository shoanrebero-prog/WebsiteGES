import { Link } from "react-router-dom";
import { Seo } from "@/components/common";

export default function NotFound() {
  return (
    <section className="section text-center" data-testid="not-found">
      <Seo title="Page not found" />
      <div className="container-x max-w-xl">
        <span className="mono text-[#0369A1]">404</span>
        <h1 className="h2 mt-3">We couldn't find that page.</h1>
        <p className="lead mt-3">The product or page may have moved. You can still tell us what you need and we'll work on the sourcing.</p>
        <div className="mt-7 flex justify-center gap-3"><Link to="/products" className="btn-outline">Browse products</Link><Link to="/request-product" className="btn-primary">Request a Product</Link></div>
      </div>
    </section>
  );
}
