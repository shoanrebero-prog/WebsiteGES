import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { ArrowRight } from "lucide-react";
import { api } from "@/lib/api";
import { Seo, SectionHead } from "@/components/common";
import { Hero } from "@/components/home/Hero";
import { Capabilities, WhyGes } from "@/components/home/Capabilities";
import { CategoriesSection, FeaturedSolutions, WarehouseFeature, RequestProductBand, SourcingProcess } from "@/components/home/Sections";
import { IndustriesSection, ApplicationsSection, HowWeWorkSteps, FinalCta, ContactStrip } from "@/components/home/Sections2";

export default function Home() {
  const [cats, setCats] = useState([]);
  const [inds, setInds] = useState([]);
  const [apps, setApps] = useState([]);
  useEffect(() => {
    api.get("/catalog/categories").then((r) => setCats(r.data)).catch(() => {});
    api.get("/catalog/industries").then((r) => setInds(r.data)).catch(() => {});
    api.get("/catalog/applications").then((r) => setApps(r.data)).catch(() => {});
  }, []);
  return (
    <>
      <Seo title={null} description="GES Global Trade — Oman & GCC-based international trading, global sourcing, industrial supply and project supply. Tell us what you need. We source the right solution." />
      <Hero />
      <Capabilities />
      <CategoriesSection categories={cats} />
      <FeaturedSolutions categories={cats} />
      <WarehouseFeature />
      <RequestProductBand />
      <IndustriesSection industries={inds} />
      <section className="section bg-slate-50 border-y border-slate-200" data-testid="home-sourcing">
        <div className="container-x">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
            <SectionHead eyebrow="Global Sourcing" title="Global Sourcing. One Reliable Point of Coordination." lead="From requirement analysis to supply coordination — a structured process for sourcing through international supply channels." />
            <Link to="/global-sourcing" className="btn-outline mb-10 md:mb-14 shrink-0">About our sourcing process <ArrowRight size={16} /></Link>
          </div>
          <SourcingProcess compact />
        </div>
      </section>
      <section className="section bg-white" data-testid="home-project-supply">
        <div className="container-x grid lg:grid-cols-2 gap-10 items-center">
          <img src="https://images.unsplash.com/photo-1504307651254-35680f356dfd?auto=format&fit=crop&w=1000&q=70" alt="Construction project site" loading="lazy" className="rounded-lg border border-slate-200 aspect-[4/3] object-cover w-full" />
          <div>
            <span className="eyebrow">Bulk &amp; Project Supply</span>
            <h2 className="h2 mt-3">From Single Requirements to Complete Project Supply</h2>
            <p className="lead mt-4">BOQ sourcing, bulk procurement, project materials, industrial equipment, electrical, water &amp; irrigation, warehouse systems and environmental solutions — coordinated as one requirement.</p>
            <ul className="mt-5 grid grid-cols-2 gap-2 text-sm text-slate-700">{["BOQ sourcing", "Bulk procurement", "Project materials", "Industrial equipment", "Construction materials", "Electrical requirements", "Water & irrigation", "Warehouse systems"].map((x) => <li key={x} className="flex items-center gap-2"><span className="h-1.5 w-1.5 rounded-full bg-[#0369A1]" />{x}</li>)}</ul>
            <div className="mt-7 flex flex-wrap gap-3"><Link to="/request-quote?type=project" className="btn-primary" data-testid="home-project-cta">Submit Project Requirement <ArrowRight size={16} /></Link><Link to="/project-supply" className="btn-outline">Learn more</Link></div>
          </div>
        </div>
      </section>
      <ApplicationsSection applications={apps} />
      <section className="section bg-white" data-testid="home-how-we-work">
        <div className="container-x">
          <SectionHead eyebrow="How We Work" title="A clear five-step process from requirement to supply." />
          <HowWeWorkSteps />
        </div>
      </section>
      <WhyGes />
      <FinalCta />
      <ContactStrip />
    </>
  );
}
