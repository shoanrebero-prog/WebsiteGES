import { lazy, Suspense } from "react";
import { BrowserRouter, Routes, Route, Outlet, useLocation } from "react-router-dom";
import { useEffect } from "react";
import { Toaster } from "sonner";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { WhatsAppFloat } from "@/components/layout/WhatsAppFloat";
import { Spinner } from "@/components/common";
import Home from "@/pages/Home";

const lazyPage = (p) => lazy(() => import(`@/pages/${p}`));
const About = lazyPage("About"), Products = lazyPage("Products"), Category = lazyPage("Category"), ProductDetail = lazyPage("ProductDetail"),
  Industries = lazyPage("Industries"), GlobalSourcing = lazyPage("GlobalSourcing"), ProjectSupply = lazyPage("ProjectSupply"),
  WarehouseSolutions = lazyPage("WarehouseSolutions"), HowWeWork = lazyPage("HowWeWork"), RequestProduct = lazyPage("RequestProduct"),
  RequestQuote = lazyPage("RequestQuote"), BusinessEnquiry = lazyPage("BusinessEnquiry"), Contact = lazyPage("Contact"),
  EnquiryStatus = lazyPage("EnquiryStatus"), Legal = lazyPage("Legal"), ThankYou = lazyPage("ThankYou"), NotFound = lazyPage("NotFound");
const Admin = lazy(() => import("@/pages/admin/Admin"));

const ScrollTop = () => { const { pathname } = useLocation(); useEffect(() => { window.scrollTo(0, 0); }, [pathname]); return null; };

const PublicLayout = () => (
  <div className="min-h-screen flex flex-col">
    <Header />
    <main className="flex-1"><Suspense fallback={<Spinner />}><Outlet /></Suspense></main>
    <Footer />
    <WhatsAppFloat />
  </div>
);

export default function App() {
  return (
    <BrowserRouter>
      <ScrollTop />
      <Toaster position="top-right" richColors closeButton />
      <Routes>
        <Route element={<PublicLayout />}>
          <Route path="/" element={<Home />} />
          <Route path="/about" element={<About />} />
          <Route path="/products" element={<Products />} />
          <Route path="/products/:slug" element={<Category />} />
          <Route path="/product/:slug" element={<ProductDetail />} />
          <Route path="/industries" element={<Industries />} />
          <Route path="/industries/:slug" element={<Industries />} />
          <Route path="/global-sourcing" element={<GlobalSourcing />} />
          <Route path="/project-supply" element={<ProjectSupply />} />
          <Route path="/warehouse-solutions" element={<WarehouseSolutions />} />
          <Route path="/how-we-work" element={<HowWeWork />} />
          <Route path="/request-product" element={<RequestProduct />} />
          <Route path="/request-quote" element={<RequestQuote />} />
          <Route path="/business-enquiry" element={<BusinessEnquiry />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/enquiry-status" element={<EnquiryStatus />} />
          <Route path="/privacy-policy" element={<Legal kind="privacy" />} />
          <Route path="/terms" element={<Legal kind="terms" />} />
          <Route path="/thank-you/:reference" element={<ThankYou />} />
          <Route path="*" element={<NotFound />} />
        </Route>
        <Route path="/admin/*" element={<Suspense fallback={<Spinner />}><Admin /></Suspense>} />
      </Routes>
    </BrowserRouter>
  );
}
