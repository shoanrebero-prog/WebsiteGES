import { useEffect } from "react";
import { Link } from "react-router-dom";
import { ChevronRight } from "lucide-react";
import { setSeo } from "@/lib/site";

export const Seo = ({ title, description }) => { useEffect(() => { setSeo(title, description); }, [title, description]); return null; };

export const SectionHead = ({ eyebrow, title, lead, align = "left", light, children }) => (
  <div className={`max-w-3xl ${align === "center" ? "mx-auto text-center" : ""} mb-10 md:mb-14`}>
    {eyebrow && <span className={`eyebrow ${light ? "text-sky-300 before:bg-sky-300" : ""} ${align === "center" ? "justify-center before:hidden" : ""}`}>{eyebrow}</span>}
    <h2 className={`h2 mt-3 ${light ? "text-white" : ""}`}>{title}</h2>
    {lead && <p className={`lead mt-4 ${light ? "text-slate-300" : ""}`}>{lead}</p>}
    {children}
  </div>
);

export const Breadcrumbs = ({ items }) => (
  <nav aria-label="Breadcrumb" className="text-xs text-slate-500 flex flex-wrap items-center gap-1" data-testid="breadcrumbs">
    <Link to="/" className="hover:text-[#0369A1]">Home</Link>
    {items.map((it, i) => (
      <span key={i} className="flex items-center gap-1"><ChevronRight size={12} />{it.to ? <Link to={it.to} className="hover:text-[#0369A1]">{it.label}</Link> : <span className="text-slate-700 font-medium">{it.label}</span>}</span>
    ))}
    <script type="application/ld+json">{JSON.stringify({ "@context": "https://schema.org", "@type": "BreadcrumbList", itemListElement: [{ "@type": "ListItem", position: 1, name: "Home", item: "https://GESGlobalTrade.com/" }, ...items.map((it, i) => ({ "@type": "ListItem", position: i + 2, name: it.label, ...(it.to ? { item: `https://GESGlobalTrade.com${it.to}` } : {}) }))] })}</script>
  </nav>
);

export const PageHero = ({ eyebrow, title, lead, image, crumbs, children, compact }) => (
  <section className={`relative bg-[#0A192F] text-white overflow-hidden ${compact ? "py-14 md:py-20" : "py-20 md:py-28"}`}>
    {image && <img src={image} alt="" aria-hidden className="absolute inset-0 h-full w-full object-cover opacity-25" loading="eager" />}
    <div className="absolute inset-0 bg-gradient-to-r from-[#0A192F] via-[#0A192F]/85 to-[#0A192F]/40" />
    <div className="absolute inset-0 dot-grid opacity-40" />
    <div className="container-x relative">
      {crumbs && <div className="mb-6 [&_a]:text-slate-300 [&_span]:text-slate-300 [&_nav]:text-slate-400"><Breadcrumbs items={crumbs} /></div>}
      {eyebrow && <span className="eyebrow text-sky-300 before:bg-sky-300 rise">{eyebrow}</span>}
      <h1 className="h1 text-white mt-4 max-w-4xl rise d1">{title}</h1>
      {lead && <p className="lead text-slate-300 mt-5 max-w-2xl rise d2">{lead}</p>}
      {children && <div className="mt-8 flex flex-wrap gap-3 rise d3">{children}</div>}
    </div>
  </section>
);

export const Empty = ({ title, text, testId }) => (
  <div className="rounded-lg border border-dashed border-slate-300 bg-slate-50 p-10 text-center" data-testid={testId || "empty-state"}>
    <p className="font-semibold text-[#0A192F]">{title}</p>
    {text && <p className="text-sm text-slate-500 mt-1">{text}</p>}
  </div>
);

export const Spinner = () => <div className="flex justify-center py-16"><div className="h-8 w-8 rounded-full border-2 border-slate-200 border-t-[#0369A1] animate-spin" /></div>;
