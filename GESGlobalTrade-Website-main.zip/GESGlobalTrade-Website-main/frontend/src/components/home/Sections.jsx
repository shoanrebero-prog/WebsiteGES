import { Link } from "react-router-dom";
import { ArrowRight, Warehouse, ClipboardList, FileSearch, Ruler, Route, Coins, FileCheck2, Truck } from "lucide-react";
import { SectionHead } from "@/components/common";

export const CategoryCard = ({ c, compact }) => (
  <Link to={`/products/${c.slug}`} className="card card-hover overflow-hidden group flex flex-col" data-testid={`category-card-${c.slug}`}>
    <div className={`relative overflow-hidden ${compact ? "aspect-[16/9]" : "aspect-[4/3]"}`}>
      <img src={c.thumb} alt={c.name} loading="lazy" className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105" />
      <span className="absolute left-3 top-3 mono text-[11px] font-medium bg-white/95 text-[#0A192F] px-2 py-0.5 rounded">{c.code}</span>
    </div>
    <div className="p-5 flex-1 flex flex-col">
      <h3 className="font-bold text-[#0A192F] leading-snug group-hover:text-[#0369A1] transition-colors">{c.name}</h3>
      <p className="text-sm text-slate-600 mt-1.5 line-clamp-2">{c.tagline}</p>
      <div className="mt-auto pt-4 flex items-center justify-between text-xs text-slate-500"><span>{c.product_count} product lines</span><ArrowRight size={14} className="text-[#0369A1] group-hover:translate-x-1 transition-transform" /></div>
    </div>
  </Link>
);

export const CategoriesSection = ({ categories }) => (
  <section className="section bg-slate-50 border-y border-slate-200" data-testid="categories-section">
    <div className="container-x">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-10">
        <SectionHead eyebrow="Product Platform" title="Industrial product categories" lead="Browse our sourcing and supply categories. Every product page leads to a quotation request — and anything not listed can still be sourced." />
        <Link to="/products" className="btn-outline shrink-0 mb-10 md:mb-14" data-testid="view-all-categories-btn">View all categories <ArrowRight size={16} /></Link>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {categories.filter((c) => !c.featured).slice(0, 8).map((c) => <CategoryCard key={c.slug} c={c} compact />)}
      </div>
    </div>
  </section>
);

export const FeaturedSolutions = ({ categories }) => {
  const picks = ["water-pumps-pumping-solutions", "generators-power-solutions", "electrical-wires-cables", "agriculture-irrigation-garden", "steel-metal-products", "environmental-water-treatment"].map((s) => categories.find((c) => c.slug === s)).filter(Boolean);
  return (
    <section className="section bg-white" data-testid="featured-section">
      <div className="container-x">
        <SectionHead eyebrow="Featured Industrial Solutions" title="Frequently requested supply lines" lead="Products commonly requested by contractors, industrial facilities, farms, utilities and distributors across the region." />
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {picks.map((c) => (
            <Link key={c.slug} to={`/products/${c.slug}`} className="relative overflow-hidden rounded-lg aspect-[16/10] group border border-slate-200" data-testid={`featured-${c.slug}`}>
              <img src={c.thumb} alt={c.name} loading="lazy" className="absolute inset-0 h-full w-full object-cover transition-transform duration-700 group-hover:scale-105" />
              <div className="absolute inset-0 bg-gradient-to-t from-[#0A192F] via-[#0A192F]/40 to-transparent" />
              <div className="absolute inset-x-0 bottom-0 p-5 text-white">
                <h3 className="font-bold text-lg leading-snug">{c.name}</h3>
                <p className="text-xs text-slate-300 mt-1">{c.subcategories.slice(0, 4).map((s) => s.name).join(" · ")}</p>
                <span className="mt-3 inline-flex items-center gap-1 text-sm font-semibold text-sky-300">Explore <ArrowRight size={14} className="group-hover:translate-x-1 transition-transform" /></span>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
};

export const WarehouseFeature = () => (
  <section className="section bg-[#0A192F] text-white relative overflow-hidden" data-testid="warehouse-section">
    <div className="absolute inset-0 dot-grid opacity-30" />
    <div className="container-x relative grid lg:grid-cols-2 gap-12 items-center">
      <div>
        <span className="eyebrow text-sky-300 before:bg-sky-300">Strategic Category</span>
        <h2 className="h2 text-white mt-3">Warehouse, Storage &amp; Material Handling Solutions</h2>
        <p className="text-sky-200 font-semibold mt-3">Smart Storage. Efficient Handling. Reliable Supply.</p>
        <p className="lead text-slate-300 mt-4">Professional storage, racking and material-handling solutions for warehouses, industrial facilities, offices, healthcare, logistics and commercial environments.</p>
        <ul className="mt-6 grid sm:grid-cols-2 gap-2.5 text-sm text-slate-200">
          {["Pallet & Cantilever Racking", "Mezzanine Systems", "Industrial & Archive Shelving", "Forklifts, Stackers & Reach Trucks", "Hospital & Museum Storage", "Dock Shelters & Loading Bays"].map((x) => <li key={x} className="flex items-center gap-2"><Warehouse size={14} className="text-sky-400 shrink-0" />{x}</li>)}
        </ul>
        <div className="mt-8 flex flex-wrap gap-3">
          <Link to="/warehouse-solutions" className="btn-primary" data-testid="warehouse-explore-btn">Explore Warehouse Solutions <ArrowRight size={16} /></Link>
          <Link to="/request-quote?type=warehouse" className="btn-ghost-light" data-testid="warehouse-rfq-btn">Send Your Layout / BOQ</Link>
        </div>
      </div>
      <div className="grid grid-cols-2 gap-3">
        <img src="https://images.unsplash.com/photo-1592085198739-ffcad7f36b54?auto=format&fit=crop&w=700&q=70" alt="Pallet racking in a warehouse" loading="lazy" className="rounded-lg object-cover aspect-[3/4] w-full border border-white/10" />
        <img src="https://images.unsplash.com/photo-1740914994657-f1cdffdc418e?auto=format&fit=crop&w=700&q=70" alt="Forklift material handling" loading="lazy" className="rounded-lg object-cover aspect-[3/4] w-full border border-white/10 mt-8" />
      </div>
    </div>
  </section>
);

export const RequestProductBand = () => (
  <section className="section bg-white" data-testid="request-product-band">
    <div className="container-x">
      <div className="rounded-xl border border-sky-200 bg-sky-50 p-8 md:p-12 grid lg:grid-cols-12 gap-8 items-center relative overflow-hidden">
        <div className="absolute -right-10 -top-10 h-56 w-56 rounded-full border-[24px] border-[#0369A1]/10" aria-hidden />
        <div className="lg:col-span-8 relative">
          <span className="eyebrow">If you don't see it, ask us.</span>
          <h2 className="h2 mt-3">Can't find what you need? We can still work on the sourcing.</h2>
          <p className="lead mt-4">Your requirement doesn't have to be listed in our catalogue. Send us the product name, specification, quantity and delivery location — our team reviews suitable sourcing options through international supply channels.</p>
        </div>
        <div className="lg:col-span-4 flex flex-col gap-3 relative">
          <Link to="/request-product" className="btn-primary" data-testid="band-request-product-btn">Request a Product <ArrowRight size={16} /></Link>
          <Link to="/request-quote" className="btn-outline" data-testid="band-rfq-btn">Have a BOQ? Send it to us.</Link>
        </div>
      </div>
    </div>
  </section>
);

export const SOURCING_STEPS = [
  [ClipboardList, "Requirement Analysis", "Understand the customer's requirement."],
  [FileSearch, "Product Identification", "Identify suitable product options."],
  [Ruler, "Specification Matching", "Review technical requirements."],
  [Route, "Supply Channel Evaluation", "Identify suitable international supply channels."],
  [Coins, "Commercial Evaluation", "Review commercial requirements."],
  [FileCheck2, "Quotation Coordination", "Coordinate suitable quotation options."],
  [Truck, "Supply Coordination", "Support the supply process."],
];

export const SourcingProcess = ({ compact }) => (
  <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4" data-testid="sourcing-process">
    {SOURCING_STEPS.map(([I, t, d], i) => (
      <div key={t} className={`card p-5 relative ${i === 6 ? "lg:col-span-1 bg-[#0A192F] border-[#0A192F] text-white" : ""}`}>
        <span className={`mono text-xs ${i === 6 ? "text-sky-300" : "text-[#0369A1]"}`}>0{i + 1}</span>
        <I size={20} className={`mt-3 ${i === 6 ? "text-sky-300" : "text-[#0A192F]"}`} />
        <h3 className={`font-bold mt-3 ${i === 6 ? "text-white" : "text-[#0A192F]"}`}>{t}</h3>
        {!compact && <p className={`text-sm mt-1 ${i === 6 ? "text-slate-300" : "text-slate-600"}`}>{d}</p>}
      </div>
    ))}
  </div>
);
