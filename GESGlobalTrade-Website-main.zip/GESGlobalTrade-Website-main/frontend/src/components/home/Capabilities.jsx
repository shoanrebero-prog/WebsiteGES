import { Link } from "react-router-dom";
import { Globe2, Factory, Ship, Boxes, Search, ArrowRight, ShieldCheck, Scale, BadgeCheck, Layers, MessagesSquare, Handshake } from "lucide-react";
import { SectionHead } from "@/components/common";

const CAPS = [
  { icon: Globe2, t: "Global Sourcing", d: "Identify suitable products and supply channels according to customer requirements.", to: "/global-sourcing" },
  { icon: Factory, t: "Industrial Supply", d: "Industrial products and equipment for commercial and project requirements.", to: "/products" },
  { icon: Ship, t: "Import & Export", d: "Coordinate international sourcing and supply requirements.", to: "/global-sourcing" },
  { icon: Boxes, t: "Bulk & Project Supply", d: "Support large-volume, BOQ and project-based requirements.", to: "/project-supply" },
  { icon: Search, t: "Custom Product Sourcing", d: "If it isn't listed, tell us what you need.", to: "/request-product", accent: true },
];

export const Capabilities = () => (
  <section className="section bg-white" data-testid="capabilities-section">
    <div className="container-x">
      <div className="grid lg:grid-cols-12 gap-10">
        <div className="lg:col-span-4"><SectionHead eyebrow="Core Capabilities" title="One partner for trading, sourcing and industrial supply." lead="GES Global Trade supports businesses across Oman, the GCC and international markets with structured sourcing and supply coordination." /></div>
        <div className="lg:col-span-8 grid sm:grid-cols-2 gap-4">
          {CAPS.map(({ icon: I, t, d, to, accent }, i) => (
            <Link to={to} key={t} className={`card card-hover p-6 group ${accent ? "bg-[#0A192F] border-[#0A192F] text-white sm:col-span-2 flex flex-col sm:flex-row sm:items-center gap-5" : ""}`} data-testid={`capability-${i}`}>
              <div className={`h-11 w-11 rounded-md flex items-center justify-center shrink-0 ${accent ? "bg-white/10 text-sky-300" : "bg-sky-50 text-[#0369A1] group-hover:bg-[#0369A1] group-hover:text-white transition-colors"}`}><I size={22} /></div>
              <div className="flex-1">
                <h3 className={`font-bold text-lg mt-4 sm:mt-0 ${accent ? "text-white" : "text-[#0A192F]"}`}>{t}</h3>
                <p className={`text-sm mt-1.5 leading-relaxed ${accent ? "text-slate-300" : "text-slate-600"}`}>{d}</p>
              </div>
              <ArrowRight size={18} className={`${accent ? "text-sky-300" : "text-slate-300 group-hover:text-[#0369A1]"} group-hover:translate-x-1 transition-transform mt-3 sm:mt-0`} />
            </Link>
          ))}
        </div>
      </div>
    </div>
  </section>
);

const WHY = [
  [ShieldCheck, "Reliable Sourcing", "Suitable sourcing options based on customer requirements."],
  [Scale, "Competitive Solutions", "Focus on commercially suitable options."],
  [BadgeCheck, "Quality Focus", "Attention to specifications and requirements."],
  [Layers, "Flexible Supply", "Support different order sizes and requirements."],
  [MessagesSquare, "Professional Coordination", "Structured communication and enquiry handling."],
  [Handshake, "Long-Term Partnerships", "Focus on professional business relationships."],
];

export const WhyGes = () => (
  <section className="section bg-slate-50 border-y border-slate-200" data-testid="why-section">
    <div className="container-x">
      <SectionHead eyebrow="Why GES Global Trade" title="Built around your requirement, not a fixed catalogue." />
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-px bg-slate-200 border border-slate-200 rounded-lg overflow-hidden">
        {WHY.map(([I, t, d]) => (
          <div key={t} className="bg-white p-7 hover:bg-sky-50/60 transition-colors group">
            <I size={22} className="text-[#0369A1]" />
            <h3 className="font-bold text-[#0A192F] mt-4">{t}</h3>
            <p className="text-sm text-slate-600 mt-1.5 leading-relaxed">{d}</p>
          </div>
        ))}
      </div>
    </div>
  </section>
);
