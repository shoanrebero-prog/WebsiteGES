import { Link } from "react-router-dom";
import { ArrowRight } from "lucide-react";

const HERO = "https://images.unsplash.com/photo-1494412651409-8963ce7935a7?auto=format&fit=crop&w=1600&q=70";

const Routes = () => (
  <svg viewBox="0 0 800 400" className="absolute inset-0 h-full w-full" aria-hidden preserveAspectRatio="xMidYMid slice">
    <defs><linearGradient id="g" x1="0" x2="1"><stop offset="0" stopColor="#38BDF8" stopOpacity="0" /><stop offset=".5" stopColor="#38BDF8" /><stop offset="1" stopColor="#38BDF8" stopOpacity="0" /></linearGradient></defs>
    {[["M120 300 Q 300 60 520 190", 0], ["M520 190 Q 640 120 760 80", 0.6], ["M120 300 Q 380 380 700 300", 1.1], ["M520 190 Q 560 300 700 300", 1.6]].map(([d, delay], i) => (
      <path key={i} d={d} fill="none" stroke="url(#g)" strokeWidth="1.5" className="route-line" style={{ animationDelay: `${delay}s` }} />
    ))}
    {[[120, 300], [520, 190], [760, 80], [700, 300]].map(([x, y], i) => (
      <g key={i}><circle cx={x} cy={y} r="4" fill="#38BDF8" /><circle cx={x} cy={y} r="9" fill="none" stroke="#38BDF8" strokeOpacity=".5" className="node-dot" style={{ animationDelay: `${i * 0.5}s` }} /></g>
    ))}
  </svg>
);

export const Hero = () => (
  <section className="relative bg-[#0A192F] text-white overflow-hidden" data-testid="hero">
    <img src={HERO} alt="Container port and international logistics operations" className="absolute inset-0 h-full w-full object-cover opacity-30 scale-105 will-change-transform" fetchPriority="high" />
    <div className="absolute inset-0 bg-gradient-to-r from-[#0A192F] via-[#0A192F]/90 to-[#0A192F]/30" />
    <div className="absolute inset-0 dot-grid opacity-30" />
    <div className="absolute inset-y-0 right-0 w-full lg:w-3/5 opacity-70 pointer-events-none"><Routes /></div>
    <div className="container-x relative py-24 md:py-32 lg:py-40">
      <span className="eyebrow text-sky-300 before:bg-sky-300 rise">Oman &amp; GCC-based. Globally connected.</span>
      <h1 className="h1 text-white mt-5 max-w-4xl rise d1">Connecting Markets.<br />Creating Reliable Supply.</h1>
      <p className="lead text-slate-300 mt-6 max-w-2xl rise d2">Oman &amp; GCC-based international trading, sourcing and supply solutions connecting businesses across regional and global markets.</p>
      <div className="mt-9 flex flex-wrap gap-3 rise d3">
        <Link to="/products" className="btn-primary" data-testid="hero-explore-btn">Explore Products <ArrowRight size={16} /></Link>
        <Link to="/request-quote" className="btn bg-white text-[#0A192F] hover:bg-slate-100" data-testid="hero-rfq-btn">Request a Quote</Link>
        <Link to="/request-product" className="btn-ghost-light" data-testid="hero-tell-us-btn">Tell Us What You Need</Link>
      </div>
      <div className="mt-14 flex flex-wrap items-center gap-x-6 gap-y-2 text-xs sm:text-sm font-semibold tracking-wide text-slate-300 rise d4" data-testid="hero-capabilities">
        {["International Trading", "Global Sourcing", "Industrial Supply", "Project Solutions"].map((c, i) => <span key={c} className="flex items-center gap-2">{i > 0 && <span className="hidden sm:block h-1 w-1 rounded-full bg-sky-400" />}{c}</span>)}
      </div>
    </div>
  </section>
);
