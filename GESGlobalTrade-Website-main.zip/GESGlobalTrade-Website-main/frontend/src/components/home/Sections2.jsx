import { useState } from "react";
import { Link } from "react-router-dom";
import { ArrowRight, Mail, MessageCircle, Building2, Factory, Route, Zap, HardHat, Sprout, Droplets, Leaf, Store, Briefcase, Warehouse, Hospital } from "lucide-react";
import { SectionHead } from "@/components/common";
import { SITE, waLink } from "@/lib/site";

export const IND_ICONS = { construction: HardHat, manufacturing: Factory, infrastructure: Route, "electrical-utilities": Zap, "industrial-projects": Building2, agriculture: Sprout, "water-irrigation": Droplets, "environmental-sustainability": Leaf, "wholesale-distribution": Store, "commercial-businesses": Briefcase, "warehousing-logistics": Warehouse, "healthcare-specialized": Hospital };

export const IndustriesSection = ({ industries }) => {
  const [active, setActive] = useState(0);
  const ind = industries[active];
  if (!ind) return null;
  return (
    <section className="section bg-white" data-testid="industries-section">
      <div className="container-x">
        <SectionHead eyebrow="Industries" title="Serving the sectors that keep the region building, producing and moving." />
        <div className="grid lg:grid-cols-12 gap-6">
          <div className="lg:col-span-5 grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-2 gap-2">
            {industries.map((x, i) => { const I = IND_ICONS[x.slug] || Building2; return (
              <button key={x.slug} onClick={() => setActive(i)} className={`text-left rounded-md border px-3.5 py-3 text-sm font-semibold flex items-center gap-2.5 transition-colors ${i === active ? "bg-[#0A192F] border-[#0A192F] text-white" : "border-slate-200 text-slate-700 hover:border-[#0369A1] hover:text-[#0369A1]"}`} data-testid={`industry-tab-${x.slug}`} aria-pressed={i === active}><I size={16} className="shrink-0" /><span className="leading-tight">{x.name}</span></button>
            ); })}
          </div>
          <div className="lg:col-span-7 card overflow-hidden grid md:grid-cols-2" data-testid="industry-panel">
            <img src={ind.image} alt={ind.name} loading="lazy" className="h-48 md:h-full w-full object-cover" />
            <div className="p-6 md:p-8 flex flex-col">
              <h3 className="h3">{ind.name}</h3>
              <p className="text-slate-600 mt-2 text-sm leading-relaxed">{ind.description}</p>
              <p className="text-xs font-bold uppercase tracking-wider text-slate-500 mt-5 mb-2">Related solutions</p>
              <ul className="flex flex-wrap gap-2">{ind.categories.slice(0, 6).map((c) => <li key={c.slug}><Link to={`/products/${c.slug}`} className="badge border-slate-200 hover:border-[#0369A1] hover:text-[#0369A1] py-1">{c.name}</Link></li>)}</ul>
              <Link to={`/industries/${ind.slug}`} className="btn-primary btn-sm mt-auto self-start pt-2 mt-6" data-testid="industry-view-btn">View industry solutions <ArrowRight size={14} /></Link>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export const ApplicationsSection = ({ applications }) => (
  <section className="section bg-slate-50 border-y border-slate-200" data-testid="applications-section">
    <div className="container-x">
      <SectionHead eyebrow="Application-Based Sourcing" title="Tell Us the Application. We'll Help Identify the Supply Solution." lead="We understand requirements, not just products. Start from what you need to achieve and we'll help identify the right supply solution." />
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
        {applications.slice(0, 12).map((a) => (
          <Link key={a.slug} to={`/products?application=${a.slug}`} className="card card-hover p-5 group" data-testid={`application-${a.slug}`}>
            <h3 className="font-bold text-[#0A192F] group-hover:text-[#0369A1] transition-colors">{a.name}</h3>
            <p className="text-xs text-slate-500 mt-2 line-clamp-2">{a.categories.map((c) => c.name).join(", ")}</p>
          </Link>
        ))}
      </div>
    </div>
  </section>
);

export const STEPS = [["Requirement", "You tell us what you need."], ["Sourcing", "We identify suitable supply options."], ["Evaluation", "We assess specifications and commercial requirements."], ["Quotation", "We coordinate suitable quotation options."], ["Supply", "We coordinate the supply process."]];

export const HowWeWorkSteps = ({ dark }) => (
  <ol className="relative grid md:grid-cols-5 gap-6" data-testid="how-we-work-steps">
    <div className={`hidden md:block absolute top-6 left-[10%] right-[10%] h-px ${dark ? "bg-white/20" : "bg-slate-200"}`} aria-hidden><div className="h-px w-full bg-[#0369A1] origin-left animate-[grow_2s_ease-out_forwards]" style={{ transform: "scaleX(0)", animationName: "grow" }} /></div>
    <style>{`@keyframes grow{to{transform:scaleX(1)}}`}</style>
    {STEPS.map(([t, d], i) => (
      <li key={t} className="relative flex md:flex-col gap-4 md:gap-0 rise" style={{ animationDelay: `${i * 0.12}s` }}>
        <div className={`h-12 w-12 shrink-0 rounded-full border-2 flex items-center justify-center mono text-sm font-medium ${dark ? "bg-[#0A192F] border-sky-400 text-sky-300" : "bg-white border-[#0369A1] text-[#0369A1]"}`}>0{i + 1}</div>
        <div className="md:mt-5"><h3 className={`font-bold ${dark ? "text-white" : "text-[#0A192F]"}`}>{t}</h3><p className={`text-sm mt-1 ${dark ? "text-slate-300" : "text-slate-600"}`}>{d}</p></div>
      </li>
    ))}
  </ol>
);

export const FinalCta = () => (
  <section className="section bg-[#0369A1] text-white relative overflow-hidden" data-testid="final-cta">
    <div className="absolute inset-0 grid-lines opacity-40 [background-image:linear-gradient(to_right,rgba(255,255,255,.08)_1px,transparent_1px),linear-gradient(to_bottom,rgba(255,255,255,.08)_1px,transparent_1px)]" />
    <div className="container-x relative text-center max-w-3xl">
      <h2 className="h2 text-white">Tell Us What You Need.</h2>
      <p className="lead text-sky-100 mt-4">Can't find the right product? Send us your requirement, BOQ, specification, drawing or project details. We'll review the requirement and work on suitable sourcing options.</p>
      <div className="mt-8 flex flex-wrap justify-center gap-3">
        <Link to="/request-product" className="btn bg-white text-[#0369A1] hover:bg-sky-50" data-testid="cta-request-product">Request a Product</Link>
        <Link to="/request-quote" className="btn-navy" data-testid="cta-request-quote">Request a Quote</Link>
        <a href={waLink()} target="_blank" rel="noopener noreferrer" className="btn-whatsapp" data-testid="cta-whatsapp"><MessageCircle size={16} />WhatsApp Us</a>
      </div>
    </div>
  </section>
);

export const ContactStrip = () => (
  <section className="section bg-white" data-testid="contact-strip">
    <div className="container-x grid md:grid-cols-2 gap-8 items-center">
      <div>
        <span className="eyebrow">Contact</span>
        <h2 className="h2 mt-3">{SITE.legalName}</h2>
        <p className="text-slate-600 mt-2">{SITE.brand} · {SITE.region}</p>
      </div>
      <div className="grid sm:grid-cols-2 gap-3">
        <a href={`mailto:${SITE.email}`} className="card card-hover p-5 flex items-center gap-3" data-testid="contact-email-card"><Mail className="text-[#0369A1]" /><div><p className="text-xs text-slate-500">Email</p><p className="font-semibold text-sm text-[#0A192F] break-all">{SITE.email}</p></div></a>
        <a href={waLink()} target="_blank" rel="noopener noreferrer" className="card card-hover p-5 flex items-center gap-3" data-testid="contact-whatsapp-card"><MessageCircle className="text-[#059669]" /><div><p className="text-xs text-slate-500">Phone / WhatsApp</p><p className="font-semibold text-sm text-[#0A192F]">{SITE.phone}</p></div></a>
      </div>
    </div>
  </section>
);
