import { Link } from "react-router-dom";
import { Mail, Phone } from "lucide-react";
import { SITE, waLink } from "@/lib/site";

const cols = [
  { title: "Company", links: [["/", "Home"], ["/about", "About"], ["/products", "Products"], ["/industries", "Industries"], ["/how-we-work", "How We Work"], ["/contact", "Contact"]] },
  { title: "Solutions", links: [["/global-sourcing", "Global Sourcing"], ["/project-supply", "Bulk & Project Supply"], ["/warehouse-solutions", "Warehouse Solutions"], ["/products/water-pumps-pumping-solutions", "Water Pumps"], ["/products/generators-power-solutions", "Generators"], ["/products/electrical-wires-cables", "Electrical Cables"]] },
  { title: "Enquiries", links: [["/request-product", "Request a Product"], ["/request-quote", "Request a Quote / RFQ"], ["/business-enquiry", "Business Enquiry"], ["/enquiry-status", "Enquiry Status"], ["/privacy-policy", "Privacy Policy"], ["/terms", "Terms & Conditions"]] },
];

export const Footer = () => (
  <footer className="bg-[#0A192F] text-slate-300 pb-20 md:pb-0" data-testid="site-footer">
    <div className="container-x py-16 grid grid-cols-1 md:grid-cols-12 gap-10">
      <div className="md:col-span-5">
        <div className="inline-block bg-white rounded-md p-3"><img src="/logo.png" alt="GES Global Trade" className="h-16 w-auto" loading="lazy" /></div>
        <p className="mt-5 font-semibold text-white">{SITE.legalName}</p>
        <p className="text-sm">{SITE.brand} · {SITE.region}</p>
        <p className="mt-4 text-sm leading-relaxed max-w-sm">International Trading • Sourcing • Import &amp; Export • Industrial Supply • Environmental Solutions</p>
        <div className="mt-6 space-y-2 text-sm">
          <a href={`mailto:${SITE.email}`} className="flex items-center gap-2 hover:text-white" data-testid="footer-email"><Mail size={15} className="text-sky-400" />{SITE.email}</a>
          <a href={waLink()} target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 hover:text-white" data-testid="footer-phone"><Phone size={15} className="text-sky-400" />{SITE.phone} (Phone / WhatsApp)</a>
        </div>
      </div>
      {cols.map((c) => (
        <div key={c.title} className="md:col-span-2">
          <p className="text-xs font-bold uppercase tracking-[0.18em] text-white mb-4">{c.title}</p>
          <ul className="space-y-2.5 text-sm">{c.links.map(([to, l]) => <li key={to}><Link to={to} className="hover:text-white transition-colors">{l}</Link></li>)}</ul>
        </div>
      ))}
      <div className="md:col-span-1" />
    </div>
    <div className="border-t border-white/10">
      <div className="container-x py-5 flex flex-col md:flex-row gap-3 items-start md:items-center justify-between text-xs text-slate-400">
        <p>© {new Date().getFullYear()} {SITE.legalName}. All rights reserved.</p>
        <p>Company registration and relevant business documentation are available upon request.</p>
      </div>
    </div>
  </footer>
);
