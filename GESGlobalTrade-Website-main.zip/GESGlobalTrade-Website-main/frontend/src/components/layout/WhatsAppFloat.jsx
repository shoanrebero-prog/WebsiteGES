import { useLocation } from "react-router-dom";
import { MessageCircle } from "lucide-react";
import { waLink } from "@/lib/site";

export const WhatsAppFloat = ({ context }) => {
  const { pathname } = useLocation();
  const msg = context ? `Hello GES Global Trade, I would like to enquire about ${context}.` : pathname.startsWith("/warehouse") ? "Hello GES Global Trade, I would like to enquire about warehouse storage and racking solutions." : undefined;
  return (
    <a href={waLink(msg)} target="_blank" rel="noopener noreferrer" aria-label="Chat on WhatsApp" data-testid="whatsapp-float"
      className="fixed z-30 right-4 bottom-20 md:bottom-6 md:right-6 h-13 w-13 p-3.5 rounded-full bg-[#059669] text-white shadow-[0_10px_30px_-8px_rgba(5,150,105,.7)] hover:bg-[#047857] hover:scale-105 transition-[transform,background-color] duration-200">
      <MessageCircle size={24} />
    </a>
  );
};
