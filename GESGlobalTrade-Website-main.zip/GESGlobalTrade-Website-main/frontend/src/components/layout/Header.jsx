import { useEffect, useState } from "react";
import { Link, NavLink, useLocation } from "react-router-dom";
import { Menu, X, Search, MessageCircle, FileText } from "lucide-react";
import { NAV, waLink } from "@/lib/site";
import { SearchDialog } from "./SearchDialog";

export const Header = () => {
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const loc = useLocation();
  useEffect(() => { setOpen(false); }, [loc.pathname]);
  useEffect(() => { const f = () => setScrolled(window.scrollY > 8); f(); window.addEventListener("scroll", f, { passive: true }); return () => window.removeEventListener("scroll", f); }, []);
  useEffect(() => { const k = (e) => { if ((e.metaKey || e.ctrlKey) && e.key === "k") { e.preventDefault(); setSearch(true); } }; window.addEventListener("keydown", k); return () => window.removeEventListener("keydown", k); }, []);

  return (
    <>
      <header className={`sticky top-0 z-40 bg-white/95 backdrop-blur border-b transition-[box-shadow,border-color] ${scrolled ? "border-slate-200 shadow-[0_4px_24px_-12px_rgba(10,25,47,.18)]" : "border-transparent"}`} data-testid="site-header">
        <div className="hidden lg:block bg-[#0A192F] text-slate-300 text-xs">
          <div className="container-x flex items-center justify-between h-8">
            <span className="tracking-wide">Oman &amp; GCC-based. Globally connected.</span>
            <div className="flex items-center gap-5">
              <a href="mailto:info@GESGlobalTrade.com" className="hover:text-white">info@GESGlobalTrade.com</a>
              <a href="tel:+971522282043" className="hover:text-white">+971 52 228 2043</a>
            </div>
          </div>
        </div>
        <div className="container-x flex items-center justify-between h-16 lg:h-[76px] gap-4">
          <Link to="/" className="flex items-center shrink-0" aria-label="GES Global Trade home" data-testid="header-logo">
            <img src="/logo-header.png" alt="GES Global Trade" className="h-10 lg:h-12 w-auto" width="640" height="247" />
          </Link>
          <nav className="hidden xl:flex items-center gap-1" aria-label="Main navigation">
            {NAV.map((n) => (
              <NavLink key={n.to} to={n.to} end={n.to === "/"} data-testid={`nav-${n.label.toLowerCase().replace(/\s+/g, "-")}`}
                className={({ isActive }) => `px-2.5 py-2 text-[12.5px] font-semibold rounded-md whitespace-nowrap transition-colors ${isActive ? "text-[#0369A1] bg-sky-50" : "text-slate-700 hover:text-[#0369A1] hover:bg-slate-50"}`}>{n.label}</NavLink>
            ))}
          </nav>
          <div className="flex items-center gap-2">
            <button onClick={() => setSearch(true)} className="btn-outline btn-sm h-10 w-10 !px-0 lg:w-auto lg:!px-3.5" aria-label="Search products" data-testid="header-search-btn"><Search size={16} /><span className="hidden lg:inline">Search</span></button>
            <a href={waLink()} target="_blank" rel="noopener noreferrer" className="btn-whatsapp btn-sm h-10 hidden sm:inline-flex xl:hidden 2xl:inline-flex" data-testid="header-whatsapp-btn"><MessageCircle size={16} />WhatsApp</a>
            <Link to="/request-quote" className="btn-primary btn-sm h-10 hidden md:inline-flex" data-testid="header-rfq-btn"><FileText size={16} />Request a Quote</Link>
            <button onClick={() => setOpen(!open)} className="xl:hidden btn-outline btn-sm h-10 w-10 !px-0" aria-label="Toggle menu" aria-expanded={open} data-testid="mobile-menu-btn">{open ? <X size={18} /> : <Menu size={18} />}</button>
          </div>
        </div>
        {open && (
          <div className="xl:hidden border-t border-slate-200 bg-white" data-testid="mobile-menu">
            <nav className="container-x py-3 flex flex-col" aria-label="Mobile navigation">
              {NAV.map((n) => <NavLink key={n.to} to={n.to} end={n.to === "/"} className={({ isActive }) => `py-3 border-b border-slate-100 text-[15px] font-semibold ${isActive ? "text-[#0369A1]" : "text-slate-800"}`}>{n.label}</NavLink>)}
              <NavLink to="/request-product" className="py-3 border-b border-slate-100 text-[15px] font-semibold text-slate-800">Request a Product</NavLink>
              <NavLink to="/contact" className="py-3 border-b border-slate-100 text-[15px] font-semibold text-slate-800">Contact</NavLink>
              <div className="grid grid-cols-2 gap-3 py-4">
                <Link to="/request-quote" className="btn-primary" data-testid="mobile-rfq-btn">Request a Quote</Link>
                <a href={waLink()} target="_blank" rel="noopener noreferrer" className="btn-whatsapp">WhatsApp</a>
              </div>
            </nav>
          </div>
        )}
      </header>
      <SearchDialog open={search} onClose={() => setSearch(false)} />
      <div className="md:hidden fixed bottom-0 inset-x-0 z-30 bg-white/95 backdrop-blur border-t border-slate-200 p-2 grid grid-cols-2 gap-2" data-testid="mobile-sticky-bar">
        <Link to="/request-quote" className="btn-primary !py-2.5">Request a Quote</Link>
        <a href={waLink()} target="_blank" rel="noopener noreferrer" className="btn-whatsapp !py-2.5"><MessageCircle size={16} />WhatsApp</a>
      </div>
    </>
  );
};
