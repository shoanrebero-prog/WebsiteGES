import { useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Search, X, ArrowRight, Clock, Layers, Package } from "lucide-react";
import { api } from "@/lib/api";

const RECENT_KEY = "ges_recent_searches";
const getRecent = () => { try { return JSON.parse(localStorage.getItem(RECENT_KEY) || "[]"); } catch { return []; } };

export const SearchDialog = ({ open, onClose }) => {
  const [q, setQ] = useState("");
  const [res, setRes] = useState(null);
  const [popular, setPopular] = useState([]);
  const nav = useNavigate();
  const ref = useRef();

  useEffect(() => { if (open) { setTimeout(() => ref.current?.focus(), 50); api.get("/catalog/search", { params: { q: "pump" } }).then((r) => setPopular(r.data.popular)).catch(() => {}); } else { setQ(""); setRes(null); } }, [open]);
  useEffect(() => {
    if (!q.trim()) { setRes(null); return; }
    const t = setTimeout(() => api.get("/catalog/search", { params: { q } }).then((r) => setRes(r.data)).catch(() => {}), 180);
    return () => clearTimeout(t);
  }, [q]);
  useEffect(() => { const k = (e) => e.key === "Escape" && onClose(); if (open) window.addEventListener("keydown", k); return () => window.removeEventListener("keydown", k); }, [open, onClose]);

  const go = (to, term) => {
    if (term) localStorage.setItem(RECENT_KEY, JSON.stringify([term, ...getRecent().filter((x) => x !== term)].slice(0, 6)));
    onClose(); nav(to);
  };
  const submit = (e) => { e.preventDefault(); if (q.trim()) go(`/products?q=${encodeURIComponent(q.trim())}`, q.trim()); };
  if (!open) return null;
  const recent = getRecent();
  const empty = res && !res.products.length && !res.categories.length;

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center p-4 pt-[8vh]" role="dialog" aria-modal="true" aria-label="Search products" data-testid="search-dialog">
      <div className="absolute inset-0 bg-[#0A192F]/70 backdrop-blur-sm" onClick={onClose} />
      <div className="relative w-full max-w-2xl bg-white rounded-xl shadow-2xl overflow-hidden rise">
        <form onSubmit={submit} className="flex items-center gap-3 px-4 border-b border-slate-200">
          <Search size={18} className="text-slate-400" />
          <input ref={ref} value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search products, categories, applications… e.g. pump, racking, cable" className="flex-1 h-14 text-base outline-none placeholder:text-slate-400" data-testid="search-input" aria-label="Search" />
          <button type="button" onClick={onClose} aria-label="Close search" className="p-2 text-slate-500 hover:text-slate-900" data-testid="search-close-btn"><X size={18} /></button>
        </form>
        <div className="max-h-[60vh] overflow-y-auto p-3">
          {!res && (
            <div className="grid sm:grid-cols-2 gap-4 p-2">
              {recent.length > 0 && <div><p className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-2 flex items-center gap-1"><Clock size={12} />Recent searches</p>{recent.map((r) => <button key={r} onClick={() => go(`/products?q=${encodeURIComponent(r)}`, r)} className="block w-full text-left px-3 py-2 rounded-md hover:bg-slate-50 text-sm">{r}</button>)}</div>}
              <div><p className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-2">Popular searches</p><div className="flex flex-wrap gap-2">{popular.map((p) => <button key={p} onClick={() => go(`/products?q=${encodeURIComponent(p)}`, p)} className="badge border-slate-200 hover:border-[#0369A1] hover:text-[#0369A1] py-1.5" data-testid={`popular-${p.toLowerCase().replace(/\s+/g, "-")}`}>{p}</button>)}</div></div>
            </div>
          )}
          {res && res.categories.length > 0 && <div className="p-2"><p className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-1">Related categories</p>{res.categories.map((c) => <button key={c.slug} onClick={() => go(`/products/${c.slug}`, q)} className="flex w-full items-center gap-3 px-3 py-2.5 rounded-md hover:bg-sky-50 text-sm text-left" data-testid={`search-cat-${c.slug}`}><Layers size={16} className="text-[#0369A1]" /><span className="flex-1 font-medium">{c.name}</span><span className="text-xs text-slate-400">{c.product_count} products</span></button>)}</div>}
          {res && res.products.length > 0 && <div className="p-2"><p className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-1">Products</p>{res.products.map((p) => <button key={p.slug} onClick={() => go(`/product/${p.slug}`, q)} className="flex w-full items-center gap-3 px-3 py-2.5 rounded-md hover:bg-sky-50 text-sm text-left" data-testid={`search-prod-${p.slug}`}><Package size={16} className="text-slate-400" /><span className="flex-1"><span className="font-medium block">{p.name}</span><span className="text-xs text-slate-500">{p.category_name}</span></span><ArrowRight size={14} className="text-slate-300" /></button>)}</div>}
          {res && res.applications.length > 0 && <div className="p-2 flex flex-wrap gap-2 items-center"><span className="text-xs text-slate-500">Applications:</span>{res.applications.map((a) => <button key={a.slug} onClick={() => go(`/products?application=${a.slug}`, q)} className="badge border-sky-200 bg-sky-50 text-[#0369A1]">{a.name}</button>)}</div>}
          {empty && (
            <div className="p-8 text-center" data-testid="search-no-results">
              <h3 className="h3">Can't Find What You're Looking For?</h3>
              <p className="text-slate-600 mt-2">Tell us what you need. We'll work on the sourcing.</p>
              <button onClick={() => go(`/request-product?product=${encodeURIComponent(q)}`)} className="btn-primary mt-5" data-testid="search-request-product-btn">Request a Product <ArrowRight size={16} /></button>
            </div>
          )}
          {res && !empty && <button onClick={submit} className="w-full mt-1 py-3 text-sm font-semibold text-[#0369A1] hover:bg-slate-50 rounded-md" data-testid="search-view-all-btn">View all results for "{q}" →</button>}
        </div>
      </div>
    </div>
  );
};
