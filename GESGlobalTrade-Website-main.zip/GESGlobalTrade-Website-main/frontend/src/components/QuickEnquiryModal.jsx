import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { X } from "lucide-react";
import { toast } from "sonner";
import { api } from "@/lib/api";
import { Field, Input, Textarea, validateCustomer } from "@/components/forms/Fields";

export const QuickEnquiryModal = ({ open, onClose, product }) => {
  const [v, setV] = useState({ full_name: "", company_name: "", email: "", phone: "", quantity: "", message: "", website: "" });
  const [errors, setErrors] = useState({});
  const [busy, setBusy] = useState(false);
  const nav = useNavigate();
  const set = (k, val) => setV((p) => ({ ...p, [k]: val }));
  if (!open) return null;

  const submit = async (e) => {
    e.preventDefault();
    const errs = validateCustomer({ ...v, country: "n/a" });
    setErrors(errs);
    if (Object.keys(errs).length) return;
    setBusy(true);
    try {
      const r = await api.post("/enquiries", { kind: "quick_enquiry", request_type: "Product Enquiry", website: v.website,
        customer: { full_name: v.full_name, company_name: v.company_name, country: "Not specified", email: v.email, phone: v.phone },
        requirement: { product: product?.name || "General enquiry", quantity: v.quantity, message: v.message, category_slug: product?.category_slug || "", product_slug: product?.slug || "" }, source_page: window.location.pathname });
      onClose(); nav(`/thank-you/${r.data.reference}`);
    } catch (err) { toast.error(err.response?.data?.detail || "We couldn't submit your requirement. Please check the highlighted fields and try again."); }
    finally { setBusy(false); }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4" role="dialog" aria-modal="true" aria-labelledby="qe-title" data-testid="quick-enquiry-modal">
      <div className="absolute inset-0 bg-[#0A192F]/70 backdrop-blur-sm" onClick={onClose} />
      <form onSubmit={submit} className="relative w-full sm:max-w-lg bg-white rounded-t-2xl sm:rounded-xl shadow-2xl p-6 sm:p-8 max-h-[92vh] overflow-y-auto rise">
        <button type="button" onClick={onClose} aria-label="Close" className="absolute right-4 top-4 p-2 text-slate-400 hover:text-slate-900" data-testid="quick-enquiry-close"><X size={18} /></button>
        <span className="eyebrow">Quick Enquiry</span>
        <h2 id="qe-title" className="h3 mt-2">Request Quote</h2>
        <p className="text-sm text-slate-600 mt-1">Product: <span className="font-semibold text-[#0A192F]">{product?.name}</span></p>
        <div className="grid sm:grid-cols-2 gap-4 mt-6">
          <Field label="Name" name="full_name" required error={errors.full_name}><Input name="full_name" value={v.full_name} onChange={set} error={errors.full_name} /></Field>
          <Field label="Company" name="company_name"><Input name="company_name" value={v.company_name} onChange={set} /></Field>
          <Field label="Email" name="email" required error={errors.email}><Input name="email" type="email" value={v.email} onChange={set} error={errors.email} /></Field>
          <Field label="Phone / WhatsApp" name="phone" required error={errors.phone}><Input name="phone" type="tel" value={v.phone} onChange={set} error={errors.phone} /></Field>
          <Field label="Quantity" name="quantity"><Input name="quantity" value={v.quantity} onChange={set} placeholder="e.g. 200 pcs" /></Field>
          <Field label="Message" name="message" className="sm:col-span-2"><Textarea name="message" rows={3} value={v.message} onChange={set} placeholder="Specifications, delivery location, required date…" /></Field>
          <input type="text" name="website" value={v.website} onChange={(e) => set("website", e.target.value)} className="hidden" tabIndex={-1} autoComplete="off" aria-hidden />
        </div>
        <button type="submit" disabled={busy} className="btn-primary w-full mt-6" data-testid="quick-enquiry-submit">{busy ? "Submitting…" : "Request Quote"}</button>
      </form>
    </div>
  );
};
