import { useCallback, useRef, useState } from "react";
import { UploadCloud, FileText, X, CheckCircle2, AlertCircle } from "lucide-react";
import { api } from "@/lib/api";

const OK_EXT = ["pdf", "xls", "xlsx", "doc", "docx", "jpg", "jpeg", "png"];
const MAX_MB = 15;
const fmt = (b) => (b > 1048576 ? `${(b / 1048576).toFixed(1)} MB` : `${Math.max(1, Math.round(b / 1024))} KB`);

export const FileUploader = ({ files, onChange, docType = "Other Documents", label = "Upload documents", hint, testId = "file-uploader" }) => {
  const [drag, setDrag] = useState(false);
  const input = useRef();

  const addFiles = useCallback(async (list) => {
    const incoming = Array.from(list);
    for (const f of incoming) {
      const ext = f.name.split(".").pop().toLowerCase();
      const local = { key: `${f.name}-${f.size}-${Date.now()}`, name: f.name, size: f.size, progress: 0, status: "uploading", doc_type: docType };
      if (!OK_EXT.includes(ext) || f.size > MAX_MB * 1048576) { onChange((p) => [...p, { ...local, status: "error", error: "This file type or size is not supported." }]); continue; }
      onChange((p) => [...p, local]);
      const fd = new FormData(); fd.append("file", f);
      try {
        const r = await api.post(`/uploads?doc_type=${encodeURIComponent(docType)}`, fd, { onUploadProgress: (e) => onChange((p) => p.map((x) => x.key === local.key ? { ...x, progress: Math.round((e.loaded / (e.total || f.size)) * 100) } : x)) });
        onChange((p) => p.map((x) => x.key === local.key ? { ...x, status: "done", progress: 100, id: r.data.id } : x));
      } catch (err) {
        const msg = err.response?.data?.detail || "Upload failed. Please try again.";
        onChange((p) => p.map((x) => x.key === local.key ? { ...x, status: "error", error: msg } : x));
      }
    }
  }, [docType, onChange]);

  const mine = files.filter((f) => f.doc_type === docType);
  return (
    <div data-testid={testId}>
      <span className="label">{label}</span>
      <div onDragOver={(e) => { e.preventDefault(); setDrag(true); }} onDragLeave={() => setDrag(false)} onDrop={(e) => { e.preventDefault(); setDrag(false); addFiles(e.dataTransfer.files); }}
        onClick={() => input.current?.click()} role="button" tabIndex={0} onKeyDown={(e) => e.key === "Enter" && input.current?.click()}
        className={`rounded-lg border-2 border-dashed p-6 text-center cursor-pointer transition-colors ${drag ? "border-[#0369A1] bg-sky-50" : "border-slate-300 hover:border-[#0369A1]/60 hover:bg-slate-50"}`} data-testid={`${testId}-dropzone`}>
        <UploadCloud className="mx-auto text-[#0369A1]" size={26} />
        <p className="mt-2 text-sm font-semibold text-[#0A192F]">Drag &amp; drop files here, or <span className="text-[#0369A1] underline">browse</span></p>
        <p className="text-xs text-slate-500 mt-1">{hint || "PDF, XLS, XLSX, DOC, DOCX, JPG, PNG · up to 15 MB each · multiple files allowed"}</p>
        <input ref={input} type="file" multiple accept={OK_EXT.map((e) => "." + e).join(",")} className="hidden" onChange={(e) => { addFiles(e.target.files); e.target.value = ""; }} data-testid={`${testId}-input`} aria-label={label} />
      </div>
      {mine.length > 0 && (
        <ul className="mt-3 space-y-2" data-testid={`${testId}-list`}>
          {mine.map((f) => (
            <li key={f.key} className="flex items-center gap-3 rounded-md border border-slate-200 bg-white px-3 py-2 text-sm" data-testid="uploaded-file-item">
              <FileText size={16} className="text-slate-400 shrink-0" />
              <div className="flex-1 min-w-0">
                <p className="truncate font-medium text-slate-800">{f.name} <span className="text-xs text-slate-400 font-normal">{fmt(f.size)}</span></p>
                {f.status === "uploading" && <div className="h-1 mt-1 bg-slate-100 rounded"><div className="h-1 bg-[#0369A1] rounded transition-[width]" style={{ width: `${f.progress}%` }} /></div>}
                {f.status === "error" && <p className="text-xs text-red-600 flex items-center gap-1"><AlertCircle size={12} />{f.error}</p>}
              </div>
              {f.status === "done" && <CheckCircle2 size={16} className="text-[#059669]" />}
              <button type="button" onClick={() => onChange((p) => p.filter((x) => x.key !== f.key))} aria-label={`Remove ${f.name}`} className="p-1 text-slate-400 hover:text-red-600" data-testid="remove-file-btn"><X size={16} /></button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};
