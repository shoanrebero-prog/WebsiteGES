import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";
import { api } from "@/lib/api";
import { validateCustomer } from "@/components/forms/Fields";

export const CUSTOMER_INIT = { full_name: "", company_name: "", country: "", email: "", phone: "" };

export function useEnquiryForm({ kind, requirementInit, requestType, buildRequirement, buildWarehouse, validateExtra }) {
  const [customer, setCustomer] = useState(CUSTOMER_INIT);
  const [req, setReq] = useState(requirementInit);
  const [files, setFiles] = useState([]);
  const [errors, setErrors] = useState({});
  const [busy, setBusy] = useState(false);
  const [honey, setHoney] = useState("");
  const nav = useNavigate();
  const setC = (k, v) => setCustomer((p) => ({ ...p, [k]: v }));
  const setR = (k, v) => setReq((p) => ({ ...p, [k]: v }));

  const submit = async (e) => {
    e?.preventDefault();
    const errs = { ...validateCustomer(customer) };
    if (!req.product || req.product.trim().length < 2) errs.product = "Please describe the product or material required.";
    if (validateExtra) Object.assign(errs, validateExtra(req));
    setErrors(errs);
    if (Object.keys(errs).length) { toast.error("We couldn't submit your requirement. Please check the highlighted fields and try again."); document.querySelector("[aria-invalid='true']")?.scrollIntoView({ behavior: "smooth", block: "center" }); return; }
    if (files.some((f) => f.status === "uploading")) { toast.info("Please wait for uploads to finish."); return; }
    setBusy(true);
    try {
      const r = await api.post("/enquiries", {
        kind, request_type: typeof requestType === "function" ? requestType(req) : requestType, customer, website: honey,
        requirement: buildRequirement ? buildRequirement(req) : req, warehouse: buildWarehouse ? buildWarehouse(req) : undefined,
        document_ids: files.filter((f) => f.status === "done").map((f) => f.id), source_page: window.location.pathname,
      });
      toast.success("Requirement Submitted Successfully");
      nav(`/thank-you/${r.data.reference}`);
    } catch (err) {
      toast.error(err.response?.status === 429 ? err.response.data.detail : "Something went wrong. Please try again or contact us via WhatsApp.");
    } finally { setBusy(false); }
  };
  return { customer, setC, req, setR, files, setFiles, errors, busy, submit, honey, setHoney };
}

export const Honeypot = ({ value, onChange }) => <input type="text" name="website" value={value} onChange={(e) => onChange(e.target.value)} className="hidden" tabIndex={-1} autoComplete="off" aria-hidden />;

export const FormShell = ({ title, children, onSubmit, aside }) => (
  <section className="section !pt-10">
    <div className="container-x grid lg:grid-cols-12 gap-10">
      <form onSubmit={onSubmit} noValidate className="lg:col-span-8 space-y-10" data-testid="enquiry-form">{children}</form>
      <aside className="lg:col-span-4">{aside}</aside>
    </div>
  </section>
);

export const FormBlock = ({ step, title, children }) => (
  <fieldset className="card p-6 md:p-8">
    <legend className="sr-only">{title}</legend>
    <div className="flex items-center gap-3 mb-6"><span className="mono text-xs text-[#0369A1] border border-sky-200 bg-sky-50 rounded px-2 py-0.5">{step}</span><h2 className="h3">{title}</h2></div>
    {children}
  </fieldset>
);
