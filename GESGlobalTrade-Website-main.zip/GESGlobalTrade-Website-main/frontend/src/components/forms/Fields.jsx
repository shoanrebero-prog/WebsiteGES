import { COUNTRIES, UNITS } from "@/lib/site";

export const Field = ({ label, name, required, error, children, hint, className = "" }) => (
  <div className={className}>
    <label htmlFor={name} className="label">{label}{required && <span className="text-red-500 ml-0.5">*</span>}</label>
    {children}
    {hint && !error && <p className="text-xs text-slate-500 mt-1">{hint}</p>}
    {error && <p className="text-xs text-red-600 mt-1" role="alert" data-testid={`error-${name}`}>{error}</p>}
  </div>
);

export const Input = ({ name, value, onChange, error, ...rest }) => (
  <input id={name} name={name} value={value ?? ""} onChange={(e) => onChange(name, e.target.value)} aria-invalid={!!error} className={`input ${error ? "border-red-400" : ""}`} data-testid={`input-${name}`} {...rest} />
);

export const Textarea = ({ name, value, onChange, error, rows = 4, ...rest }) => (
  <textarea id={name} name={name} value={value ?? ""} onChange={(e) => onChange(name, e.target.value)} rows={rows} aria-invalid={!!error} className={`input ${error ? "border-red-400" : ""}`} data-testid={`input-${name}`} {...rest} />
);

export const Select = ({ name, value, onChange, options, placeholder = "Select…", error }) => (
  <select id={name} name={name} value={value ?? ""} onChange={(e) => onChange(name, e.target.value)} aria-invalid={!!error} className={`input ${error ? "border-red-400" : ""}`} data-testid={`select-${name}`}>
    <option value="">{placeholder}</option>
    {options.map((o) => <option key={o} value={o}>{o}</option>)}
  </select>
);

export const CustomerFields = ({ v, set, errors }) => (
  <div className="grid sm:grid-cols-2 gap-5">
    <Field label="Full Name" name="full_name" required error={errors.full_name}><Input name="full_name" value={v.full_name} onChange={set} error={errors.full_name} autoComplete="name" /></Field>
    <Field label="Company Name" name="company_name" error={errors.company_name}><Input name="company_name" value={v.company_name} onChange={set} autoComplete="organization" /></Field>
    <Field label="Country" name="country" required error={errors.country}><Select name="country" value={v.country} onChange={set} options={COUNTRIES} error={errors.country} /></Field>
    <Field label="Email" name="email" required error={errors.email}><Input name="email" type="email" value={v.email} onChange={set} error={errors.email} autoComplete="email" /></Field>
    <Field label="Phone / WhatsApp" name="phone" required error={errors.phone} className="sm:col-span-2"><Input name="phone" type="tel" value={v.phone} onChange={set} error={errors.phone} placeholder="+968 …" autoComplete="tel" /></Field>
  </div>
);

export const QuantityUnit = ({ v, set, errors }) => (
  <>
    <Field label="Quantity" name="quantity" error={errors.quantity}><Input name="quantity" value={v.quantity} onChange={set} inputMode="decimal" placeholder="e.g. 500" /></Field>
    <Field label="Unit" name="unit"><Select name="unit" value={v.unit} onChange={set} options={UNITS} /></Field>
  </>
);

export const validateCustomer = (v) => {
  const e = {};
  if (!v.full_name || v.full_name.trim().length < 2) e.full_name = "Please enter your full name.";
  if (!v.country) e.country = "Please select your country.";
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(v.email || "")) e.email = "Please enter a valid email address.";
  if (!v.phone || v.phone.replace(/\D/g, "").length < 6) e.phone = "Please enter a valid phone / WhatsApp number.";
  return e;
};
