import { Link } from "react-router-dom";
import { MessageCircle, ShieldCheck, Clock, FileCheck2 } from "lucide-react";
import { SITE, waLink } from "@/lib/site";

export const FormAside = ({ title = "What happens next?", children }) => (
  <div className="lg:sticky lg:top-[132px] space-y-4">
    <div className="card p-6">
      <h3 className="font-bold text-[#0A192F]">{title}</h3>
      <ol className="mt-4 space-y-3 text-sm text-slate-600">
        {[[FileCheck2, "You receive a unique reference number instantly."], [Clock, "Our team reviews the requirement and identifies suitable sourcing options."], [MessageCircle, "We contact you regarding quotation and supply coordination."]].map(([I, t], i) => <li key={i} className="flex gap-3"><I size={16} className="text-[#0369A1] shrink-0 mt-0.5" />{t}</li>)}
      </ol>
    </div>
    <div className="card p-6 bg-slate-50">
      <p className="text-sm text-slate-700 flex gap-2"><ShieldCheck size={16} className="text-[#059669] shrink-0 mt-0.5" />Uploaded documents are stored privately and are never exposed publicly. Used only to review your requirement.</p>
    </div>
    {children}
    <a href={waLink()} target="_blank" rel="noopener noreferrer" className="btn-whatsapp w-full" data-testid="aside-whatsapp"><MessageCircle size={16} />Prefer WhatsApp? {SITE.phone}</a>
    <p className="text-xs text-slate-500 text-center">Already submitted? <Link to="/enquiry-status" className="text-[#0369A1] font-semibold">Check your enquiry status</Link></p>
  </div>
);
