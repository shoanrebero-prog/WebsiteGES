import re

U = "https://images.unsplash.com/photo-"
IMG = {
    "port": U + "1494412651409-8963ce7935a7",
    "port_cranes": U + "1578575437130-527eed3abbec",
    "port_night": U + "1519003722824-194d4455a60c",
    "containers": U + "1605732562742-3023a888e56e",
    "racking": U + "1592085198739-ffcad7f36b54",
    "forklift": U + "1740914994657-f1cdffdc418e",
    "warehouse": U + "1586528116311-ad8dd3c8310d",
    "racking2": U + "1590247813693-5541d1c609fd",
    "aisle": U + "1587293852726-70cdb56c2866",
    "plant": U + "1516937941344-00b4e0337589",
    "welding": U + "1504328345606-18bbc8c9d7d1",
    "electrical": U + "1621905251189-08b45d6a269e",
    "construction": U + "1504307651254-35680f356dfd",
    "seedlings": U + "1625246333195-78d9c38ad449",
    "field": U + "1500382017468-9049fed747ef",
    "solar": U + "1641959166364-6c9b9898e804",
    "solar2": U + "1613665813446-82a78c468a1d",
    "solar3": U + "1473341304170-971dccb5ac1e",
    "trucks": U + "1565793298595-6a879b1d9492",
    "truck": U + "1601584115197-04ecc0da31d7",
    "drawing": U + "1581094288338-2314dddb7ece",
    "blueprint": U + "1542621334-a254cf47733d",
    "water": U + "1574691250077-03a929faece5",
}


def img(key, w=1200):
    return f"{IMG[key]}?auto=format&fit=crop&w={w}&q=75"


def slugify(s):
    return re.sub(r"[^a-z0-9]+", "-", s.lower()).strip("-")


INDUSTRIES = [
    ("construction", "Construction", "Materials, equipment and site supply for building and civil works.", "construction"),
    ("manufacturing", "Manufacturing", "Industrial inputs, machinery and maintenance supply for production facilities.", "plant"),
    ("infrastructure", "Infrastructure", "Bulk and project materials for roads, utilities and public works.", "construction"),
    ("electrical-utilities", "Electrical & Utilities", "Cables, distribution equipment and power products for utility networks.", "electrical"),
    ("industrial-projects", "Industrial Projects", "BOQ-based supply coordination for industrial and EPC projects.", "plant"),
    ("agriculture", "Agriculture", "Pumps, irrigation, machinery and inputs for farms and agri-businesses.", "seedlings"),
    ("water-irrigation", "Water & Irrigation", "Pumping, piping and irrigation solutions for water transfer and distribution.", "field"),
    ("environmental-sustainability", "Environmental & Sustainability", "Water treatment, wastewater and environmental equipment.", "water"),
    ("wholesale-distribution", "Wholesale & Distribution", "Volume sourcing for traders, resellers and distribution businesses.", "containers"),
    ("commercial-businesses", "Commercial Businesses", "Equipment and supplies for offices, retail and commercial facilities.", "trucks"),
    ("warehousing-logistics", "Warehousing & Logistics", "Racking, shelving, material handling and loading bay solutions.", "racking"),
    ("healthcare-specialized", "Healthcare & Specialized Facilities", "Specialized storage, mobile shelving and medical storage systems.", "aisle"),
]

APPLICATIONS = [
    ("warehouse-storage", "Warehouse Storage"), ("water-transfer", "Water Transfer"), ("irrigation", "Irrigation"),
    ("construction", "Construction"), ("power-generation", "Power Generation"), ("electrical-distribution", "Electrical Distribution"),
    ("material-handling", "Material Handling"), ("industrial-maintenance", "Industrial Maintenance"),
    ("environmental-treatment", "Environmental Treatment"), ("manufacturing", "Manufacturing"), ("logistics", "Logistics"),
    ("agriculture", "Agriculture"), ("dewatering", "Dewatering"), ("water-supply", "Water Supply"),
]

# (slug, name, tagline, description, image, industries, applications, related_categories, subcategories, configurations)
RAW_CATEGORIES = [
    ("gypsum-mineral-materials", "Gypsum & Mineral Materials", "Bulk mineral and construction raw materials",
     "Natural gypsum, gypsum powder and industrial minerals sourced in bulk for cement, construction and industrial processing requirements.",
     "construction", ["construction", "manufacturing", "infrastructure", "wholesale-distribution"], ["construction", "manufacturing"],
     ["steel-metal-products", "chemicals-fertilizers", "plastics-polymers"],
     ["Natural Gypsum / Gypsum Rock", "Gypsum Powder", "Industrial Minerals", "Construction Minerals"],
     ["Bulk / loose cargo", "Bagged supply", "Grade and purity as per requirement", "Particle size as per requirement"]),
    ("electrical-wires-cables", "Electrical Wires & Cables", "Building, power, control and specialty cables",
     "A wide range of electrical wires and cables for building, industrial, power distribution, control and specialty applications, sourced according to project specifications.",
     "electrical", ["electrical-utilities", "construction", "industrial-projects", "infrastructure"], ["electrical-distribution", "construction", "power-generation"],
     ["electrical-equipment", "generators-power-solutions", "engines-power-components"],
     ["Single Core Wires", "2-Core Cables", "3-Core Cables", "4-Core Cables", "5-Core Cables", "Multi-Core Cables", "Building Wires", "Flexible Cables", "Industrial Cables", "Power Cables", "Control Cables", "Instrumentation Cables", "Armoured Cables", "XLPE Cables", "PVC Cables", "Low Voltage Cables", "Medium Voltage Cables", "Submersible Pump Cables", "Solar DC Cables", "Fire-Resistant / Fire-Rated Cables"],
     ["Conductor size and core count as per requirement", "Insulation and sheath type as per specification", "Voltage grade as per project requirement", "Drum length and packing as per requirement"]),
    ("electrical-equipment", "Electrical Equipment", "Switchgear, distribution and electrical components",
     "Switchgear, distribution equipment and industrial electrical components for commercial, industrial and project electrical requirements.",
     "solar2", ["electrical-utilities", "construction", "manufacturing", "industrial-projects"], ["electrical-distribution", "power-generation", "industrial-maintenance"],
     ["electrical-wires-cables", "generators-power-solutions", "engines-power-components"],
     ["Switchgear", "Distribution Equipment", "Electrical Accessories", "Industrial Electrical Components", "Power Distribution Products"],
     ["Ratings as per project specification", "Enclosure type as per site requirement", "Configuration based on load schedule"]),
    ("steel-metal-products", "Steel & Metal Products", "Structural steel, sections, pipes, sheets and plates",
     "Structural steel, sections, pipes, sheets, plates and industrial metal products for construction, fabrication and industrial projects.",
     "containers", ["construction", "manufacturing", "infrastructure", "industrial-projects"], ["construction", "manufacturing", "industrial-maintenance"],
     ["pipes-valves-fittings", "welding-equipment", "gypsum-mineral-materials"],
     ["Structural Steel", "Steel Sections", "Steel Pipes", "Steel Sheets", "Steel Plates", "Metal Products", "Industrial Steel Materials"],
     ["Grade as per specification", "Dimensions and thickness as per requirement", "Surface finish as per requirement", "Cut-to-length options subject to requirement"]),
    ("pipes-valves-fittings", "Pipes, Valves & Fittings", "HDPE, PVC and industrial piping systems",
     "HDPE, PVC and industrial pipes with valves, flanges and fittings for water, irrigation, construction and industrial fluid systems.",
     "plant", ["water-irrigation", "construction", "infrastructure", "agriculture", "manufacturing"], ["water-transfer", "irrigation", "water-supply", "construction"],
     ["water-pumps-pumping-solutions", "industrial-hoses-accessories", "agriculture-irrigation-garden"],
     ["HDPE Pipes", "PVC Pipes", "Industrial Pipes", "Valves", "Flanges", "Pipe Fittings", "Irrigation Fittings"],
     ["Diameter and pressure class as per requirement", "Material grade as per application", "Connection type as per system design"]),
    ("plastics-polymers", "Plastics & Polymers", "Industrial plastics and raw materials",
     "Industrial plastics, polymer products and plastic raw materials for manufacturing and processing requirements.",
     "warehouse", ["manufacturing", "wholesale-distribution", "industrial-projects"], ["manufacturing"],
     ["chemicals-fertilizers", "gypsum-mineral-materials", "pipes-valves-fittings"],
     ["Industrial Plastics", "Polymer Products", "Plastic Raw Materials"],
     ["Grade and form as per requirement", "Packaging as per requirement"]),
    ("chemicals-fertilizers", "Chemicals & Fertilizers", "Industrial, water treatment and agricultural inputs",
     "Industrial chemicals, water treatment chemicals, agricultural fertilizers and industrial raw materials sourced according to customer specifications and applicable regulations.",
     "seedlings", ["agriculture", "manufacturing", "environmental-sustainability", "water-irrigation"], ["agriculture", "environmental-treatment", "manufacturing"],
     ["environmental-water-treatment", "agriculture-irrigation-garden", "plastics-polymers"],
     ["Industrial Chemicals", "Water Treatment Chemicals", "Agricultural Fertilizers", "Industrial Raw Materials"],
     ["Grade and concentration as per requirement", "Packaging as per requirement", "Documentation as per applicable regulations"]),
    ("industrial-machinery-equipment", "Industrial Machinery & Equipment", "Machinery, tools and spare parts",
     "Industrial machinery, processing equipment, workshop equipment, tools, accessories and spare parts for industrial and commercial operations.",
     "drawing", ["manufacturing", "industrial-projects", "construction", "commercial-businesses"], ["manufacturing", "industrial-maintenance", "material-handling"],
     ["material-handling-equipment", "welding-equipment", "air-compressors"],
     ["Industrial Machinery", "Processing Equipment", "Material Handling Equipment", "Workshop Equipment", "Industrial Tools", "Machinery Accessories", "Machinery Spare Parts"],
     ["Capacity and power as per requirement", "Configuration as per operational need", "Spare parts as per model reference"]),
    ("agriculture-irrigation-garden", "Agriculture, Irrigation & Garden Equipment", "Farm machinery, irrigation systems and garden tools",
     "Agricultural machinery, irrigation systems, pumps, fertigation equipment and garden machinery for farms, landscaping and water distribution.",
     "field", ["agriculture", "water-irrigation", "commercial-businesses"], ["agriculture", "irrigation", "water-transfer"],
     ["water-pumps-pumping-solutions", "pipes-valves-fittings", "industrial-hoses-accessories", "chemicals-fertilizers"],
     ["Agricultural Machinery", "Agricultural Water Pumps", "Agricultural Equipment", "Irrigation Pumps", "Drip Irrigation Systems", "Sprinkler Systems", "Irrigation Pipes", "Irrigation Valves", "Irrigation Filters", "Fertigation Equipment", "Irrigation Controllers", "Chainsaws", "Lawn Mowers", "Brush Cutters", "Grass Cutters", "Pruners", "Garden Machinery", "Garden Tools"],
     ["Capacity and coverage as per field requirement", "Power source as per site availability", "System components as per layout"]),
    ("water-pumps-pumping-solutions", "Water Pumps & Pumping Solutions", "Centrifugal, submersible, diesel, solar and dewatering pumps",
     "Water pumps and pumping solutions for agriculture, irrigation, construction, dewatering, industrial water transfer and water supply.",
     "field", ["agriculture", "water-irrigation", "construction", "infrastructure", "manufacturing"], ["water-transfer", "irrigation", "dewatering", "water-supply", "agriculture", "construction"],
     ["pipes-valves-fittings", "industrial-hoses-accessories", "agriculture-irrigation-garden", "generators-power-solutions", "engines-power-components"],
     ["Centrifugal Pumps", "Submersible Pumps", "Borehole Pumps", "Deep-Well Pumps", "Diesel Water Pumps", "Petrol Water Pumps", "Electric Water Pumps", "Solar Water Pumps", "High-Pressure Pumps", "Trash Pumps", "Dewatering Pumps", "Self-Priming Pumps", "Chemical / Agricultural Pumps", "Pump Spare Parts"],
     ["Flow rate and head as per requirement", "Power source: electric, diesel, petrol or solar", "Inlet / outlet size as per system", "Material as per fluid application"]),
    ("generators-power-solutions", "Generators & Power Solutions", "Diesel, petrol, silent and industrial generators",
     "Diesel, petrol, portable, silent and industrial generators, ATS systems, alternators and spare parts for standby and prime power requirements.",
     "solar2", ["construction", "manufacturing", "electrical-utilities", "commercial-businesses", "agriculture"], ["power-generation", "construction", "industrial-maintenance"],
     ["engines-power-components", "electrical-wires-cables", "electrical-equipment", "welding-equipment"],
     ["Diesel Generators", "Petrol / Gasoline Generators", "Portable Generators", "Silent Generators", "Industrial Generators", "ATS Generator Systems", "Welder Generators", "Generator & Pump Sets", "Generator Spare Parts", "Alternators", "Automatic Transfer Switches"],
     ["Output rating as per load requirement", "Open or silent canopy", "Manual or automatic start", "Voltage and frequency as per site"]),
    ("engines-power-components", "Engines & Power Components", "Engines, alternators and motors",
     "General purpose, petrol, diesel and industrial engines, AC alternators, induction motors and spare parts for equipment and power applications.",
     "truck", ["manufacturing", "agriculture", "construction", "industrial-projects"], ["power-generation", "industrial-maintenance", "agriculture"],
     ["generators-power-solutions", "water-pumps-pumping-solutions", "industrial-machinery-equipment"],
     ["General Purpose Engines", "Petrol Engines", "Diesel Engines", "Industrial Engines", "AC Alternators", "Induction Motors", "Engine Spare Parts"],
     ["Power output as per requirement", "Shaft and mounting as per application", "Spare parts as per model reference"]),
    ("construction-equipment", "Construction Equipment", "Site equipment, compaction and hoists",
     "Concrete vibrators, asphalt cutters, compaction equipment, hoists and construction machinery for contractors and site operations.",
     "construction", ["construction", "infrastructure", "industrial-projects"], ["construction", "material-handling"],
     ["generators-power-solutions", "steel-metal-products", "material-handling-equipment", "welding-equipment"],
     ["Concrete Vibrators", "Asphalt Cutters", "Compaction Equipment", "Electric Hoists", "Construction Machinery", "Material Handling Equipment", "Construction Accessories"],
     ["Capacity as per site requirement", "Power source as per availability", "Accessories as per application"]),
    ("cleaning-pressure-equipment", "Cleaning & Pressure Equipment", "Pressure washers and cleaning equipment",
     "High-pressure washers, industrial and portable pressure washers and cleaning equipment for facilities, fleets and industrial cleaning.",
     "trucks", ["commercial-businesses", "manufacturing", "warehousing-logistics", "construction"], ["industrial-maintenance", "logistics"],
     ["air-compressors", "industrial-hoses-accessories", "water-pumps-pumping-solutions"],
     ["High-Pressure Washers", "Industrial Pressure Washers", "Portable Pressure Washers", "Cleaning Equipment", "Cleaning Accessories"],
     ["Pressure and flow as per requirement", "Electric or engine driven", "Hot or cold water as per application"]),
    ("air-compressors", "Air Compressors", "Portable and industrial compressed air",
     "Portable and industrial air compressors, accessories and spare parts for workshops, construction sites and industrial operations.",
     "plant", ["manufacturing", "construction", "commercial-businesses"], ["industrial-maintenance", "construction", "manufacturing"],
     ["industrial-machinery-equipment", "industrial-hoses-accessories", "welding-equipment"],
     ["Portable Air Compressors", "Industrial Air Compressors", "Compressor Accessories", "Compressor Spare Parts"],
     ["Capacity and pressure as per requirement", "Tank size as per application", "Power source as per site"]),
    ("welding-equipment", "Welding Equipment", "Welding machines, consumables and accessories",
     "Welding machines, generator welding sets, accessories, consumables and spare parts for fabrication, maintenance and construction.",
     "welding", ["manufacturing", "construction", "industrial-projects"], ["industrial-maintenance", "construction", "manufacturing"],
     ["steel-metal-products", "generators-power-solutions", "air-compressors"],
     ["Welding Machines", "Generator Welding Sets", "Welding Accessories", "Welding Consumables", "Welding Spare Parts"],
     ["Process and amperage as per requirement", "Input power as per site", "Consumables as per material"]),
    ("safety-security-equipment", "Safety & Security Equipment", "Fire-resistant and security safes",
     "Fire-resistant, fireproof, security and industrial safes for offices, commercial premises and industrial facilities.",
     "aisle", ["commercial-businesses", "healthcare-specialized", "manufacturing"], ["industrial-maintenance"],
     ["warehouse-storage-material-handling", "industrial-machinery-equipment"],
     ["Fire-Resistant Safes", "Fireproof Safes", "Security Safes", "Industrial Safes"],
     ["Size and capacity as per requirement", "Locking type as per requirement"]),
    ("material-handling-equipment", "Material Handling Equipment", "Pallet trucks, hoists and lifting",
     "Hand pallet trucks, electric hoists, lifting equipment and material handling accessories for warehouses, workshops and sites.",
     "forklift", ["warehousing-logistics", "manufacturing", "construction", "wholesale-distribution"], ["material-handling", "warehouse-storage", "logistics"],
     ["warehouse-storage-material-handling", "construction-equipment", "industrial-machinery-equipment"],
     ["Hand Pallet Trucks", "Electric Hoists", "Lifting Equipment", "Material Handling Accessories"],
     ["Load capacity as per requirement", "Fork dimensions as per pallet type", "Lift height as per application"]),
    ("environmental-water-treatment", "Environmental & Water Treatment Solutions", "Water, wastewater and environmental equipment",
     "Water treatment equipment, wastewater solutions, environmental equipment and sustainability products for municipal, industrial and commercial facilities.",
     "water", ["environmental-sustainability", "water-irrigation", "manufacturing", "infrastructure"], ["environmental-treatment", "water-supply", "manufacturing"],
     ["chemicals-fertilizers", "water-pumps-pumping-solutions", "pipes-valves-fittings"],
     ["Water Treatment Equipment", "Wastewater Solutions", "Environmental Equipment", "Sustainability Solutions", "Industrial Environmental Products"],
     ["Capacity as per design flow", "Process configuration as per water analysis", "Components as per system design"]),
    ("industrial-hoses-accessories", "Industrial Hoses & Accessories", "Hydraulic, industrial, water and chemical hoses",
     "Hydraulic, industrial, water and chemical hoses with fittings and accessories for fluid transfer across industrial and agricultural applications.",
     "trucks", ["manufacturing", "agriculture", "construction", "water-irrigation"], ["water-transfer", "industrial-maintenance", "irrigation"],
     ["pipes-valves-fittings", "water-pumps-pumping-solutions", "air-compressors"],
     ["Hydraulic Hoses", "Industrial Hoses", "Water Hoses", "Chemical Hoses", "Hose Fittings", "Hose Accessories"],
     ["Diameter, length and pressure rating as per requirement", "Material as per fluid", "End fittings as per system"]),
    ("warehouse-storage-material-handling", "Warehouse, Storage & Material Handling Solutions", "Smart Storage. Efficient Handling. Reliable Supply.",
     "Professional storage, racking and material-handling solutions for warehouses, industrial facilities, offices, healthcare, logistics and commercial environments.",
     "racking", ["warehousing-logistics", "wholesale-distribution", "manufacturing", "healthcare-specialized", "commercial-businesses"], ["warehouse-storage", "material-handling", "logistics"],
     ["material-handling-equipment", "safety-security-equipment", "steel-metal-products"],
     ["Pallet Racking", "Selective Pallet Racking", "Push-Back Racking", "Cantilever Racking", "Radio Shuttle Racking", "Mobile Pallet Racking", "Longspan Racking", "Heavy-Duty Racking", "Mezzanine Systems", "Automated Storage & Retrieval Systems",
      "Slotted Angle Shelving", "Bolt-Free Shelving", "Longspan Shelving", "Static Shelving", "Heavy-Duty Shelving", "Archive Shelving", "Museum Shelving", "Mobile Shelving", "Two-Tier Mobile Shelving",
      "Electric Pallet Trucks", "Stackers", "Reach Trucks", "Forklifts", "Electric Forklifts", "IC Forklifts", "Tow Tractors", "Order Pickers", "VNA Machines",
      "Hospital Mobile Shelving", "Hospital Kanban Systems", "Medical Drawers", "Medical Storage Solutions", "Archive Storage", "Museum Storage", "Medical Curtains",
      "Dock Shelters", "Loading Bay Solutions", "Warehouse Storage Systems", "Picking & Storage Systems", "Warehouse Layout & Optimization"],
     ["Bay dimensions and levels as per layout", "Load capacity per level as per requirement", "Pallet dimensions and quantity", "Finish and accessories as per specification"]),
]

WAREHOUSE_GROUPS = {
    "Warehouse Racking": ["Pallet Racking", "Selective Pallet Racking", "Push-Back Racking", "Cantilever Racking", "Radio Shuttle Racking", "Mobile Pallet Racking", "Longspan Racking", "Heavy-Duty Racking", "Mezzanine Systems", "Automated Storage & Retrieval Systems"],
    "Industrial & Commercial Shelving": ["Slotted Angle Shelving", "Bolt-Free Shelving", "Longspan Shelving", "Static Shelving", "Heavy-Duty Shelving", "Archive Shelving", "Museum Shelving", "Mobile Shelving", "Two-Tier Mobile Shelving"],
    "Material Handling": ["Electric Pallet Trucks", "Stackers", "Reach Trucks", "Forklifts", "Electric Forklifts", "IC Forklifts", "Tow Tractors", "Order Pickers", "VNA Machines"],
    "Healthcare & Specialized Storage": ["Hospital Mobile Shelving", "Hospital Kanban Systems", "Medical Drawers", "Medical Storage Solutions", "Archive Storage", "Museum Storage", "Medical Curtains"],
    "Warehouse & Loading Solutions": ["Dock Shelters", "Loading Bay Solutions", "Warehouse Storage Systems", "Picking & Storage Systems", "Warehouse Layout & Optimization"],
}

SUB_IMAGES = {"Forklift": "forklift", "Pallet Truck": "forklift", "Stacker": "forklift", "Reach Truck": "forklift", "Order Picker": "forklift", "VNA": "forklift", "Tow": "forklift",
              "Shelving": "aisle", "Racking": "racking", "Mezzanine": "racking2", "Dock": "warehouse", "Loading": "warehouse", "Warehouse": "racking2", "Picking": "warehouse",
              "Solar": "solar3", "Cable": "electrical", "Wire": "electrical", "Welding": "welding", "Welder": "welding"}

_IND = {s: n for s, n, _, _ in INDUSTRIES}
_APP = dict(APPLICATIONS)

CATEGORIES, PRODUCTS = [], []
for i, (slug, name, tagline, desc, image, inds, apps, related, subs, configs) in enumerate(RAW_CATEGORIES, 1):
    cat = {"code": f"{i:02d}", "slug": slug, "name": name, "tagline": tagline, "description": desc, "image": img(image), "thumb": img(image, 600),
           "industries": [{"slug": s, "name": _IND[s]} for s in inds], "applications": [{"slug": s, "name": _APP[s]} for s in apps],
           "related_categories": related, "subcategories": [{"name": s, "slug": slugify(s)} for s in subs], "product_count": len(subs),
           "featured": slug == "warehouse-storage-material-handling"}
    if cat["featured"]:
        cat["groups"] = [{"name": g, "items": [{"name": s, "slug": slugify(s)} for s in items]} for g, items in WAREHOUSE_GROUPS.items()]
    CATEGORIES.append(cat)
    for sub in subs:
        ik = next((v for k, v in SUB_IMAGES.items() if k.lower() in sub.lower()), image)
        PRODUCTS.append({
            "slug": slugify(sub), "name": sub, "category_slug": slug, "category_name": name, "category_code": cat["code"],
            "image": img(ik, 900), "thumb": img(ik, 500),
            "overview": f"GES Global Trade sources and supplies {sub.lower()} for commercial, industrial and project requirements across Oman, the GCC and international markets. {desc}",
            "applications": [_APP[a] for a in apps], "industries": [{"slug": s, "name": _IND[s]} for s in inds],
            "configurations": configs, "keywords": [w for w in re.split(r"[\s/&,-]+", (sub + " " + name).lower()) if len(w) > 2],
            "spec_note": "Specifications available based on selected configuration and requirement.",
        })

CATEGORY_BY_SLUG = {c["slug"]: c for c in CATEGORIES}
PRODUCT_BY_SLUG = {}
for p in PRODUCTS:
    PRODUCT_BY_SLUG.setdefault(p["slug"], p)

POPULAR_SEARCHES = ["Water Pumps", "Pallet Racking", "Diesel Generators", "Armoured Cables", "HDPE Pipes", "Forklifts", "Irrigation", "Steel Pipes", "Welding Machines", "Shelving"]

SYNONYMS = {"pump": ["pumps", "pumping"], "rack": ["racking", "racks"], "genset": ["generator", "generators"], "cable": ["cables", "wires", "wire"],
            "forklift": ["forklifts", "reach truck", "stacker"], "shelf": ["shelving", "shelves"], "pipe": ["pipes", "piping", "hdpe", "pvc"], "irrigation": ["drip", "sprinkler", "fertigation"]}


def _terms(q):
    q = q.lower().strip()
    terms = {q}
    for k, vs in SYNONYMS.items():
        if k in q or any(v in q for v in vs):
            terms.update([k] + vs)
    return [t for t in terms if t]


def search_products(q, limit=40):
    terms = _terms(q)
    scored = []
    for p in PRODUCTS:
        hay_name, hay_cat = p["name"].lower(), p["category_name"].lower()
        hay_other = " ".join(p["applications"] + [i["name"] for i in p["industries"]] + p["keywords"]).lower()
        score = 0
        for t in terms:
            if t in hay_name:
                score += 10 if hay_name.startswith(t) else 6
            if t in hay_cat:
                score += 3
            if t in hay_other:
                score += 1
        if score:
            scored.append((score, p))
    scored.sort(key=lambda x: (-x[0], x[1]["name"]))
    return [p for _, p in scored[:limit]]


def search_categories(q):
    terms = _terms(q)
    out = []
    for c in CATEGORIES:
        hay = (c["name"] + " " + c["description"] + " " + " ".join(s["name"] for s in c["subcategories"])).lower()
        if any(t in hay for t in terms):
            out.append(c)
    return out


def related_products(p, limit=8):
    same = [x for x in PRODUCTS if x["category_slug"] == p["category_slug"] and x["slug"] != p["slug"]][:4]
    cat = CATEGORY_BY_SLUG[p["category_slug"]]
    others = []
    for rc in cat["related_categories"]:
        others += [x for x in PRODUCTS if x["category_slug"] == rc][:2]
    return (same + others)[:limit]


def public_category(c):
    return {k: v for k, v in c.items()}
