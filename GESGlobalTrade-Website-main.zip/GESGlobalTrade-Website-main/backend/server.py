import csv
import io
import logging
import os
import time
import uuid
from collections import defaultdict
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Optional, List

from dotenv import load_dotenv

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

from fastapi import FastAPI, APIRouter, HTTPException, UploadFile, File, Request, Depends, Header, Query
from fastapi.responses import Response, StreamingResponse
from motor.motor_asyncio import AsyncIOMotorClient
from pydantic import BaseModel, Field, EmailStr
from pymongo import ReturnDocument
from starlette.middleware.cors import CORSMiddleware

import catalog_data as cat
from storage import init_storage, put_object, get_object, APP_NAME

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger("ges")

client = AsyncIOMotorClient(os.environ['MONGO_URL'])
db = client[os.environ['DB_NAME']]
app = FastAPI(title="GES Global Trade API")
api = APIRouter(prefix="/api")

STATUSES = ["New", "Under Review", "Sourcing", "Supplier Evaluation", "Quotation Prepared", "Awaiting Customer", "Completed", "Closed"]
REQUEST_TYPES = ["Product Enquiry", "RFQ", "BOQ / Bulk Requirement", "Project Requirement", "Technical Requirement", "Tender Requirement", "Warehouse / Storage Project", "General Business Enquiry"]
KIND_PREFIX = {"rfq": "RFQ", "product_request": "PRQ", "business_enquiry": "ENQ", "quick_enquiry": "QEQ", "warehouse_project": "WHP"}
ALLOWED_EXT = {"pdf": "application/pdf", "xls": "application/vnd.ms-excel", "xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
               "doc": "application/msword", "docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
               "jpg": "image/jpeg", "jpeg": "image/jpeg", "png": "image/png"}
MAX_UPLOAD = int(os.environ.get("MAX_UPLOAD_MB", "15")) * 1024 * 1024
DEFAULT_SETTINGS = {"id": "site", "legal_name": "Global Environmental Services & Trading SPC", "brand_name": "GES Global Trade", "region": "Oman & GCC",
                    "email": "info@GESGlobalTrade.com", "phone": "+971 52 228 2043", "whatsapp": "971522282043", "website": "GESGlobalTrade.com",
                    "notification_email": "info@GESGlobalTrade.com", "email_enabled": False, "team_members": ["Sales Team", "Procurement Team", "Management"]}


def now_iso():
    return datetime.now(timezone.utc).isoformat()


# ---------- security helpers (auth deferred; key-gate ready) ----------
async def require_admin(x_admin_key: Optional[str] = Header(None)):
    expected = os.environ.get("ADMIN_API_KEY", "")
    if expected and x_admin_key != expected:
        raise HTTPException(status_code=401, detail="Unauthorized")
    return True


_hits = defaultdict(list)


def rate_limit(request: Request, limit=12, window=60):
    ip = request.headers.get("x-forwarded-for", request.client.host if request.client else "?").split(",")[0].strip()
    now = time.time()
    _hits[ip] = [t for t in _hits[ip] if now - t < window]
    if len(_hits[ip]) >= limit:
        raise HTTPException(status_code=429, detail="Too many requests. Please try again shortly.")
    _hits[ip].append(now)


# ---------- models ----------
class Customer(BaseModel):
    full_name: str = Field(min_length=2, max_length=120)
    company_name: str = Field(default="", max_length=160)
    country: str = Field(min_length=2, max_length=80)
    email: EmailStr
    phone: str = Field(min_length=6, max_length=40)


class Requirement(BaseModel):
    product: str = Field(min_length=2, max_length=300)
    quantity: Optional[str] = Field(default="", max_length=60)
    unit: Optional[str] = Field(default="", max_length=40)
    delivery_location: Optional[str] = Field(default="", max_length=200)
    required_date: Optional[str] = Field(default="", max_length=40)
    specifications: Optional[str] = Field(default="", max_length=5000)
    preferred_brand: Optional[str] = Field(default="", max_length=200)
    alternative: Optional[str] = Field(default="", max_length=500)
    message: Optional[str] = Field(default="", max_length=5000)
    category_slug: Optional[str] = ""
    product_slug: Optional[str] = ""
    industry: Optional[str] = Field(default="", max_length=120)
    application: Optional[str] = Field(default="", max_length=120)


class WarehouseDetails(BaseModel):
    project_name: Optional[str] = ""
    dimensions: Optional[str] = ""
    layout: Optional[str] = ""
    rack_type: Optional[str] = ""
    load_capacity: Optional[str] = ""
    levels: Optional[str] = ""
    pallet_dimensions: Optional[str] = ""
    pallet_count: Optional[str] = ""
    equipment: Optional[str] = ""
    special_requirements: Optional[str] = ""


class EnquiryCreate(BaseModel):
    kind: str
    request_type: Optional[str] = ""
    customer: Customer
    requirement: Requirement
    warehouse: Optional[WarehouseDetails] = None
    document_ids: List[str] = []
    source_page: Optional[str] = ""
    website: Optional[str] = ""  # honeypot


class EnquiryUpdate(BaseModel):
    status: Optional[str] = None
    assigned_to: Optional[str] = None
    priority: Optional[str] = None
    follow_up_date: Optional[str] = None
    follow_up_note: Optional[str] = None
    actor: Optional[str] = "Admin"


class NoteCreate(BaseModel):
    text: str = Field(min_length=1, max_length=3000)
    author: Optional[str] = "Admin"


class SettingsUpdate(BaseModel):
    legal_name: Optional[str] = None
    brand_name: Optional[str] = None
    region: Optional[str] = None
    email: Optional[str] = None
    phone: Optional[str] = None
    whatsapp: Optional[str] = None
    notification_email: Optional[str] = None
    team_members: Optional[List[str]] = None


# ---------- helpers ----------
async def next_reference(prefix: str):
    year = datetime.now(timezone.utc).year
    doc = await db.counters.find_one_and_update({"_id": f"{prefix}-{year}"}, {"$inc": {"seq": 1}}, upsert=True, return_document=ReturnDocument.AFTER)
    return f"GES-{prefix}-{year}-{doc['seq']:04d}"


def compute_priority(e: dict):
    score = 0
    rt = e.get("request_type", "")
    if rt in ("Project Requirement", "Tender Requirement", "Warehouse / Storage Project"):
        score += 3
    if rt == "BOQ / Bulk Requirement":
        score += 3
    if e.get("kind") == "warehouse_project" or e.get("warehouse"):
        score += 2
    docs = e.get("documents", [])
    if any(d.get("doc_type") in ("BOQ", "Drawing", "Technical Specification") for d in docs):
        score += 2
    if e["customer"].get("company_name"):
        score += 1
    if e["requirement"].get("required_date"):
        score += 1
    qty = e["requirement"].get("quantity") or ""
    try:
        if float(qty.replace(",", "")) >= 100:
            score += 1
    except ValueError:
        pass
    return ("High" if score >= 6 else "Medium" if score >= 3 else "Normal"), score


async def notify(ntype, title, message, enquiry_id=None, reference=None):
    await db.notifications.insert_one({"id": str(uuid.uuid4()), "type": ntype, "title": title, "message": message, "enquiry_id": enquiry_id,
                                       "reference": reference, "read": False, "created_at": now_iso()})


async def audit(action, entity_id, meta=None, actor="system"):
    await db.audit_logs.insert_one({"id": str(uuid.uuid4()), "action": action, "entity_id": entity_id, "meta": meta or {}, "actor": actor, "created_at": now_iso()})


async def upsert_customer(e: dict):
    c = e["customer"]
    key = (c.get("company_name") or c["email"]).strip().lower()
    existing = await db.customers.find_one({"key": key}, {"_id": 0})
    contact = {"name": c["full_name"], "email": c["email"], "phone": c["phone"]}
    if existing:
        contacts = existing.get("contacts", [])
        if not any(x["email"].lower() == c["email"].lower() for x in contacts):
            contacts.append(contact)
        await db.customers.update_one({"key": key}, {"$set": {"contacts": contacts, "last_seen": now_iso(), "country": c["country"]}, "$inc": {"enquiry_count": 1}})
        return existing["id"]
    cid = str(uuid.uuid4())
    await db.customers.insert_one({"id": cid, "key": key, "company_name": c.get("company_name") or c["full_name"], "country": c["country"],
                                   "contacts": [contact], "enquiry_count": 1, "first_seen": now_iso(), "last_seen": now_iso(), "notes": []})
    return cid


def public_enquiry(e: dict):
    return {"reference": e["reference"], "status": e["status"], "kind": e["kind"], "request_type": e.get("request_type"),
            "product": e["requirement"]["product"], "created_at": e["created_at"], "updated_at": e["updated_at"],
            "documents": [{"original_filename": d["original_filename"], "uploaded_at": d["uploaded_at"], "doc_type": d.get("doc_type")} for d in e.get("documents", [])],
            "timeline": [{"event": h["event"], "at": h["at"]} for h in e.get("history", [])],
            "next_action": "Please review the quotation shared by our team and confirm your requirement." if e["status"] == "Awaiting Customer" else None}


# ---------- public: settings, catalog ----------
@api.get("/")
async def root():
    return {"service": "GES Global Trade API", "status": "ok"}


@api.get("/settings/public")
async def public_settings():
    s = await db.settings.find_one({"id": "site"}, {"_id": 0}) or DEFAULT_SETTINGS
    return {k: s.get(k) for k in ("legal_name", "brand_name", "region", "email", "phone", "whatsapp", "website")}


@api.get("/catalog/categories")
async def categories():
    return [{k: v for k, v in c.items() if k != "groups"} for c in cat.CATEGORIES]


@api.get("/catalog/categories/{slug}")
async def category(slug: str):
    c = cat.CATEGORY_BY_SLUG.get(slug)
    if not c:
        raise HTTPException(404, "Category not found")
    products = [p for p in cat.PRODUCTS if p["category_slug"] == slug]
    related = [cat.CATEGORY_BY_SLUG[r] for r in c["related_categories"] if r in cat.CATEGORY_BY_SLUG]
    return {**c, "products": products, "related": [{k: r[k] for k in ("slug", "name", "tagline", "thumb", "product_count")} for r in related]}


@api.get("/catalog/products")
async def products(category: Optional[str] = None, industry: Optional[str] = None, application: Optional[str] = None, q: Optional[str] = None, limit: int = 200):
    items = cat.search_products(q, limit=500) if q else list(cat.PRODUCTS)
    if category:
        items = [p for p in items if p["category_slug"] == category]
    if industry:
        items = [p for p in items if any(i["slug"] == industry for i in p["industries"])]
    if application:
        name = dict(cat.APPLICATIONS).get(application, application)
        items = [p for p in items if name in p["applications"]]
    return {"total": len(items), "items": items[:limit]}


@api.get("/catalog/products/{slug}")
async def product(slug: str):
    p = cat.PRODUCT_BY_SLUG.get(slug)
    if not p:
        raise HTTPException(404, "Product not found")
    c = cat.CATEGORY_BY_SLUG[p["category_slug"]]
    related_cats = [cat.CATEGORY_BY_SLUG[r] for r in c["related_categories"]]
    return {**p, "related_products": cat.related_products(p), "related_categories": [{k: r[k] for k in ("slug", "name", "tagline", "thumb")} for r in related_cats]}


@api.get("/catalog/industries")
async def industries():
    out = []
    for slug, name, desc, image in cat.INDUSTRIES:
        cats = [{"slug": c["slug"], "name": c["name"]} for c in cat.CATEGORIES if any(i["slug"] == slug for i in c["industries"])]
        out.append({"slug": slug, "name": name, "description": desc, "image": cat.img(image, 900), "categories": cats})
    return out


@api.get("/catalog/applications")
async def applications():
    out = []
    for slug, name in cat.APPLICATIONS:
        cats = [{"slug": c["slug"], "name": c["name"]} for c in cat.CATEGORIES if any(a["slug"] == slug for a in c["applications"])]
        out.append({"slug": slug, "name": name, "categories": cats})
    return out


@api.get("/catalog/search")
async def search(q: str = Query(min_length=1, max_length=100), limit: int = 8):
    prods = cat.search_products(q, limit=limit)
    cats = cat.search_categories(q)[:4]
    apps = [{"slug": s, "name": n} for s, n in cat.APPLICATIONS if q.lower() in n.lower()][:3]
    return {"query": q, "products": [{k: p[k] for k in ("slug", "name", "category_name", "category_slug", "thumb")} for p in prods],
            "categories": [{k: c[k] for k in ("slug", "name", "product_count")} for c in cats], "applications": apps,
            "popular": cat.POPULAR_SEARCHES}


# ---------- uploads ----------
@api.post("/uploads")
async def upload(request: Request, file: UploadFile = File(...), doc_type: str = "Other Documents"):
    rate_limit(request, limit=40)
    ext = (file.filename or "").rsplit(".", 1)[-1].lower() if "." in (file.filename or "") else ""
    if ext not in ALLOWED_EXT:
        raise HTTPException(400, "This file type or size is not supported.")
    data = await file.read()
    if len(data) == 0 or len(data) > MAX_UPLOAD:
        raise HTTPException(400, "This file type or size is not supported.")
    doc_id = str(uuid.uuid4())
    path = f"{APP_NAME}/uploads/{datetime.now(timezone.utc).year}/{doc_id}.{ext}"
    try:
        result = put_object(path, data, ALLOWED_EXT[ext])
    except Exception as ex:
        logger.error(f"Upload failed: {ex}")
        raise HTTPException(503, "Something went wrong. Please try again or contact us via WhatsApp.")
    record = {"id": doc_id, "storage_path": result["path"], "original_filename": file.filename, "content_type": ALLOWED_EXT[ext], "size": result.get("size", len(data)),
              "doc_type": doc_type, "enquiry_id": None, "is_deleted": False, "uploaded_at": now_iso()}
    await db.documents.insert_one(record)
    return {"id": doc_id, "original_filename": file.filename, "size": record["size"], "doc_type": doc_type}


# ---------- enquiries ----------
@api.post("/enquiries", status_code=201)
async def create_enquiry(payload: EnquiryCreate, request: Request):
    rate_limit(request)
    if payload.website:
        raise HTTPException(400, "Invalid submission")
    kind = payload.kind if payload.kind in KIND_PREFIX else "rfq"
    request_type = payload.request_type or {"rfq": "RFQ", "product_request": "Product Enquiry", "business_enquiry": "General Business Enquiry", "quick_enquiry": "Product Enquiry"}.get(kind, "RFQ")
    if request_type == "Warehouse / Storage Project":
        kind = "warehouse_project"
    reference = await next_reference(KIND_PREFIX[kind])
    docs = []
    if payload.document_ids:
        cursor = db.documents.find({"id": {"$in": payload.document_ids}, "enquiry_id": None, "is_deleted": False}, {"_id": 0})
        docs = await cursor.to_list(50)
    eid = str(uuid.uuid4())
    ts = now_iso()
    e = {"id": eid, "reference": reference, "kind": kind, "request_type": request_type, "customer": payload.customer.model_dump(),
         "requirement": payload.requirement.model_dump(), "warehouse": payload.warehouse.model_dump() if payload.warehouse else None,
         "documents": [{k: d[k] for k in ("id", "original_filename", "content_type", "size", "doc_type", "uploaded_at")} for d in docs],
         "status": "New", "assigned_to": "", "follow_up_date": "", "follow_up_note": "", "notes": [],
         "history": [{"event": "Requirement Received", "status": "New", "at": ts, "by": "customer"}],
         "source_page": payload.source_page, "created_at": ts, "updated_at": ts}
    e["priority"], e["priority_score"] = compute_priority(e)
    e["customer_id"] = await upsert_customer(e)
    await db.enquiries.insert_one(e)
    if docs:
        await db.documents.update_many({"id": {"$in": [d["id"] for d in docs]}}, {"$set": {"enquiry_id": eid}})
    labels = {"rfq": "New RFQ", "product_request": "New Product Request", "business_enquiry": "New Business Enquiry", "quick_enquiry": "New Quick Enquiry", "warehouse_project": "New Warehouse Project"}
    await notify(kind, labels[kind], f"{reference} · {e['customer']['company_name'] or e['customer']['full_name']} · {e['requirement']['product']}", eid, reference)
    if docs:
        await notify("document", "New document upload", f"{len(docs)} file(s) attached to {reference}", eid, reference)
    await audit("enquiry.created", eid, {"reference": reference, "kind": kind}, actor="customer")
    logger.info(f"[EMAIL-DISABLED] Would notify {DEFAULT_SETTINGS['notification_email']} and {e['customer']['email']} about {reference}")
    return {"id": eid, "reference": reference, "status": "New", "created_at": ts}


@api.get("/enquiries/status")
async def enquiry_status(reference: str, email: str, request: Request):
    rate_limit(request, limit=20)
    e = await db.enquiries.find_one({"reference": reference.strip().upper(), "customer.email": {"$regex": f"^{email.strip()}$", "$options": "i"}}, {"_id": 0})
    if not e:
        raise HTTPException(404, "No enquiry found for this reference and email combination.")
    return public_enquiry(e)


@api.get("/meta")
async def meta():
    return {"statuses": STATUSES, "request_types": REQUEST_TYPES, "allowed_extensions": sorted(ALLOWED_EXT), "max_upload_mb": MAX_UPLOAD // (1024 * 1024)}


# ---------- admin ----------
admin = APIRouter(prefix="/admin", dependencies=[Depends(require_admin)])


@admin.get("/dashboard")
async def dashboard():
    today = datetime.now(timezone.utc).date().isoformat()
    total = await db.enquiries.count_documents({})
    kpis = {"total": total, "new": await db.enquiries.count_documents({"status": "New"}),
            "active_rfqs": await db.enquiries.count_documents({"kind": "rfq", "status": {"$nin": ["Completed", "Closed"]}}),
            "product_requests": await db.enquiries.count_documents({"kind": "product_request"}),
            "project_requests": await db.enquiries.count_documents({"request_type": {"$in": ["Project Requirement", "Tender Requirement", "BOQ / Bulk Requirement"]}}),
            "warehouse_projects": await db.enquiries.count_documents({"kind": "warehouse_project"}),
            "pending_followups": await db.enquiries.count_documents({"follow_up_date": {"$gte": today}, "status": {"$nin": ["Completed", "Closed"]}}),
            "completed": await db.enquiries.count_documents({"status": "Completed"})}
    recent = await db.enquiries.find({}, {"_id": 0, "notes": 0, "history": 0}).sort("created_at", -1).limit(8).to_list(8)
    fu = await followups()
    unread = await db.notifications.count_documents({"read": False})
    return {"kpis": kpis, "recent": recent, "followups": fu, "unread_notifications": unread}


@admin.get("/enquiries")
async def list_enquiries(q: Optional[str] = None, status: Optional[str] = None, kind: Optional[str] = None, priority: Optional[str] = None,
                         assigned_to: Optional[str] = None, sort: str = "created_at", order: str = "desc", page: int = 1, page_size: int = 25):
    f = {}
    if status:
        f["status"] = status
    if kind:
        f["kind"] = kind
    if priority:
        f["priority"] = priority
    if assigned_to:
        f["assigned_to"] = assigned_to
    if q:
        rx = {"$regex": q, "$options": "i"}
        f["$or"] = [{"reference": rx}, {"customer.full_name": rx}, {"customer.company_name": rx}, {"customer.email": rx}, {"requirement.product": rx}, {"customer.country": rx}]
    total = await db.enquiries.count_documents(f)
    sort_field = sort if sort in ("created_at", "updated_at", "status", "priority_score", "reference", "follow_up_date") else "created_at"
    items = await db.enquiries.find(f, {"_id": 0, "notes": 0, "history": 0}).sort(sort_field, -1 if order == "desc" else 1).skip((page - 1) * page_size).limit(page_size).to_list(page_size)
    return {"total": total, "page": page, "page_size": page_size, "items": items}


@admin.get("/enquiries/export")
async def export_enquiries():
    items = await db.enquiries.find({}, {"_id": 0}).sort("created_at", -1).to_list(5000)
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(["Reference", "Type", "Request Type", "Status", "Priority", "Name", "Company", "Country", "Email", "Phone", "Product", "Quantity", "Unit", "Delivery Location", "Required Date", "Assigned", "Follow-up", "Created"])
    for e in items:
        c, r = e["customer"], e["requirement"]
        w.writerow([e["reference"], e["kind"], e.get("request_type"), e["status"], e.get("priority"), c["full_name"], c.get("company_name"), c["country"], c["email"], c["phone"],
                    r["product"], r.get("quantity"), r.get("unit"), r.get("delivery_location"), r.get("required_date"), e.get("assigned_to"), e.get("follow_up_date"), e["created_at"]])
    return StreamingResponse(iter([buf.getvalue()]), media_type="text/csv", headers={"Content-Disposition": "attachment; filename=ges-enquiries.csv"})


@admin.get("/enquiries/{eid}")
async def get_enquiry(eid: str):
    e = await db.enquiries.find_one({"$or": [{"id": eid}, {"reference": eid}]}, {"_id": 0})
    if not e:
        raise HTTPException(404, "Enquiry not found")
    return e


@admin.patch("/enquiries/{eid}")
async def update_enquiry(eid: str, upd: EnquiryUpdate):
    e = await db.enquiries.find_one({"id": eid}, {"_id": 0})
    if not e:
        raise HTTPException(404, "Enquiry not found")
    sets, push = {"updated_at": now_iso()}, []
    if upd.status and upd.status != e["status"]:
        if upd.status not in STATUSES:
            raise HTTPException(400, "Invalid status")
        sets["status"] = upd.status
        push.append({"event": upd.status, "status": upd.status, "at": now_iso(), "by": upd.actor})
        await notify("status", "Status updated", f"{e['reference']} moved to {upd.status}", eid, e["reference"])
    if upd.assigned_to is not None and upd.assigned_to != e.get("assigned_to"):
        sets["assigned_to"] = upd.assigned_to
        push.append({"event": f"Assigned to {upd.assigned_to or 'nobody'}", "status": e["status"], "at": now_iso(), "by": upd.actor})
    if upd.priority is not None:
        sets["priority"] = upd.priority
    if upd.follow_up_date is not None:
        sets["follow_up_date"] = upd.follow_up_date
        if upd.follow_up_date:
            push.append({"event": f"Follow-up scheduled for {upd.follow_up_date}", "status": e["status"], "at": now_iso(), "by": upd.actor})
    if upd.follow_up_note is not None:
        sets["follow_up_note"] = upd.follow_up_note
    update = {"$set": sets}
    if push:
        update["$push"] = {"history": {"$each": push}}
    await db.enquiries.update_one({"id": eid}, update)
    await audit("enquiry.updated", eid, sets, actor=upd.actor or "Admin")
    return await db.enquiries.find_one({"id": eid}, {"_id": 0})


@admin.post("/enquiries/{eid}/notes")
async def add_note(eid: str, note: NoteCreate):
    n = {"id": str(uuid.uuid4()), "text": note.text, "author": note.author, "created_at": now_iso()}
    res = await db.enquiries.update_one({"id": eid}, {"$push": {"notes": n}, "$set": {"updated_at": now_iso()}})
    if not res.matched_count:
        raise HTTPException(404, "Enquiry not found")
    return n


@admin.get("/documents/{doc_id}/download")
async def download_document(doc_id: str):
    d = await db.documents.find_one({"id": doc_id, "is_deleted": False}, {"_id": 0})
    if not d:
        raise HTTPException(404, "Document not found")
    try:
        data, ctype = get_object(d["storage_path"])
    except Exception as ex:
        logger.error(f"Download failed: {ex}")
        raise HTTPException(503, "Document temporarily unavailable")
    return Response(content=data, media_type=d.get("content_type", ctype), headers={"Content-Disposition": f'attachment; filename="{d["original_filename"]}"'})


@admin.get("/customers")
async def list_customers(q: Optional[str] = None):
    f = {"$or": [{"company_name": {"$regex": q, "$options": "i"}}, {"contacts.email": {"$regex": q, "$options": "i"}}, {"country": {"$regex": q, "$options": "i"}}]} if q else {}
    return await db.customers.find(f, {"_id": 0}).sort("last_seen", -1).to_list(500)


@admin.get("/customers/{cid}")
async def get_customer(cid: str):
    c = await db.customers.find_one({"id": cid}, {"_id": 0})
    if not c:
        raise HTTPException(404, "Customer not found")
    enquiries = await db.enquiries.find({"customer_id": cid}, {"_id": 0}).sort("created_at", -1).to_list(200)
    return {**c, "enquiries": enquiries}


@admin.post("/customers/{cid}/notes")
async def customer_note(cid: str, note: NoteCreate):
    n = {"id": str(uuid.uuid4()), "text": note.text, "author": note.author, "created_at": now_iso()}
    res = await db.customers.update_one({"id": cid}, {"$push": {"notes": n}})
    if not res.matched_count:
        raise HTTPException(404, "Customer not found")
    return n


@admin.get("/followups")
async def followups():
    today = datetime.now(timezone.utc).date()
    items = await db.enquiries.find({"follow_up_date": {"$ne": ""}, "status": {"$nin": ["Completed", "Closed"]}}, {"_id": 0, "notes": 0, "history": 0}).sort("follow_up_date", 1).to_list(500)
    out = {"today": [], "upcoming": [], "overdue": []}
    for e in items:
        try:
            d = datetime.fromisoformat(e["follow_up_date"]).date()
        except ValueError:
            continue
        out["today" if d == today else "upcoming" if d > today else "overdue"].append(e)
    return out


@admin.get("/notifications")
async def notifications(limit: int = 50):
    items = await db.notifications.find({}, {"_id": 0}).sort("created_at", -1).limit(limit).to_list(limit)
    unread = await db.notifications.count_documents({"read": False})
    today = datetime.now(timezone.utc).date().isoformat()
    due = await db.enquiries.count_documents({"follow_up_date": today, "status": {"$nin": ["Completed", "Closed"]}})
    overdue = await db.enquiries.count_documents({"follow_up_date": {"$lt": today, "$ne": ""}, "status": {"$nin": ["Completed", "Closed"]}})
    return {"items": items, "unread": unread, "followups_due_today": due, "followups_overdue": overdue}


@admin.post("/notifications/read")
async def mark_read(ids: Optional[List[str]] = None):
    f = {"id": {"$in": ids}} if ids else {}
    await db.notifications.update_many(f, {"$set": {"read": True}})
    return {"ok": True}


@admin.get("/analytics")
async def analytics():
    items = await db.enquiries.find({}, {"_id": 0, "notes": 0, "history": 0}).to_list(10000)
    by_month, by_cat, by_industry, by_country, by_status, by_kind, by_app = (defaultdict(int) for _ in range(7))
    for e in items:
        by_month[e["created_at"][:7]] += 1
        r = e["requirement"]
        c = cat.CATEGORY_BY_SLUG.get(r.get("category_slug") or "")
        by_cat[c["name"] if c else "Unlisted / Custom"] += 1
        by_industry[r.get("industry") or "Not specified"] += 1
        by_app[r.get("application") or "Not specified"] += 1
        by_country[e["customer"]["country"]] += 1
        by_status[e["status"]] += 1
        by_kind[e["kind"]] += 1
    top = lambda d, n=10: sorted(({"name": k, "value": v} for k, v in d.items()), key=lambda x: -x["value"])[:n]
    months = []
    d = datetime.now(timezone.utc).replace(day=1)
    for i in range(11, -1, -1):
        m = (d - timedelta(days=30 * i)).strftime("%Y-%m")
        months.append({"month": m, "value": by_month.get(m, 0)})
    workload = defaultdict(int)
    for e in items:
        if e["status"] not in ("Completed", "Closed"):
            workload[e.get("assigned_to") or "Unassigned"] += 1
    return {"total": len(items), "by_month": months, "by_category": top(by_cat), "by_industry": top(by_industry), "by_country": top(by_country),
            "by_application": top(by_app), "funnel": [{"name": s, "value": by_status.get(s, 0)} for s in STATUSES], "by_kind": top(by_kind),
            "workload": top(workload), "followups": await followups()}


@admin.get("/settings")
async def get_settings():
    return await db.settings.find_one({"id": "site"}, {"_id": 0}) or DEFAULT_SETTINGS


@admin.put("/settings")
async def put_settings(upd: SettingsUpdate):
    sets = {k: v for k, v in upd.model_dump().items() if v is not None}
    await db.settings.update_one({"id": "site"}, {"$set": sets}, upsert=True)
    await audit("settings.updated", "site", sets)
    return await db.settings.find_one({"id": "site"}, {"_id": 0})


@admin.get("/audit")
async def audit_logs(limit: int = 100):
    return await db.audit_logs.find({}, {"_id": 0}).sort("created_at", -1).limit(limit).to_list(limit)


api.include_router(admin)
app.include_router(api)
app.add_middleware(CORSMiddleware, allow_credentials=True, allow_origins=os.environ.get('CORS_ORIGINS', '*').split(','), allow_methods=["*"], allow_headers=["*"])


@app.on_event("startup")
async def startup():
    await db.enquiries.create_index("reference", unique=True)
    await db.enquiries.create_index([("created_at", -1)])
    await db.enquiries.create_index("customer_id")
    await db.documents.create_index("id", unique=True)
    await db.customers.create_index("key", unique=True)
    await db.settings.update_one({"id": "site"}, {"$setOnInsert": DEFAULT_SETTINGS}, upsert=True)
    try:
        init_storage()
        logger.info("Object storage initialized")
    except Exception as ex:
        logger.error(f"Storage init failed: {ex}")


@app.on_event("shutdown")
async def shutdown():
    client.close()
