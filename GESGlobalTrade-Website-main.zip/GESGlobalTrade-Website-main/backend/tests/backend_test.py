"""Backend API tests for GES Global Trade platform."""
import io
import os
import time
from datetime import datetime, timezone

import pytest
import requests

BASE_URL = os.environ.get("REACT_APP_BACKEND_URL")
if not BASE_URL:
    # fallback: read from frontend .env
    with open("/app/frontend/.env") as f:
        for line in f:
            if line.startswith("REACT_APP_BACKEND_URL="):
                BASE_URL = line.split("=", 1)[1].strip()
                break
BASE_URL = BASE_URL.rstrip("/")
API = f"{BASE_URL}/api"


@pytest.fixture(scope="session")
def client():
    s = requests.Session()
    return s


# ---------- catalog ----------
class TestCatalog:
    def test_categories_count(self, client):
        r = client.get(f"{API}/catalog/categories")
        assert r.status_code == 200
        data = r.json()
        assert isinstance(data, list)
        assert len(data) == 21, f"expected 21 categories, got {len(data)}"

    def test_category_detail_warehouse(self, client):
        r = client.get(f"{API}/catalog/categories/warehouse-storage-material-handling")
        assert r.status_code == 200
        data = r.json()
        assert "groups" in data
        assert "products" in data
        assert len(data["products"]) > 0

    def test_product_ges_procurement(self, client):
        r = client.get(f"{API}/catalog/products/ges-procurement")
        # if product doesn't exist, skip
        if r.status_code == 404:
            pytest.skip("ges-procurement product not in catalog")
        assert r.status_code == 200
        d = r.json()
        assert "related_products" in d
        assert "related_categories" in d

    def test_search_pump(self, client):
        r = client.get(f"{API}/catalog/search", params={"q": "pump"})
        assert r.status_code == 200
        d = r.json()
        assert len(d["products"]) > 0
        assert "categories" in d

    def test_products_no_match(self, client):
        r = client.get(f"{API}/catalog/products", params={"q": "xyznotfound"})
        assert r.status_code == 200
        assert r.json()["total"] == 0

    def test_industries(self, client):
        r = client.get(f"{API}/catalog/industries")
        assert r.status_code == 200
        assert isinstance(r.json(), list)
        assert len(r.json()) > 0

    def test_applications(self, client):
        r = client.get(f"{API}/catalog/applications")
        assert r.status_code == 200
        assert isinstance(r.json(), list)


# ---------- uploads ----------
class TestUploads:
    def test_upload_pdf_ok(self, client):
        pdf_bytes = b"%PDF-1.4\n%test\n1 0 obj<<>>endobj\ntrailer<<>>\n%%EOF"
        files = {"file": ("test.pdf", io.BytesIO(pdf_bytes), "application/pdf")}
        r = client.post(f"{API}/uploads?doc_type=BOQ", files=files)
        assert r.status_code == 200, r.text
        d = r.json()
        assert "id" in d
        pytest.uploaded_doc_id = d["id"]

    def test_upload_exe_rejected(self, client):
        files = {"file": ("bad.exe", io.BytesIO(b"MZ\x90\x00"), "application/octet-stream")}
        r = client.post(f"{API}/uploads", files=files)
        assert r.status_code == 400
        assert "not supported" in r.text.lower()

    def test_upload_txt_rejected(self, client):
        files = {"file": ("readme.txt", io.BytesIO(b"hello"), "text/plain")}
        r = client.post(f"{API}/uploads", files=files)
        assert r.status_code == 400


# ---------- enquiries ----------
BASE_CUSTOMER = {"full_name": "TEST Buyer", "company_name": "TEST Co", "country": "Oman",
                 "email": "test_buyer@example.com", "phone": "+96812345678"}
BASE_REQ = {"product": "Submersible pumps 5HP", "quantity": "10", "unit": "nos"}


class TestEnquiries:
    def test_create_rfq(self, client):
        r = client.post(f"{API}/enquiries", json={"kind": "rfq", "request_type": "RFQ",
                                                  "customer": BASE_CUSTOMER, "requirement": BASE_REQ})
        assert r.status_code == 201, r.text
        ref = r.json()["reference"]
        assert ref.startswith("GES-RFQ-")
        pytest.rfq_ref = ref
        pytest.rfq_id = r.json()["id"]

    def test_create_warehouse(self, client):
        doc_ids = [getattr(pytest, "uploaded_doc_id", None)] if getattr(pytest, "uploaded_doc_id", None) else []
        # only include doc if not already attached; upload new for isolation
        pdf_bytes = b"%PDF-1.4\n%wh\n%%EOF"
        up = client.post(f"{API}/uploads?doc_type=BOQ",
                         files={"file": ("wh.pdf", io.BytesIO(pdf_bytes), "application/pdf")})
        assert up.status_code == 200
        doc_ids = [up.json()["id"]]
        r = client.post(f"{API}/enquiries", json={"kind": "rfq", "request_type": "Warehouse / Storage Project",
                                                  "customer": BASE_CUSTOMER, "requirement": BASE_REQ,
                                                  "warehouse": {"project_name": "TEST WH", "dimensions": "50x30"},
                                                  "document_ids": doc_ids})
        assert r.status_code == 201, r.text
        assert r.json()["reference"].startswith("GES-WHP-")
        pytest.whp_ref = r.json()["reference"]

    def test_create_product_request(self, client):
        r = client.post(f"{API}/enquiries", json={"kind": "product_request",
                                                  "customer": BASE_CUSTOMER, "requirement": BASE_REQ})
        assert r.status_code == 201
        assert r.json()["reference"].startswith("GES-PRQ-")

    def test_create_business_enquiry(self, client):
        r = client.post(f"{API}/enquiries", json={"kind": "business_enquiry",
                                                  "customer": BASE_CUSTOMER, "requirement": BASE_REQ})
        assert r.status_code == 201
        assert r.json()["reference"].startswith("GES-ENQ-")

    def test_create_quick_enquiry(self, client):
        r = client.post(f"{API}/enquiries", json={"kind": "quick_enquiry",
                                                  "customer": BASE_CUSTOMER, "requirement": BASE_REQ})
        assert r.status_code == 201
        assert r.json()["reference"].startswith("GES-QEQ-")

    def test_honeypot_blocks(self, client):
        r = client.post(f"{API}/enquiries", json={"kind": "rfq", "website": "spam",
                                                  "customer": BASE_CUSTOMER, "requirement": BASE_REQ})
        assert r.status_code == 400

    def test_invalid_email(self, client):
        bad = dict(BASE_CUSTOMER, email="not-an-email")
        r = client.post(f"{API}/enquiries", json={"kind": "rfq", "customer": bad, "requirement": BASE_REQ})
        assert r.status_code == 422

    def test_unique_references(self, client):
        refs = set()
        for _ in range(3):
            r = client.post(f"{API}/enquiries", json={"kind": "rfq",
                                                     "customer": BASE_CUSTOMER, "requirement": BASE_REQ})
            assert r.status_code == 201
            refs.add(r.json()["reference"])
        assert len(refs) == 3

    def test_status_lookup_ok(self, client):
        ref = getattr(pytest, "rfq_ref", None)
        assert ref
        r = client.get(f"{API}/enquiries/status", params={"reference": ref, "email": BASE_CUSTOMER["email"]})
        assert r.status_code == 200
        d = r.json()
        assert "notes" not in d
        assert "priority" not in d
        assert d["reference"] == ref

    def test_status_lookup_wrong_email(self, client):
        ref = getattr(pytest, "rfq_ref", None)
        r = client.get(f"{API}/enquiries/status", params={"reference": ref, "email": "wrong@x.com"})
        assert r.status_code == 404


# ---------- admin ----------
@pytest.fixture(scope="module")
def admin_enquiry(client):
    """Create a dedicated enquiry for admin tests to avoid cross-worker state."""
    r = client.post(f"{API}/enquiries", json={"kind": "rfq", "request_type": "RFQ",
                                              "customer": BASE_CUSTOMER, "requirement": BASE_REQ})
    assert r.status_code == 201
    return r.json()


class TestAdmin:
    def test_dashboard(self, client):
        r = client.get(f"{API}/admin/dashboard")
        assert r.status_code == 200
        d = r.json()
        assert "kpis" in d
        assert d["kpis"]["total"] > 0

    def test_list_enquiries_filters(self, client):
        r = client.get(f"{API}/admin/enquiries", params={"q": "pump", "kind": "rfq", "page": 1})
        assert r.status_code == 200
        assert "items" in r.json()

    def test_get_enquiry(self, client, admin_enquiry):
        eid = admin_enquiry["id"]
        r = client.get(f"{API}/admin/enquiries/{eid}")
        assert r.status_code == 200
        assert r.json()["id"] == eid

    def test_patch_status_and_history(self, client, admin_enquiry):
        eid = admin_enquiry["id"]
        r = client.patch(f"{API}/admin/enquiries/{eid}", json={"status": "Sourcing"})
        assert r.status_code == 200
        d = r.json()
        assert d["status"] == "Sourcing"
        assert any(h["event"] == "Sourcing" for h in d["history"])

    def test_patch_followup_and_appears(self, client, admin_enquiry):
        eid = admin_enquiry["id"]
        today = datetime.now(timezone.utc).date().isoformat()
        r = client.patch(f"{API}/admin/enquiries/{eid}",
                         json={"follow_up_date": today, "assigned_to": "Sales Team", "priority": "High"})
        assert r.status_code == 200
        f = client.get(f"{API}/admin/followups")
        assert f.status_code == 200
        today_items = f.json()["today"]
        assert any(e["id"] == eid for e in today_items)

    def test_add_note(self, client, admin_enquiry):
        eid = admin_enquiry["id"]
        r = client.post(f"{API}/admin/enquiries/{eid}/notes", json={"text": "TEST note"})
        assert r.status_code == 200
        assert r.json()["text"] == "TEST note"

    def test_download_document(self, client):
        doc_id = getattr(pytest, "uploaded_doc_id", None)
        if not doc_id:
            pytest.skip("no doc uploaded")
        r = client.get(f"{API}/admin/documents/{doc_id}/download")
        assert r.status_code == 200
        assert "attachment" in r.headers.get("content-disposition", "").lower()
        assert len(r.content) > 0

    def test_customers_list_and_detail(self, client):
        r = client.get(f"{API}/admin/customers")
        assert r.status_code == 200
        customers = r.json()
        assert len(customers) > 0
        cid = customers[0]["id"]
        r2 = client.get(f"{API}/admin/customers/{cid}")
        assert r2.status_code == 200
        assert "enquiries" in r2.json()

    def test_customer_notes(self, client):
        cs = client.get(f"{API}/admin/customers").json()
        cid = cs[0]["id"]
        r = client.post(f"{API}/admin/customers/{cid}/notes", json={"text": "TEST cust note"})
        assert r.status_code == 200

    def test_notifications(self, client):
        r = client.get(f"{API}/admin/notifications")
        assert r.status_code == 200
        d = r.json()
        assert "items" in d and "unread" in d
        r2 = client.post(f"{API}/admin/notifications/read")
        assert r2.status_code == 200

    def test_analytics(self, client):
        r = client.get(f"{API}/admin/analytics")
        assert r.status_code == 200
        d = r.json()
        assert len(d["by_month"]) == 12
        assert "funnel" in d
        assert "by_category" in d

    def test_export_csv(self, client):
        r = client.get(f"{API}/admin/enquiries/export")
        assert r.status_code == 200
        assert "text/csv" in r.headers.get("content-type", "")
        assert "Reference" in r.text

    def test_settings_get_put(self, client):
        r = client.get(f"{API}/admin/settings")
        assert r.status_code == 200
        r2 = client.put(f"{API}/admin/settings", json={"phone": "+971 52 228 2043"})
        assert r2.status_code == 200
